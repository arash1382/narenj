# Naranj Typography System

Version 1.0 · Demo baseline · Persian-first · RTL

## Font family

Use the supplied **Abar Low** family for all Persian UI text. The repository contains these exact font files:

| File | CSS weight | Intended use |
|---|---:|---|
| `AbarLow-Regular.woff2` | 400 | Body text, descriptions, form input |
| `AbarLow-SemiBold.woff2` | 600 | Buttons, labels, card titles, navigation |
| `AbarLow-Bold.woff2` | 700 | Section headings, page titles |
| `AbarLow-ExtraBold.woff2` | 800 | Strong display headings, key metrics |
| `AbarLow-Black.woff2` | 900 | Rare hero/display emphasis only |

Do not substitute another Persian font. Do not synthesize missing weights; use the actual supplied font files.

## Type scale

| Token | Size | Weight | Line height | Use |
|---|---:|---:|---:|---|
| Display | 40px | 800 | 1.35 | Onboarding hero / welcome |
| H1 | 32px | 700 | 1.4 | Page title |
| H2 | 26px | 700 | 1.45 | Major section heading |
| H3 | 22px | 600 | 1.5 | Card group / panel heading |
| H4 | 18px | 600 | 1.55 | Card title / subheading |
| Body Large | 17px | 400 | 1.85 | Introductory and important copy |
| Body | 15px | 400 | 1.8 | Default interface text |
| Body Small | 14px | 400 | 1.75 | Supporting descriptions |
| Label | 13px | 600 | 1.6 | Form labels, chips, metadata |
| Caption | 12px | 400 | 1.6 | Secondary metadata only |
| Button | 15px | 600 | 1.2 | Button labels |

Use this as a compact scale. Do not create arbitrary one-off font sizes without a clear need.

## Numeric and mathematics typography

- Use tabular numerals for scores, timers, counts and progress values where supported (`font-variant-numeric: tabular-nums`).
- Use Persian digits in ordinary Persian UI by default, unless the math/question specification requires Latin digits or a specific numeral system.
- Keep mathematical expressions, variables, operators and equation content in a dedicated math rendering layer; do not force Persian text shaping onto math glyphs.
- Mixed Persian/Latin strings must use explicit direction isolation (`<bdi>` or equivalent) to prevent punctuation and numbers from jumping.
- Keep SmartScore values and timers visually stable; reserve a fixed-width numeric area where values update.

## Persian and RTL rules

- Set document language to `fa` and direction to `rtl` at the application shell.
- Align Persian paragraphs right by default.
- Do not reverse mathematical expressions, URLs, email addresses, English abbreviations or Latin identifiers.
- Use logical CSS properties (`margin-inline`, `padding-inline`, `inset-inline`, `border-inline`) instead of hardcoded left/right where possible.
- Do not use negative letter spacing as a general Persian typography trick.
- Avoid all-caps decorative labels.
- Keep headings short and line lengths comfortable.

## Font loading

Load local WOFF2 files using `@font-face` from `/design-system/fonts/` or the corresponding public asset path. Use `font-display: swap`. Ensure the correct font is preloaded for the first visible screen.
