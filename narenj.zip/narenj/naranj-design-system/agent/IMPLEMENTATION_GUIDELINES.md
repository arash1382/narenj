# Naranj Agent Implementation Guidelines

1. Read `DESIGN.md` and the referenced design-system documents before coding.
2. Treat the supplied UX Architecture v2.1 as the product behavior authority. Do not silently change confirmed rules.
3. Implement only pages included in the approved demo scope. If scope is not yet supplied, propose a short page list and wait for confirmation before expanding.
4. Use Abar Low local WOFF2 files and the provided `fonts.css`.
5. Use the existing color CSS variables and tokens. Never add arbitrary hex values to components.
6. Build reusable components from `COMPONENTS.md`; avoid one-off styling.
7. Implement Persian RTL as the default direction, including logical CSS properties and mixed-direction isolation.
8. Follow the responsive grid and breakpoints in `LAYOUT_SYSTEM.md`.
9. Every interactive control must have a real demo behavior. If backend behavior is unavailable, use clearly labeled mock state.
10. Include loading, empty, error, success, disabled, focus and selected states as relevant.
11. Keep the interface spacious but purposeful. The main task must be immediately discoverable.
12. Test at 360, 390, 768, 1024, 1280 and 1440px.
13. Respect `prefers-reduced-motion`; do not rely on animation to communicate important information.
14. Keep content age-appropriate, school-appropriate and in natural Persian.
15. Do not invent logos, mascot variants or avatar designs that conflict with the approved assets.
