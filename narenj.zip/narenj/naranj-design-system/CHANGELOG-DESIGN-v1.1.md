# Design System v1.1

- Consolidated UI/UX standards into the root DESIGN.md.
- Added explicit authority rules protecting UX Architecture v2.1, approved flows, brand colors and typography.
- Added navigation, responsive layout, reusable component, interaction-state, accessibility, RTL and QA standards.
- Preserved all existing color, typography, font, layout-token and component files unchanged.
