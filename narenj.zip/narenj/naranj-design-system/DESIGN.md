# Naranj Design System — UI/UX Specification

**Version:** 1.1  
**Status:** Consolidated implementation specification  
**Product mode:** Persian-first · RTL by default  
**Authority:** This document governs visual structure and interface implementation. It does not redefine product behavior.

---

## 1. Purpose and authority

This document consolidates practical interface standards for Naranj using the existing Naranj design baseline and selected patterns from Notion, Airtable, Figma, Intercom, Wise and Shopify.

The references inform **information hierarchy, layout, navigation clarity, component behavior, data presentation and accessibility**. They are not visual templates.

### 1.1 Immutable product and brand constraints

The implementation agent MUST preserve the following:

- Existing Naranj brand colors and semantic color tokens.
- Existing typography decisions, font files, font weights, type scale and Persian/English font assignments.
- Approved product flows, sitemap, page inventory, roles, business rules and learning logic in **UX Architecture v2.1**.
- Approved question types and question interaction definitions in the supplied question-type workbook.
- Existing demo scope and approved content/data sources.

Do not rename, reorder, add, remove or reinterpret product flows. Do not invent new screens or navigation destinations. If a UX improvement appears to require a flow or business-rule change, document it as a proposal and do not implement it without approval.

### 1.2 Source hierarchy

When sources conflict, use this order:

1. UX Architecture v2.1 — product behavior, flows, roles and rules.
2. Approved demo scope — what is included in the demo.
3. Existing Naranj color and typography specifications — brand styling.
4. This document — UI structure, components, responsive behavior and accessibility.
5. Existing component/layout token files — exact implementation values.
6. External reference DESIGN.md files — inspiration only; never override Naranj sources.

---

## 2. Design principles

### 2.1 Clarity before decoration

- Every screen must make its primary task obvious.
- Use hierarchy, grouping, spacing and concise labels before adding decoration.
- Avoid unnecessary cards, borders, badges, illustrations and explanatory copy.
- Do not make every element visually prominent. Establish one primary emphasis per task area.

### 2.2 Progressive disclosure

- Show the information needed for the current decision first.
- Put secondary details behind an intentional expansion, detail view or contextual disclosure.
- Do not hide essential actions or status information behind hover-only interactions.
- Keep the number of simultaneous choices manageable, especially in student-facing practice.

### 2.3 Consistency and predictability

- Reuse the same component for the same purpose across pages.
- Keep navigation placement, action hierarchy, control behavior and status language consistent.
- Prefer established patterns over bespoke page-specific interactions.
- A component must not change its meaning between student and teacher areas.

### 2.4 Task-appropriate density

- Student experience: calm, guided, readable and focused on the next learning action.
- Teacher experience: more information-dense, scannable and efficient for class management.
- Use tables when comparison or scanning across structured records is important; use cards or lists when the user is choosing or progressing through content.
- Do not force both roles into the same density or page composition.

### 2.5 Feedback that helps users recover

- Every meaningful action must produce a clear result.
- Explain what happened and, when relevant, what the user can do next.
- Practice feedback should be instructional and encouraging, not punitive.
- Avoid transient toast-only feedback for critical errors or information users must retain.

---

## 3. Information architecture and navigation

Navigation must implement the approved UX Architecture v2.1. This section defines presentation and usability rules only.

### 3.1 Navigation rules

- Keep global navigation stable between pages within the same role area.
- Clearly distinguish the current location using more than color alone (e.g. label weight, indicator, icon or background).
- Use familiar, concise destination labels. Avoid internal product terminology where a plain-language label is clearer.
- Keep primary destinations visible; place infrequent utilities in a secondary menu.
- Do not duplicate the same destination in multiple navigation regions unless the architecture explicitly requires it.
- Avoid nested navigation deeper than necessary. Prefer a clear parent/child relationship and a visible way back.
- Do not use hover as the only way to reveal navigation options.
- Preserve the user's current context when opening a detail view, dialog or temporary task.

### 3.2 Role-specific shells

- Student and teacher areas may use different navigation shells where their tasks differ, as defined by the approved architecture.
- Shared foundations (spacing, controls, feedback, typography, color tokens) must remain consistent.
- Do not add a role selector before authentication if the approved flow determines the role after sign-in.
- Do not add navigation items or role capabilities that are not in the approved architecture.

### 3.3 RTL navigation

- Default application direction is RTL.
- Use CSS logical properties (`margin-inline`, `padding-inline`, `inset-inline`, `border-inline`) rather than hard-coded left/right values.
- In RTL, navigation order and directional icons must be checked in context; do not blindly mirror non-directional icons.
- Back/forward, expand/collapse, breadcrumb and pagination indicators must communicate the correct direction.
- Keep icon-label spacing and active indicators consistent across all navigation states.

### 3.4 Focused tasks

A focused practice or assessment experience must visually minimize unrelated navigation and distractions, while preserving the exit or return behavior defined in the product architecture. Do not invent a new exit flow.

---

## 4. Grid, layout and spacing

Use the existing `design-system/layout/LAYOUT_SYSTEM.md` and `layout-tokens.css` as the implementation source of truth. The following rules explain how to apply them.

### 4.1 Responsive grid

| Viewport | Grid | Outer gutter | Column gap |
|---|---:|---:|---:|
| Mobile: 0–599px | 4 columns | 16px | 12px |
| Tablet: 600–899px | 8 columns | 24px | 20px |
| Desktop: 900–1199px | 12 columns | 32px | 24px |
| Wide: 1200px+ | 12 columns | 40px | 24px |

- Maximum main content width: 1200px.
- Center the content container on wide screens.
- Keep long-form reading widths controlled; do not stretch paragraphs across the full desktop canvas.
- Use grid spans consistently. Avoid arbitrary pixel positioning for primary page structure.
- Cards in a row should align to a common grid and maintain consistent internal padding.

### 4.2 Spacing system

- Use the existing 4px-based spacing scale.
- Prefer the established 8px and 16px rhythm for common gaps.
- Use larger spacing between sections than between items within a section.
- Keep labels close to their controls and headings close to the content they introduce.
- Do not use whitespace to compensate for weak hierarchy.
- Do not introduce one-off spacing values when an existing token is suitable.

### 4.3 Responsive behavior

- Design mobile layouts as intentional compositions, not compressed desktop pages.
- Reflow multi-column content to a single column when the content no longer has sufficient readable width.
- Do not shrink text or controls to preserve a desktop layout.
- Avoid horizontal page scrolling. Horizontal scrolling is permitted only for an intentional, discoverable component such as a compact carousel or a data table whose columns cannot reasonably be stacked.
- When a table is not usable on mobile, convert each record into a stacked, labeled layout without losing field names or actions.
- Keep primary actions reachable without requiring precision pointer movement.
- Prevent fixed headers, bottom bars and overlays from covering focused controls or content.

### 4.4 Density and first viewport

- Each major viewport should have one dominant task or message.
- Put the next relevant action or most important status before secondary summaries.
- Keep recommendation modules short and scannable; follow the approved product rules for their count.
- Avoid creating a separate card for every line of content.
- Avoid multiple competing calls to action in the same visual group.
- Use skeletons that match the dimensions of the final content to prevent layout shift.

### 4.5 Layout stability

- Reserve space for asynchronous content when practical.
- Keep changing numeric values in stable-width containers where visual jumping would be distracting.
- Avoid inserting content above the user's current reading or interaction position without preserving context.
- Do not change component dimensions between loading and loaded states unless the design explicitly calls for it.

---

## 5. Component standards

Build a small, reusable component library. Use the existing `design-system/components/COMPONENTS.md` for the Naranj-specific component variants and token mappings.

### 5.1 Buttons

Use a clear hierarchy:

- **Primary:** one dominant action in a task area.
- **Secondary:** important alternative action.
- **Tertiary / ghost:** low-emphasis actions that should not compete with the primary action.
- **Destructive:** irreversible or high-impact action, with clear wording and confirmation where appropriate.
- **Icon button:** only when the icon is unambiguous; always provide an accessible name.

Rules:

- Button labels start with a clear action verb where possible.
- Do not use vague labels such as “OK” when a specific action label is possible.
- Preserve button width during loading to avoid layout shift.
- Disabled buttons must have an understandable reason where the reason is not obvious.
- Do not place multiple primary buttons side by side.
- Do not use a button for navigation when a link is semantically correct.

### 5.2 Forms and inputs

- Every input has a persistent visible label.
- Placeholder text is supplementary and never replaces the label.
- Group related fields and use a logical reading and keyboard order.
- Put validation feedback adjacent to the relevant field.
- Associate error text programmatically with the input.
- Validate at a useful moment; avoid interrupting users with premature errors while they are still entering data.
- Preserve entered values after recoverable errors.
- Distinguish disabled from read-only states.
- Use appropriate input types, autocomplete and input modes.
- For numeric and mathematical entry, follow the approved question/component specification rather than substituting a generic text field.

### 5.3 Cards and panels

- Use cards to group related information or actions, not as a default wrapper for every element.
- Avoid card-inside-card nesting unless the information architecture requires it.
- Card titles should identify the content; primary actions should be easy to locate.
- Keep padding consistent within a component family.
- Use borders and surface contrast before adding shadows.
- Make the entire card clickable only when the card represents one clear destination. Do not nest independent interactive controls inside a fully clickable card without careful semantics.

### 5.4 Tables and data lists

- Use tables for comparison across consistent fields and records.
- Provide clear column headers and maintain alignment of numeric values.
- Do not communicate status with color alone; include a label or icon.
- Keep row actions predictable and discoverable.
- Support sorting and filtering only where the product scope requires them.
- On mobile, stack records or use a clearly indicated horizontal scroll when stacking would damage comparison.
- Do not imitate a spreadsheet for student-facing content unless the task genuinely requires tabular comparison.

### 5.5 Tabs, filters and chips

- Tabs switch between closely related views at the same hierarchy level.
- Do not use tabs as a substitute for global navigation.
- Filters must show their selected state and provide a clear way to remove or reset selections.
- Chips are for compact categories, filters or statuses; do not overload a card with them.
- Selected states must be conveyed by shape, border, label or icon as well as color.

### 5.6 Dialogs, popovers and menus

- Use dialogs for important decisions, destructive actions or short focused tasks.
- Use popovers for brief contextual information and lightweight controls.
- Use menus for a small set of related actions.
- Keep dialogs short and focused; do not turn them into a second full page.
- On mobile, use a near-full-width layout with safe margins.
- Dismissible dialogs must support Escape, keep focus inside while open and restore focus to the trigger when closed.
- Do not use hover-only popovers for essential information.

### 5.7 Feedback and notifications

Provide consistent patterns for:

- Success
- Error
- Warning
- Informational notice
- Inline validation
- Loading / pending
- Empty state
- No-results state

Rules:

- Use inline feedback for field-level errors.
- Use a persistent page-level message for important failures that affect the whole page.
- Use toast notifications only for brief, non-critical confirmations.
- A message must explain the event, not merely display a color-coded status.
- Where recovery is possible, provide the next action.
- Do not punish students visually for an incorrect answer.

### 5.8 Progress and status

- Progress bars must have an accessible name and a readable value or description.
- Use a consistent visual treatment for the same status across the product.
- Pair important progress visuals with text or numeric context.
- Do not imply precision beyond the underlying data.
- Reward styling must not obscure the actual learning status.

### 5.9 Empty, loading and error states

- Empty states explain why the area is empty and what action can resolve it.
- No-results states distinguish “nothing exists” from “the current filter found nothing.”
- Skeletons match final component geometry.
- Loading states must not create duplicate submissions.
- Error states preserve user input where possible and explain whether retrying is safe.
- Do not use decorative illustrations as a substitute for actionable guidance.

---

## 6. Interaction states and behavior

Every interactive component must define applicable states:

- Default
- Hover (pointer devices only)
- Focus-visible
- Pressed / active
- Selected
- Disabled
- Loading
- Success
- Error

Rules:

- Keyboard focus must remain visible.
- Hover must never be the only indication that an element is interactive.
- State changes must not rely on color alone.
- Use subtle transitions; avoid motion that delays task completion.
- Honor `prefers-reduced-motion`.
- Do not animate essential information into view if it would delay access.
- Prevent double submission while an action is pending.
- Provide immediate feedback after an action, while preserving the approved product behavior.

### 6.1 Motion

- Motion should clarify cause and effect, hierarchy or spatial continuity.
- Prefer short, restrained transitions.
- Avoid parallax, looping decoration and large movement in task-focused learning screens.
- Disable or reduce non-essential motion when the user requests reduced motion.
- Never communicate success, failure or progress exclusively through animation.

---

## 7. Accessibility baseline

Target **WCAG 2.2 Level AA** for the demo and production interface, subject to validation.

### 7.1 Keyboard and focus

- All interactive functionality must be operable by keyboard.
- Use semantic controls and a logical focus order.
- Provide a clearly visible focus indicator.
- Focus must not be obscured by sticky headers, dialogs or floating controls.
- Avoid keyboard traps except the intentional focus containment inside an open modal dialog.
- Support Escape for dismissible overlays and restore focus to the invoking control.

### 7.2 Touch and pointer

- Aim for touch targets of at least 44×44 CSS pixels.
- WCAG 2.2 AA includes a 24×24 CSS pixel minimum target-size criterion with exceptions; use 44×44 as the Naranj usability target where practical.
- Keep adequate spacing between adjacent targets.
- Do not require dragging when a click, tap or keyboard alternative can achieve the same result.
- Provide alternatives for complex pointer interactions where the question specification permits them.

### 7.3 Contrast and non-color cues

- Normal text contrast: at least 4.5:1.
- Large text contrast: at least 3:1.
- Relevant component boundaries, states and graphical objects: at least 3:1 where required.
- Never rely on color alone for correctness, status, selection or errors.
- Validate actual foreground/background combinations from the existing Naranj palette. Do not alter the palette in this document.
- If a current token pairing fails contrast, document the affected use and propose a token-role adjustment for approval; do not silently change brand colors.

### 7.4 Semantics and assistive technology

- Use semantic landmarks, headings, buttons, links, lists, tables and form controls.
- Maintain a logical heading hierarchy.
- Give icon-only controls accessible names.
- Provide text alternatives for meaningful images; decorative images should be ignored by assistive technology.
- Announce important asynchronous status changes appropriately without making every small update interruptive.
- Ensure error messages are associated with their controls.
- Do not use ARIA where native HTML semantics already provide the required behavior.

### 7.5 Persian, RTL and mixed-direction content

- Set the document language and direction correctly (`lang="fa"`, `dir="rtl"` for Persian screens).
- Use logical CSS properties.
- Isolate embedded Latin text, URLs, IDs and mixed-direction values with `bdi` or equivalent.
- Keep mathematical expressions in a math rendering layer with the correct internal direction.
- Verify punctuation, parentheses, decimal values, dates and mixed Persian/Latin labels in real rendered screens.
- Do not mirror non-directional icons.
- Provide meaningful labels for screen readers in Persian.

### 7.6 Cognitive accessibility

- Use plain, age-appropriate Persian.
- Keep instructions short and concrete.
- Avoid unnecessary memory load: show relevant context near the action.
- Use consistent wording for the same action.
- Avoid unexpected navigation or context loss.
- Break complex tasks into manageable steps only when consistent with the approved flow.
- Avoid excessive simultaneous alerts, badges, colors and animations.

---

## 8. Content and microcopy

- Use concise, natural Persian.
- Prefer action-oriented labels.
- Use the same term consistently for the same product concept.
- Avoid technical language in student-facing copy unless it is part of the learning content.
- Distinguish instructional feedback from system errors.
- Do not use blame-oriented language.
- Keep helper text close to the field or action it explains.
- Do not add new product claims, policies or learning rules in UI copy without an approved source.

---

## 9. Responsive QA and acceptance criteria

Test at minimum:

- 360px
- 390px
- 768px
- 1024px
- 1280px
- 1440px

### 9.1 Layout checks

- No unintended horizontal page overflow.
- Main content respects the grid and maximum width.
- Text does not clip or overlap.
- Cards reflow without awkward narrow columns.
- Navigation remains usable at each breakpoint.
- Sticky elements do not obscure content or keyboard focus.
- Tables remain understandable on narrow screens.
- Dialogs fit within viewport height and width.

### 9.2 Interaction checks

- Every visible control performs its advertised action.
- Keyboard navigation works in a logical order.
- Focus is visible in all relevant states.
- Loading prevents duplicate submissions.
- Errors are understandable and recoverable where possible.
- Empty and no-results states provide useful next steps.
- Reduced-motion preference is respected.

### 9.3 Accessibility checks

- Text and controls meet contrast requirements.
- Status is not conveyed by color alone.
- Inputs have labels and programmatically associated errors.
- Icon-only controls have accessible names.
- Screen-reader reading order matches the visual and logical order.
- RTL and mixed-direction content render correctly.

### 9.4 Definition of done

A page or component is ready when:

1. It follows the approved product flow without changing behavior.
2. It uses existing brand colors and typography without modification.
3. It follows the shared grid, spacing and component standards.
4. It works at the required viewport widths.
5. It defines all applicable interaction states.
6. It passes keyboard and basic accessibility checks.
7. It contains no invented product rules or unsupported UI destinations.

---

## 10. Reference synthesis — inspiration, not authority

The following sources informed the interface standards:

| Reference | Principles adapted | Explicitly not copied |
|---|---|---|
| Notion | Information hierarchy, modular grouping, calm content surfaces | Brand palette, typography, workspace identity |
| Airtable | Data density, tables, filters, scannable operational views | Spreadsheet-like density everywhere |
| Figma | Controlled emphasis, clear visual grouping, disciplined use of accent surfaces | Brand colors, typography, signature layouts |
| Intercom | Form states, feedback patterns, contextual help and interaction clarity | Product-specific conversation UI |
| Wise | Numeric clarity, status communication, compact data summaries | Financial-product visual identity |
| Shopify | Separation of public marketing and operational application surfaces | Dark cinematic marketing treatment and commerce-specific patterns |

Reference files are third-party analyses in the `awesome-design-md` repository, not official design specifications from the brands. Their values are not Naranj tokens.

---

## 11. Implementation instruction

Before implementing or modifying any page:

1. Read this file.
2. Read `design-system/layout/LAYOUT_SYSTEM.md`.
3. Read `design-system/components/COMPONENTS.md`.
4. Read the existing color and typography specifications without changing them.
5. Read UX Architecture v2.1 and the approved demo scope.
6. Implement the approved product behavior using the standards in this document.
7. If a conflict appears, stop and report it rather than silently changing product behavior, brand styling or flow.

**Final rule:** Improve the usability and implementation quality of Naranj without redesigning its identity or redefining its product.
