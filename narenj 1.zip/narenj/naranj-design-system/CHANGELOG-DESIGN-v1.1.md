# Design System v1.1

- Consolidated UI/UX standards into the root DESIGN.md.
- Added explicit authority rules protecting UX Architecture v2.1, approved flows, brand colors and typography.
- Added navigation, responsive layout, reusable component, interaction-state, accessibility, RTL and QA standards.
- Preserved all existing color, typography, font, layout-token and component files unchanged.

- Updated active Abar Low typography assets to exactly three weights (400/600/700) based on the current supplied font files.
- Rebalanced hierarchy to reduce visible weight contrast: Regular is dominant, SemiBold handles most hierarchy, Bold is reserved for rare emphasis.
- Removed ExtraBold and Black from active runtime font directories and tokens.
- Preserved the complete original design-system structure, color tokens, layout system, component standards, onboarding guide and implementation instructions.
