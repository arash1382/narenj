# Naranj Onboarding — Demo Specification

Version 1.0 · Proposed interaction flow

## Purpose

Introduce the student to Naranj, establish a friendly first-use experience and let them choose a mascot/avatar. Do not turn onboarding into a long profile questionnaire.

## Principles

- Short, skippable where optional.
- One decision per step.
- The user can understand where they are and what comes next.
- Avoid collecting unnecessary personal data.
- Use the approved Naranj mascot and avatar assets.
- No gender assumption based on avatar choice; avatar selection is cosmetic.
- Onboarding must not block access to practice if the product rules allow later completion.

## Proposed student flow

### Step 1 — Welcome
- Naranj mascot appears.
- Heading: «به نارنج خوش اومدی!»
- Supporting text: «اینجا می‌تونی با تمرین‌های کوتاه، مهارت‌های ریاضی‌ات رو قوی‌تر کنی.»
- Primary action: «شروع کنیم»
- Secondary action: «بعداً»

### Step 2 — Choose an avatar
- Heading: «دوست داری با کدوم آواتار وارد نارنج بشی؟»
- Show the ten approved avatar options (five girl and five boy designs) in a clear grid.
- Selecting an avatar highlights it with a visible border and check mark.
- Selection is not a statement about gender and must not change account permissions or content.
- Primary action: «ادامه»
- Secondary action: «بعداً انتخاب می‌کنم»

### Step 3 — Quick orientation
- 2–3 short panels:
  1. «تمرین‌های مناسب خودت رو پیدا کن»
  2. «پیشرفتت رو قدم‌به‌قدم ببین»
  3. «با انجام تمرین‌ها امتیاز و نشان بگیر»
- Use small mascot poses; avoid long explanatory text.
- Primary action: «بریم سراغ تمرین‌ها»

### Step 4 — Student home
- Route to Student Home.
- Show a compact first-task or recommendation entry.
- Do not add another setup form.

## Teacher onboarding

Teacher onboarding is separate and role-specific:
- Welcome and class context.
- Explain class switcher and current class.
- Guide the teacher to the first relevant action (view class, assign skill or create quiz) based on permissions.
- Do not show student avatar selection in teacher onboarding.

## Persistence and states

- Store completion state and avatar choice in the demo's local mock state.
- Allow avatar changes later from profile/settings.
- If onboarding is skipped, show a small non-blocking way to resume avatar selection.
- Handle loading and error states without losing the selected avatar.
- For the demo, mock persistence is acceptable; do not imply real authentication or server storage unless implemented.

## Responsive behavior

- Desktop/tablet: centered content panel with generous whitespace and avatar grid.
- Mobile: single-column flow; avatar grid may use 2 columns; buttons remain full-width or comfortably reachable.
- Respect reduced-motion preference.
