# Naranj Component System

Version 1.0 · Demo baseline · RTL-first

## General principles

- Every component has one clear purpose and predictable states.
- Prefer a small reusable component set over bespoke page-specific widgets.
- Keep touch targets at least 44×44px where practical.
- Provide visible keyboard focus.
- Use semantic HTML and accessible names.
- Never use color alone to communicate state.
- Use Abar Low for all Persian interface copy.
- Buttons and form controls must have hover, focus, pressed, disabled and loading states as applicable.

## Buttons

### Variants
1. Primary — orange fill, dark foreground (`#1F1D1A`), used for the single dominant action.
2. Secondary — teal fill, white foreground.
3. Tertiary — neutral surface or transparent with clear text.
4. Destructive — danger fill or outlined danger treatment.
5. Icon button — icon-only, with accessible label and tooltip where useful.

### Sizes
- Large: 48px height, horizontal padding 20px.
- Medium: 44px height, horizontal padding 16px.
- Small: 36px height, horizontal padding 12px.

Radius: 14px by default; pill only for special chips or explicitly playful actions.

States:
- Hover: darken fill one token step.
- Pressed: use active token and slight 1px downward feedback if motion is enabled.
- Focus: 2px visible teal focus ring with 2px offset.
- Disabled: muted fill/text and no hover response.
- Loading: preserve button width and label context; show compact progress indicator.

## Inputs

- Minimum height: 48px for standard fields.
- Label sits above field, not only as placeholder.
- Placeholder is a hint, never the only label.
- Default border: `border.default`; focus: `border.focus`.
- Error message appears adjacent to the field and is programmatically associated.
- Disabled and read-only states must be visually distinct.
- Support keyboard navigation and clear focus.

## Cards

- Standard radius: 18px.
- Standard padding: 20–24px desktop; 16px mobile.
- White raised surface on warm canvas.
- Border: 1px `border.default`.
- Use subtle shadow only when elevation is meaningful.
- Card title and primary action must be easy to locate.
- Do not nest cards inside cards without a strong information-architecture reason.

## Badges and chips

- Use compact pill shape.
- Use for status, category or filters only.
- Include text or icon + text; do not use color-only badges.
- Avoid too many chips in a single card.

## Navigation

- Desktop: stable role-specific navigation with clear active state.
- Mobile: show highest-frequency destinations first; overflow destinations in a secondary menu.
- Active item uses a soft brand tint and stronger label, not a large saturated block.
- Icon and label must have consistent alignment in RTL.

## Progress

- Use teal for neutral learning progress and primary orange for key progress emphasis.
- Gold reserved for rewards, medals and celebrations.
- Always pair progress bars with a numeric or textual description when the exact value matters.
- Use accessible text labels for progress values.

## Dialogs and popovers

- Dialogs for important decisions, destructive actions or focused short tasks.
- Popovers for lightweight contextual information.
- Keep dialog width readable; on mobile use near-full width with safe margins.
- Escape closes dismissible dialogs; focus is trapped and restored appropriately.

## Feedback and alerts

- Success, warning, danger and info use the semantic palette.
- Use a short title plus actionable description where needed.
- Incorrect practice answers should be pedagogical and encouraging, not punitive.
- Critical errors must not be communicated only through a toast.

## Tables and data lists

- Use tables only when comparing structured values.
- Prefer readable lists/cards for student-facing content.
- Keep row heights comfortable and avoid dense spreadsheet styling.
- On mobile, convert complex tables into stacked records or allow a carefully designed horizontal scroll with clear affordance.

## Skeletons and empty states

- Skeletons must mirror final layout dimensions.
- Empty states explain what is missing and offer one relevant next action.
- Use the Naranj mascot sparingly as a helper, not as decoration on every screen.

## Onboarding components

- Welcome panel with concise value proposition.
- Step indicator when onboarding has multiple steps.
- One question or decision per step.
- Back and Continue actions.
- Skip only when the step is optional.
- Progress must be visible and not falsely imply mandatory completion.
- Avatar selection uses equal-size avatar cards with selected border, check indicator and accessible selected state.
