# Active Abar Low Font Assets

The active runtime set is exactly:
- `AbarLow-Regular.woff2` — 400
- `AbarLow-SemiBold.woff2` — 600
- `AbarLow-Bold.woff2` — 700

Do not add or request synthetic weights. Load these via `design-system/typography/fonts.css` and adjust the URL only to match the app's canonical public font directory.
