# Naranj Typography System

**Version:** 1.1 · **Status:** Updated to current supplied font assets · **Language:** Persian-first · **Direction:** RTL

## 1. Font family and available files

Use **Abar Low** for all Persian interface text. The current approved/runtime font set contains exactly three weights:

| File | CSS weight | Primary role |
|---|---:|---|
| `AbarLow-Regular.woff2` | 400 | Reading, body copy, descriptions, question text, helper text |
| `AbarLow-SemiBold.woff2` | 600 | Main hierarchy: headings, labels, navigation, buttons and card titles |
| `AbarLow-Bold.woff2` | 700 | Rare, high-priority emphasis: key page title or important score/status |

Do not load or request 500, 800 or 900. Do not synthesize missing weights. `font-synthesis: none` must be set. The active font files are duplicated in `design-system/fonts/` and `public/fonts/` to support the supplied package structure; the app should load one canonical copy only.

## 2. Weight hierarchy — keep contrast restrained

The visual hierarchy must not look heavy or shouty. Most of the interface should use Regular 400. SemiBold 600 should do most of the hierarchy work. Bold 700 is a limited accent, not the default heading weight.

| Weight | Use | Avoid |
|---|---|---|
| 400 Regular | Body, descriptions, question text, helper text, secondary metadata, form values | Low contrast or undersized reading text |
| 600 SemiBold | Page/section headings, card titles, buttons, tabs, navigation, form labels when needed | Applying to every paragraph or all content in cards |
| 700 Bold | One dominant title, key score or a critical short status | Long text, multiple adjacent headings, every card title |

**Rule of thumb:** 400 carries content; 600 creates hierarchy; 700 creates rare emphasis.

Do not use weight as the only hierarchy signal. Combine size, line-height, spacing, position, surface and semantic labels.

## 3. Type scale

This scale preserves the existing compact Naranj scale while adapting the strongest heading weights to the three available files. It is a shared starting point, not a reason to force every page to use every level.

| Token | Size | Weight | Line height | Typical use |
|---|---:|---:|---:|---|
| Display | 36–40px | 700 | 1.25–1.35 | Rare welcome/onboarding title |
| H1 | 30–32px | 700 | 1.3–1.4 | Main page title |
| H2 | 24–26px | 600 | 1.35–1.45 | Major section heading |
| H3 | 20–22px | 600 | 1.4–1.5 | Card group / panel heading |
| H4 | 18px | 600 | 1.45–1.55 | Card title / subheading |
| Body Large | 17px | 400 | 1.75–1.85 | Introductory or important copy |
| Body | 15–16px | 400 | 1.7–1.8 | Default interface text |
| Body Small | 14px | 400 | 1.6–1.75 | Supporting descriptions |
| Label | 13–14px | 600 | 1.45–1.6 | Form labels, chips, compact controls |
| Caption | 12px | 400 | 1.5–1.6 | Secondary metadata only |
| Button | 15–16px | 600 | 1.2 | Button labels |

### Type-scale usage rules

- Do not use more than 4–5 distinct text hierarchy levels in one screen.
- Do not render every page title in Bold if the hierarchy is already clear with SemiBold.
- Prefer H1 600 for routine internal pages; reserve H1 700 for pages that need a strong anchor.
- Keep student practice screens especially calm: question text 400, supporting instructions 400, primary action 600.
- Keep teacher data surfaces readable; use size, alignment and whitespace before increasing weight.
- Do not reduce ordinary body text below 14px.
- On narrow screens, reduce oversized headings only when needed to prevent wrapping or crowding; preserve comfortable body text.

## 4. Numeric and mathematics typography

- Use tabular numerals for scores, timers, counts and progress values where supported (`font-variant-numeric: tabular-nums`).
- Use Persian digits in ordinary Persian UI by default, unless the question/math specification requires Latin digits or a specific numeral system.
- Render mathematical expressions, variables, operators and equations in a dedicated math layer; do not force Persian text shaping onto math glyphs.
- Mixed Persian/Latin strings must use direction isolation (`<bdi>` or equivalent).
- Keep SmartScore values and timers visually stable; reserve a fixed-width numeric area where values update.

## 5. Persian and RTL rules

- Set document language to `fa` and direction to `rtl` at the application shell.
- Align Persian paragraphs right by default.
- Do not reverse mathematical expressions, URLs, email addresses, English abbreviations or Latin identifiers.
- Use logical CSS properties (`margin-inline`, `padding-inline`, `inset-inline`, `border-inline`) instead of hardcoded left/right where possible.
- Do not use negative letter spacing as a general Persian typography trick.
- Avoid all-caps decorative labels.
- Keep headings short and line lengths comfortable.

## 6. Font loading

Load local WOFF2 files from `/fonts/` or the actual canonical public asset path. Use `font-display: swap`. Preload only the Regular font for the first screen unless a visible above-the-fold title genuinely requires SemiBold/Bold.

## 7. CSS

```css
@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-Regular.woff2") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
}

@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-SemiBold.woff2") format("woff2");
  font-style: normal;
  font-weight: 600;
  font-display: swap;
}

@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-Bold.woff2") format("woff2");
  font-style: normal;
  font-weight: 700;
  font-display: swap;
}

:root {
  --naranj-font-family: "Abar Low", Tahoma, sans-serif;
  --font-weight-regular: 400;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
}

html[lang="fa"],
html[dir="rtl"],
body {
  font-family: var(--naranj-font-family);
  font-synthesis: none;
}
```

Adjust the URL to the actual public asset location; do not duplicate font loading from multiple CSS files.

## 8. Acceptance checks

- Exactly three active font files are loaded: Regular 400, SemiBold 600, Bold 700.
- No 500, 800 or 900 font weight is requested in CSS or components.
- Browser font synthesis is disabled.
- Regular is the dominant reading weight.
- SemiBold provides most hierarchy.
- Bold is used sparingly.
- Persian hierarchy remains clear at 360, 390, 430, 768, 1024, 1280 and 1440px.
- Buttons, forms, question text, mathematical notation and navigation are checked with real Persian content.
