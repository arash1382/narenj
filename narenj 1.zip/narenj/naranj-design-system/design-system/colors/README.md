# Naranj Color System

**Version:** 1.0.0  
**Status:** Proposed baseline for the first demo  
**Theme:** Light  
**Product:** نارنج (Naranj)

This folder is the source of truth for color decisions in the Naranj demo. Use semantic tokens in UI code; do not invent one-off colors when an existing token fits.

## Files

- `tokens/color.tokens.json` — structured color token source.
- `tokens/color.css` — CSS custom properties for implementation.
- `COLOR_SYSTEM.md` — usage rules, roles, states and accessibility guidance.

## Core palette

| Role | Token | Hex | Use |
|---|---|---:|---|
| Primary | `brand.primary.500` | `#E9782B` | Main brand orange, primary actions and key highlights |
| Primary dark | `brand.primary.600` | `#D9651B` | Hover/pressed states and stronger emphasis |
| Secondary | `brand.secondary.500` | `#218C83` | Supporting actions, links, progress and selected supporting elements |
| Accent | `brand.accent.400` | `#F2C14E` | Rewards, stars and small celebratory accents |
| Main text | `text.primary` | `#2E2B27` | Main readable text |
| Page background | `surface.canvas` | `#FAF9F6` | Warm neutral application canvas |

## Implementation rules

1. Use `var(--naranj-...)` CSS variables from `tokens/color.css`.
2. Prefer semantic tokens (`--naranj-text-primary`, `--naranj-surface-page`) over raw palette steps.
3. Orange is the primary brand color; teal is the secondary color. Yellow is an accent, not a second primary.
4. Use semantic status colors only for their actual meaning: success, warning, danger and informational feedback.
5. Never communicate status by color alone; pair it with text, iconography or another visual cue.
6. Do not use the saturated brand orange for long paragraphs or small text.
7. Preserve contrast and focus visibility in every interactive state.
8. The default demo theme is light. Do not invent a dark theme unless it is explicitly scoped.

## AI agent instruction

Read `COLOR_SYSTEM.md` and `tokens/color.tokens.json` before implementing UI. Treat these tokens as authoritative. If a required color role is missing, propose a token addition rather than hardcoding a random value.
