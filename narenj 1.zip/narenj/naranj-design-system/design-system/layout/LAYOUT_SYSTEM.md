# Naranj Layout & Spatial System

Version 1.0 · Demo baseline

## Design intent

Naranj should feel spacious and easy to scan, not empty or wasteful. Use whitespace to separate tasks, create hierarchy and reduce cognitive load. The visual references are used for product-design principles, not copied layouts: clear grouping, high-frequency actions easy to find, concise labels, predictable navigation and relevant content density.

A useful Snapp redesign case study describes grouping related services, prioritizing high-value content in the first viewport, and avoiding irrelevant content density. Apply the general lesson to Naranj: prioritize the student's next learning action and keep secondary material subordinate. Do not reproduce Snapp's service grid or navigation pattern. Source: https://virgool.io/snapp-eng/داستان-یک-همکاری-بازطراحی-صفحهٔ-اصلی-سوپراپلیکیشن-اسنپ-awkg6aww6edt

Bama is a reference for task-oriented browsing and structured information, not for copying marketplace-specific filters or dense listing layouts. Naranj is a learning product; its interface must remain calmer and more guided than a vehicle marketplace.

## Grid

### Desktop
- 12-column grid.
- Maximum content width: 1200px.
- Wide desktop outer gutters: 40px.
- Standard desktop outer gutters: 32px.
- Column gap: 24px.
- Main dashboard content should use a readable max width rather than stretching every card edge-to-edge.

### Tablet
- 8-column grid.
- Outer gutters: 24px.
- Column gap: 20px.

### Mobile
- 4-column grid.
- Outer gutters: 16px.
- Column gap: 12px.
- Avoid horizontal scrolling except for intentional compact carousels.

## Spacing scale

Base unit: 4px.

| Token | Value | Typical use |
|---|---:|---|
| 0 | 0px | Reset |
| 1 | 4px | Icon/text micro gap |
| 2 | 8px | Tight internal gap |
| 3 | 12px | Compact component padding |
| 4 | 16px | Standard component gap |
| 5 | 20px | Form and card spacing |
| 6 | 24px | Standard section/card padding |
| 8 | 32px | Large component gap |
| 10 | 40px | Section spacing |
| 12 | 48px | Major section spacing |
| 16 | 64px | Page section separation |
| 20 | 80px | Large desktop separation |

Use 8px or 16px rhythm most often. Do not inflate every card just to create a premium feeling.

## Radius

| Token | Value | Use |
|---|---:|---|
| xs | 6px | Small tags, compact chips |
| sm | 10px | Inputs, small controls |
| md | 14px | Buttons, small cards |
| lg | 18px | Standard cards |
| xl | 24px | Large cards, panels |
| 2xl | 28px | Hero and onboarding panels |
| pill | 999px | Pills, avatar chips, fully rounded buttons |

Use rounded geometry consistently, but avoid making every surface a pill. Inputs should remain easy to scan and not overly bubbly.

## Shadows

| Token | CSS | Use |
|---|---|---|
| none | `none` | Default flat surfaces |
| xs | `0 1px 2px rgba(31,29,26,.05)` | Subtle card separation |
| sm | `0 2px 8px rgba(31,29,26,.06)` | Raised cards |
| md | `0 8px 24px rgba(31,29,26,.08)` | Popovers / menus |
| lg | `0 16px 40px rgba(31,29,26,.12)` | Modal / overlay |

Prefer borders and surface contrast over heavy shadows. Shadows should describe elevation, not decorate every component.

## Breakpoints

| Name | Width | Layout |
|---|---:|---|
| mobile | 0–599px | 4 columns |
| tablet | 600–899px | 8 columns |
| desktop | 900–1199px | 12 columns |
| wide | 1200px+ | 12 columns, max content width 1200px |

Treat these as initial implementation breakpoints. Test at 360, 390, 768, 1024, 1280 and 1440px. Do not design only for a single desktop viewport.

## Density and whitespace rules

- One dominant task per page or major viewport.
- Dashboard first viewport: greeting/context, next action or nearest deadline, then a small number of secondary summaries.
- Avoid more than 3–5 recommendation items in the initial home view.
- Group related data into sections; do not create a card for every line of text.
- Keep section headings and content close enough to read as a group.
- Use larger vertical spacing between sections than between items inside a section.
- Keep primary actions visually obvious and secondary actions quiet.
- Use skeletons with the same dimensions as final content to avoid layout shift.

## Navigation

- Student and teacher shells must be distinct where their tasks differ.
- Keep global navigation stable across pages.
- Show the current location clearly.
- Do not put the focused practice session inside the general navigation.
- On mobile, prioritize the most frequently used destinations and keep secondary destinations in a compact menu.
