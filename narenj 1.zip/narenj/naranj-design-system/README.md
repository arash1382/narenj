# Naranj Demo — Design System Package

This package contains the first implementation-ready design-system baseline for Naranj.

## Included
- `DESIGN.md` — visual and interaction source of truth for AI agents.
- `design-system/colors/` — full color system, JSON tokens and CSS variables.
- `design-system/typography/` — Abar Low font files, type scale and font-face CSS.
- `design-system/layout/` — grid, spacing, radius, shadow and responsive rules.
- `design-system/components/` — reusable component behavior and visual states.
- `design-system/tokens/design-tokens.json` — consolidated non-color tokens.
- `product/ONBOARDING.md` — proposed student and teacher onboarding.
- `agent/IMPLEMENTATION_GUIDELINES.md` — agent implementation contract.

## Font
Abar Low is the required Persian UI family. Exactly three active weights are included locally: Regular 400, SemiBold 600 and Bold 700. The type hierarchy is intentionally restrained; 400 is dominant, 600 handles most hierarchy, and 700 is reserved for rare emphasis.

## Install/use
Copy the `design-system/fonts/` files to the app's public font directory or preserve the provided path and adjust the CSS URL consistently. Import:
- typography: `design-system/typography/fonts.css`
- layout: `design-system/layout/layout-tokens.css`
- color variables from the previously prepared Naranj color package.

## Status
This is a demo baseline, not final production sign-off. The UX Architecture v2.1 remains the authority for product behavior. The onboarding flow is a proposed design recommendation and should be reviewed against the confirmed product scope.
