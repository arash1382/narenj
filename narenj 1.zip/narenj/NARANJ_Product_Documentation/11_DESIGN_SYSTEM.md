# NARANJ — Design System & UI Foundations

**Status:** Consolidated implementation reference based on approved Naranj design sources.
**Scope:** Visual tokens, layout, typography, components, interaction states, responsiveness, RTL, accessibility and QA.
**Precedence:** Existing brand tokens and source design decisions override generic design advice. This document does not redefine product behavior.

## 1. System principles

- Mobile-first and Persian RTL by default.
- One clear primary action per page or section.
- Visually rich brand expression; cognitively light functional interface.
- Use semantic tokens rather than hard-coded one-off colors.
- Reuse components and spacing rules consistently.
- Provide complete interaction states and responsive behavior.
- Preserve approved mascot, avatars, illustrations and font assets.



## 4. Visual experience system

### 4.1 Visual personality

The desired direction combines:

- A polished, friendly educational product.
- Strong and clear information hierarchy.
- A recognizable 3D visual identity.
- Controlled use of vivid brand colors.
- Soft, tactile depth and layered surfaces.
- Simple, highly legible functional UI.

Avoid generic dashboard aesthetics, excessive glassmorphism, random gradients, childish clip-art, overused blobs, or a collection of unrelated 3D stock illustrations.

### 4.2 3D visual language

3D must be a coherent visual system. It should appear consistently in selected high-value moments rather than being scattered randomly across every component.

#### Recommended 3D use cases

- Student avatar and avatar selection.
- Naranj mascot and key brand moments.
- Empty states where a character can help explain the next action.
- Achievement and reward moments.
- Selected learning milestones.
- Onboarding illustrations.
- A small number of student-home highlights.

#### 3D restraint rules

- Do not put a 3D object in every card.
- Do not use 3D behind dense text or math questions.
- Do not let 3D overlap labels, buttons, formulas or answer controls.
- Keep silhouettes and facial expressions readable at mobile sizes.
- Use consistent lighting, camera perspective, material quality and shadow softness.
- Avoid mixing photorealistic 3D with flat cartoon illustrations without a deliberate art-direction rule.
- Use 3D as a visual anchor, not as a substitute for information architecture.
- Do not use continuous 3D animation in the practice question area.
- Provide static or reduced-motion alternatives.

#### 3D quality direction

Preferred qualities:

- Soft, rounded forms.
- Tactile but restrained materials.
- Friendly, expressive characters.
- Controlled highlights and soft shadows.
- Clear silhouettes.
- Consistent scale and camera angle.
- Warm, approachable lighting.
- High-quality rendering without excessive realism.

The exact rendering style should be established through a small approved visual exploration before producing a large asset library.

### 4.3 Color usage and visual energy

The existing Naranj palette is authoritative. Do not invent a replacement palette or alter approved brand values.

Improve perceived color richness through **better composition and semantic application**:

- Use existing primary and secondary colors for meaningful emphasis.
- Use approved tints and shades only if they already exist in the token system or are explicitly approved.
- Use neutral surfaces to create breathing room around stronger colors.
- Give each major student-facing area a clear color role; do not make every card a different bright color.
- Use color to distinguish action, progress, category or feedback only when that meaning is consistent.
- Keep body text and question content highly legible.
- Verify contrast for every foreground/background pairing.
- Never communicate correctness, status or selection through color alone.

The visual result should feel more colorful and alive than the current interface, but not noisy.

### 4.4 Shape, depth and surfaces

- Use a consistent radius scale.
- Use surface contrast and spacing before adding shadows.
- Reserve stronger elevation for floating or interactive elements.
- Avoid excessive borders around every block.
- Use layered surfaces sparingly to create depth.
- Keep input fields and answer components visually stable and highly legible.
- Do not use decorative outlines that make the page look fragmented.

### 4.5 Illustration and iconography

- Use one coherent illustration language.
- Prefer custom Naranj assets and mascot/avatar assets over generic stock artwork.
- Icons must be recognizable and consistent in stroke, fill and optical size.
- Do not use emoji as a replacement for core product iconography.
- Decorative illustrations must not carry essential information by themselves.

---

## 7. Mobile-first responsive system

### 7.1 Required design order

Design and validate in this order:

1. 360px mobile.
2. 390px mobile.
3. 430px large mobile.
4. 768px tablet.
5. 1024px laptop.
6. 1280px desktop.
7. 1440px wide desktop.

Do not design a desktop page and then merely stack its cards for mobile.

### 7.2 Mobile requirements

- Single-column composition for most student surfaces.
- Primary actions must be reachable without precision pointer movement.
- Avoid horizontal page scrolling.
- Keep touch targets at least 44×44 CSS px where practical.
- Avoid fixed elements covering content or keyboard focus.
- Keep the most important action in a predictable location.
- Use bottom navigation only if it is already supported by the approved information architecture; do not add it as a new destination model without approval.
- Use compact, readable cards and lists.
- Keep page headings concise.
- Avoid multi-column metric dashboards on mobile.
- Use accordions or detail routes for secondary information.
- Keep practice question content within a stable, distraction-free frame.

### 7.3 Tablet and desktop

- Scale the same information hierarchy; do not introduce new content just because space is available.
- Use additional width for readable grouping and comparison, not for showing every module at once.
- Keep long text at a controlled measure.
- Use multi-column layouts only when the content benefits from side-by-side comparison.
- Maintain a clear main content area and predictable navigation.
- On wide screens, avoid stretching cards and paragraphs across the entire viewport.

### 7.4 Grid and spacing

Existing layout tokens remain the source of truth. The previous design baseline used a 4px spacing foundation and responsive grids. Do not invent conflicting values.

If the existing token files are missing or inconsistent, report the issue before creating new global tokens.

---

## 8. Typography, Persian and RTL

- Preserve the approved Naranj Persian and English font assignments and local font files.
- Persian is the default language and RTL is the default direction.
- Use CSS logical properties.
- Keep text hierarchy clear through size, weight, spacing and line-height, not color alone.
- Do not use too many font sizes or weights on one page.
- Keep student-facing copy short, concrete and age-appropriate.
- Use consistent Persian terminology for product concepts.
- Handle mixed Persian/Latin text, URLs, IDs, numbers, dates and mathematical expressions correctly.
- Do not mirror non-directional icons.
- Mathematical notation must follow the approved math rendering and direction rules.
- Verify real Persian copy in rendered UI; placeholder Latin copy is not an adequate RTL test.

---

## 9. Core component behavior and visual standards

Use the existing component library and tokens. Extend components only when a real product need requires it.

### 9.1 Cards

- A card must represent a meaningful content group or action.
- Do not turn every paragraph, number or label into its own card.
- Avoid nested cards.
- Use a clear title and one dominant action at most.
- Keep card content short and scannable.
- Do not make a card fully clickable if it contains multiple independent actions.

### 9.2 Buttons

- One primary button per task area.
- Use specific action labels.
- Secondary and tertiary actions must be visually quieter.
- Preserve button dimensions during loading.
- Disabled states must explain why when the reason is not self-evident.
- Never use a button style for ordinary navigation links.

### 9.3 Forms

- Every input has a persistent visible label.
- Place errors next to the relevant input.
- Preserve values after recoverable errors.
- Keep forms focused and group related fields.
- Do not expose unnecessary fields in the initial view.
- Use progressive disclosure for optional or advanced fields.

### 9.4 Tables and lists

- Use tables for comparison and structured teacher workflows.
- Respect the maximum 6-column guidance from UXA v2.1.
- On mobile, stack records or use an intentional, discoverable horizontal-scroll pattern.
- Do not use spreadsheet-like tables for student learning content unless required by the task.

### 9.5 Progress and status

- Pair progress visuals with clear labels or values.
- Use consistent status language and appearance.
- Do not imply precision unsupported by data.
- Never show missing data as zero.
- Keep progress and reward systems from competing with the primary task.

### 9.6 Feedback, empty and error states

Every page must define relevant states:

- Initial
- Loading
- Empty
- No results
- Success
- Error
- Offline
- Submitting / Pending
- Saved
- Permission denied
- Expired session
- Completed

Follow UXA v2.1 system-state rules:

- Never claim an action was saved before server confirmation.
- Never show zero as a replacement for unavailable data.
- Explain what happened, what was preserved and what the user can do next.
- Do not use raw technical error codes in user-facing copy.
- Preserve entered data where recovery is possible.

---

## 12. Motion and interaction

Motion must support orientation, feedback and continuity.

### 12.1 Allowed motion roles

- Short transitions between related states.
- Small hover/press feedback on pointer devices.
- Meaningful achievement moments.
- Subtle 3D character idle motion in non-critical contexts.
- Guided-tour transitions that clarify the current step.

### 12.2 Disallowed or discouraged

- Continuous decorative movement near questions.
- Large parallax effects on task-focused pages.
- Repeated confetti or full-screen reward interruptions.
- Long transitions that delay a primary action.
- Motion as the only signal of success or failure.
- Auto-advancing educational feedback.

Honor `prefers-reduced-motion` and provide static alternatives.

---

## 13. Accessibility, safety and age-appropriate design

Target WCAG 2.2 AA, subject to validation.

- Minimum text and component contrast must be verified against actual tokens.
- Do not communicate status through color alone.
- Use semantic controls and logical keyboard order.
- Make focus visible and unobscured.
- Provide accessible names for icon-only controls.
- Keep touch targets at least 44×44 CSS px where practical.
- Use age-appropriate Persian.
- Avoid manipulative urgency, shame, public comparison or pressure.
- Do not use streaks, goals or rewards to punish absence.
- Avoid excessive notifications and attention-grabbing animations.
- Do not expose one student's performance to other students.
- Do not use avatar appearance to infer academic ability or personal traits.

---

## 14. Performance and implementation constraints

The 3D direction must not compromise performance or task completion.

- Prefer optimized, appropriately sized assets.
- Lazy-load non-critical 3D and illustration assets.
- Avoid loading large 3D scenes on every page.
- Use static image fallbacks where needed.
- Avoid unnecessary layout shifts.
- Keep interactions responsive on mid-range mobile devices.
- Do not block the first meaningful interaction while decorative assets load.
- Test the practice flow with 3D and decorative assets disabled; core functionality must remain complete.
- Use existing project technology and architecture unless an explicit technical change is approved.

**[TECHNICAL VALIDATION]** Performance budgets, asset formats, device test matrix and loading thresholds must be agreed with engineering.

---

## 16. Acceptance criteria

The redesign is not successful merely because it looks more colorful or uses 3D.

It is successful when:

1. The primary task on each page is immediately understandable.
2. The first mobile viewport is visibly less crowded than the current version.
3. Secondary information is available without competing with the primary task.
4. No approved product capability or business rule has been silently removed or changed.
5. Student pages feel engaging but remain calm and focused.
6. Teacher pages are scannable and operationally efficient.
7. 3D assets are consistent, purposeful and performant.
8. Existing brand colors and typography remain intact.
9. Mobile layouts are designed intentionally and work without horizontal page overflow.
10. Practice remains distraction-free and follows all approved session rules.
11. Gamification supports personal progress and never introduces public ranking.
12. Every implemented page includes the relevant loading, empty, error and success states.
13. Persian, RTL, mixed-direction content and mathematical notation are verified in the actual UI.
14. All visible controls work as labeled.
15. The project builds and runs without new errors.

---

## 2. Approved color system

## Source: `COLOR_SYSTEM.md`

# Naranj — Color System Specification

**Version:** 1.0.0  
**Status:** Proposed design-system baseline for demo implementation  
**Language:** Token names are English for code consistency; product content is Persian (RTL).

## 1. Color direction

Naranj should feel warm, optimistic, energetic and trustworthy without looking like a toy interface. The palette combines a mature citrus orange with a calm teal, warm neutrals and a restrained golden accent.

- **Primary orange:** `#E9782B` — medium-depth, warm, recognizably citrus. It is neither fluorescent nor brown/dark.
- **Secondary teal:** `#218C83` — balances the orange and supports learning, navigation and progress states.
- **Accent yellow:** `#F2C14E` — used sparingly for rewards, stars and celebratory moments.
- **Warm neutral scale:** reduces the clinical feel of pure grey and supports long learning sessions.

The selected palette is a proposed starting point for the demo. It should be validated against the actual logo, mascot renders and representative screens before being treated as immutable brand governance.

## 2. Brand palette

### Primary — Citrus Orange

| Token | Hex | Intended role |
|---|---|---|
| `primary.50` | `#FFF6EF` | Very soft orange-tinted surface |
| `primary.100` | `#FCE9DA` | Selected backgrounds, subtle highlights |
| `primary.200` | `#F8D1B5` | Soft borders and decorative fills |
| `primary.300` | `#F3B287` | Illustration accents, disabled fills |
| `primary.400` | `#ED9257` | Secondary emphasis |
| `primary.500` | `#E9782B` | Main brand orange |
| `primary.600` | `#D9651B` | Hover / stronger emphasis |
| `primary.700` | `#B94F14` | Active / pressed |
| `primary.800` | `#943F12` | Deep brand accent |
| `primary.900` | `#71320F` | Deepest orange tone |

**Use `primary.500` for:** primary CTA fills when paired with a sufficiently dark foreground, brand marks, active progress accents and key highlights.  
**Do not use it for:** long text, large uninterrupted page backgrounds, or tiny orange text on white.

### Secondary — Learning Teal

| Token | Hex | Intended role |
|---|---|---|
| `secondary.50` | `#EFF9F7` | Teal-tinted surface |
| `secondary.100` | `#D9F0EC` | Selection and information panels |
| `secondary.200` | `#B5E1DA` | Soft borders |
| `secondary.300` | `#83C9BE` | Supporting graphics |
| `secondary.400` | `#4EAA9D` | Mid-tone accent |
| `secondary.500` | `#218C83` | Secondary actions and supporting highlights |
| `secondary.600` | `#18756E` | Hover / links |
| `secondary.700` | `#155E59` | Active / pressed |
| `secondary.800` | `#144C49` | Deep accent |
| `secondary.900` | `#123F3D` | Deepest teal |

Use teal to balance orange. It can identify secondary actions, links, progress indicators and selected supporting navigation. Do not make every component two-tone.

### Accent — Citrus Gold

| Token | Hex | Intended role |
|---|---|---|
| `accent.50` | `#FFFAE8` | Reward background |
| `accent.100` | `#FFF1C2` | Soft celebratory surface |
| `accent.200` | `#FBE18A` | Stars and badges |
| `accent.300` | `#F5D05D` | Illustration highlights |
| `accent.400` | `#F2C14E` | Main accent gold |
| `accent.500` | `#DFA92D` | Stronger gold accent |
| `accent.600` | `#B9851F` | Deep gold |
| `accent.700` | `#8E641B` | Deepest gold |

Gold is a **limited accent**, mainly for coins, stars, rewards and success celebrations. It is not a competing primary color.

## 3. Neutral palette

| Token | Hex | Intended role |
|---|---|---|
| `neutral.0` | `#FFFFFF` | Pure white |
| `neutral.50` | `#FAF9F6` | App canvas |
| `neutral.100` | `#F3F1EC` | Subtle panels |
| `neutral.200` | `#E7E3DC` | Default borders / dividers |
| `neutral.300` | `#D5D0C7` | Strong borders |
| `neutral.400` | `#AAA49A` | Disabled text / icons |
| `neutral.500` | `#79736B` | Tertiary text |
| `neutral.600` | `#5F5A53` | Secondary text |
| `neutral.700` | `#45413C` | Strong text |
| `neutral.800` | `#2E2B27` | Primary text |
| `neutral.900` | `#1F1D1A` | Highest emphasis |
| `neutral.950` | `#141311` | Deep inverse surfaces |

Warm neutrals are the default foundation. Avoid using pure black for ordinary text and avoid stacking too many subtly different grey surfaces.

## 4. Semantic status colors

Status colors communicate meaning and must not be used as decoration.

### Success

- Background: `#EFF8F1` (`success.50`)
- Soft background: `#D9EEDC` (`success.100`)
- Main: `#2F855A` (`success.500`)
- Hover / strong: `#276C4A` (`success.600`)
- Deep: `#20583D` (`success.700`)

Use for correct answers, completed tasks, saved confirmation and positive progress.

### Warning

- Background: `#FFF7E8` (`warning.50`)
- Soft background: `#FCE8BF` (`warning.100`)
- Main: `#A96812` (`warning.500`)
- Hover / strong: `#87520E` (`warning.600`)
- Deep: `#68400D` (`warning.700`)

Use for approaching deadlines, caution, incomplete steps and non-blocking attention.

### Danger / Error

- Background: `#FFF1F0` (`danger.50`)
- Soft background: `#F8DAD7` (`danger.100`)
- Main: `#C4473A` (`danger.500`)
- Hover / strong: `#A9362D` (`danger.600`)
- Deep: `#852B25` (`danger.700`)

Use for validation errors, failed actions, destructive actions and critical problems. Do not use danger red for ordinary incorrect practice answers if the learning feedback should remain encouraging; use neutral instructional feedback or a gentle warning treatment where appropriate.

### Information

- Background: `#EFF6FD` (`info.50`)
- Soft background: `#DCEBFA` (`info.100`)
- Main: `#3478B8` (`info.500`)
- Hover / strong: `#285F95` (`info.600`)
- Deep: `#204B75` (`info.700`)

Use for tips, system information, help messages and neutral notices.

## 5. Semantic UI tokens

### Surfaces

| Token | Hex | Use |
|---|---|---|
| `surface.canvas` | `#FAF9F6` | Overall app background |
| `surface.page` | `#FFFFFF` | Main content surface |
| `surface.subtle` | `#F3F1EC` | Quiet grouped content |
| `surface.raised` | `#FFFFFF` | Cards, menus, popovers |
| `surface.sunken` | `#EDEAE4` | Inset controls and recessed regions |
| `surface.inverse` | `#2E2B27` | Dark contrast panel |

### Text

| Token | Hex | Use |
|---|---|---|
| `text.primary` | `#2E2B27` | Main body and heading text |
| `text.secondary` | `#5F5A53` | Supporting copy |
| `text.tertiary` | `#79736B` | Metadata; check contrast for small text |
| `text.disabled` | `#AAA49A` | Disabled labels only; not essential information |
| `text.inverse` | `#FFFFFF` | Text on sufficiently dark surfaces |
| `text.link` | `#18756E` | Inline links |
| `text.linkHover` | `#155E59` | Hovered links |
| `text.onPrimary` | `#1F1D1A` | Foreground on primary orange |
| `text.onSecondary` | `#FFFFFF` | Foreground on secondary teal |
| `text.onDanger` | `#FFFFFF` | Foreground on danger |
| `text.onSuccess` | `#FFFFFF` | Foreground on success |
| `text.onInfo` | `#FFFFFF` | Foreground on info |

### Borders and focus

| Token | Hex | Use |
|---|---|---|
| `border.default` | `#E7E3DC` | Standard component borders |
| `border.strong` | `#D5D0C7` | High-emphasis borders |
| `border.subtle` | `#F3F1EC` | Subtle separators |
| `border.focus` | `#218C83` | Focused controls |
| `focus.ring` | `#218C83` | Keyboard focus ring |
| `focus.ringOnDark` | `#F5D05D` | Focus ring on dark surfaces |

### Interactive states

| Component state | Token | Hex |
|---|---|---|
| Primary default | `interactive.primary` | `#E9782B` |
| Primary hover | `interactive.primaryHover` | `#D9651B` |
| Primary pressed | `interactive.primaryActive` | `#B94F14` |
| Primary disabled fill | `interactive.primaryDisabled` | `#F3B287` |
| Secondary default | `interactive.secondary` | `#218C83` |
| Secondary hover | `interactive.secondaryHover` | `#18756E` |
| Secondary pressed | `interactive.secondaryActive` | `#155E59` |
| Secondary disabled fill | `interactive.secondaryDisabled` | `#83C9BE` |
| Selected background | `interactive.selection` | `#FCE9DA` |
| Selected border | `interactive.selectionBorder` | `#E9782B` |

Disabled controls should also have reduced emphasis and must not be the only way to communicate availability. Do not rely on color alone to distinguish hover, pressed, selected or disabled states.

## 6. Recommended component mapping

| UI element | Recommended color treatment |
|---|---|
| Main CTA | Primary orange with `text.onPrimary` |
| Secondary CTA | Teal with white text |
| Tertiary button | Neutral surface with primary/teal text |
| Navigation active item | `primary.50` surface + `primary.700` text or teal treatment |
| Links | `text.link` |
| Main page | `surface.canvas` |
| Cards | `surface.raised` |
| Card borders | `border.default` |
| Input default | White surface + `border.strong` |
| Input focus | `border.focus` + visible focus ring |
| Input error | Danger border + danger helper text |
| Correct answer | Success treatment, icon and explicit confirmation |
| Incorrect answer | Supportive feedback; avoid harsh red as the default |
| Progress | Teal or primary orange; define meaning consistently |
| Coins / stars / rewards | Accent gold |
| Deadline approaching | Warning |
| Critical system error | Danger |

## 7. Accessibility and contrast rules

Target WCAG 2.2 AA:

- Normal text: contrast ratio at least **4.5:1**.
- Large text: at least **3:1**.
- Meaningful UI boundaries and graphical controls: at least **3:1** against adjacent colors where WCAG requires it.
- Keyboard focus must be clearly visible.
- Never convey correctness, status, selection or errors by color alone.

Important practical note: the primary orange `#E9782B` is a brand color, not a safe white-text background for small text. Use dark `text.onPrimary` on it. For a white-text orange button, use the deeper `primary.700` (`#B94F14`) and validate contrast in implementation.

Recommended foreground pairings:
- `#2E2B27` on `#FFFFFF` or `#FAF9F6`.
- `#1F1D1A` on `#E9782B`.
- `#FFFFFF` on `#18756E`.
- `#FFFFFF` on `#276C4A`.
- `#FFFFFF` on `#A9362D`.
- `#FFFFFF` on `#285F95`.

Do not use `neutral.400` or `neutral.500` for essential small text on white without checking contrast.

## 8. Usage proportions

A useful starting balance for typical screens:

- 65–75% warm neutral surfaces.
- 15–20% primary orange and its tints.
- 8–12% secondary teal and its tints.
- 2–5% accent gold and semantic colors.

These are visual balancing guidelines, not strict per-screen quotas.

## 9. Design consistency rules

1. Orange owns the brand. Teal supports it. Gold celebrates.
2. Keep large surfaces neutral; reserve saturated colors for actions, feedback and meaningful emphasis.
3. Use one dominant colored action per screen whenever possible.
4. Use semantic colors consistently across the student and teacher experiences.
5. Keep all status colors paired with labels/icons.
6. Do not introduce new hex values directly in components. Add a named token first.
7. For illustrations and the mascot, colors may be more expressive, but interactive UI must follow semantic tokens.
8. The demo uses a light theme baseline. Dark mode is not included in this specification.

## 10. Open validation items

Before final design-system sign-off:
- Test the palette against the final Naranj logo and mascot.
- Check contrast in actual button, input, badge, chart and feedback components.
- Validate colors on common laptop and tablet displays.
- Confirm whether the final product needs a dark theme.
- Review semantic feedback colors with the educational team, especially the treatment of incorrect answers.

Until these checks are complete, treat this as **Color System v1.0 — Demo Baseline**, not immutable brand specification.

## 3. Existing token references

## Source file: `naranj-color-system/tokens/color.tokens.json`

```json
{
  "$schema": "https://design-tokens.github.io/community-group/format/",
  "name": "Naranj Color System",
  "version": "1.0.0",
  "description": "Color tokens for the Naranj educational platform. Light theme baseline.",
  "color": {
    "brand": {
      "primary": {
        "50": "#FFF6EF",
        "100": "#FCE9DA",
        "200": "#F8D1B5",
        "300": "#F3B287",
        "400": "#ED9257",
        "500": "#E9782B",
        "600": "#D9651B",
        "700": "#B94F14",
        "800": "#943F12",
        "900": "#71320F"
      },
      "secondary": {
        "50": "#EFF9F7",
        "100": "#D9F0EC",
        "200": "#B5E1DA",
        "300": "#83C9BE",
        "400": "#4EAA9D",
        "500": "#218C83",
        "600": "#18756E",
        "700": "#155E59",
        "800": "#144C49",
        "900": "#123F3D"
      },
      "accent": {
        "50": "#FFFAE8",
        "100": "#FFF1C2",
        "200": "#FBE18A",
        "300": "#F5D05D",
        "400": "#F2C14E",
        "500": "#DFA92D",
        "600": "#B9851F",
        "700": "#8E641B"
      }
    },
    "neutral": {
      "0": "#FFFFFF",
      "50": "#FAF9F6",
      "100": "#F3F1EC",
      "200": "#E7E3DC",
      "300": "#D5D0C7",
      "400": "#AAA49A",
      "500": "#79736B",
      "600": "#5F5A53",
      "700": "#45413C",
      "800": "#2E2B27",
      "900": "#1F1D1A",
      "950": "#141311"
    },
    "semantic": {
      "success": {
        "50": "#EFF8F1",
        "100": "#D9EEDC",
        "500": "#2F855A",
        "600": "#276C4A",
        "700": "#20583D"
      },
      "warning": {
        "50": "#FFF7E8",
        "100": "#FCE8BF",
        "500": "#A96812",
        "600": "#87520E",
        "700": "#68400D"
      },
      "danger": {
        "50": "#FFF1F0",
        "100": "#F8DAD7",
        "500": "#C4473A",
        "600": "#A9362D",
        "700": "#852B25"
      },
      "info": {
        "50": "#EFF6FD",
        "100": "#DCEBFA",
        "500": "#3478B8",
        "600": "#285F95",
        "700": "#204B75"
      }
    },
    "surface": {
      "canvas": "#FAF9F6",
      "page": "#FFFFFF",
      "subtle": "#F3F1EC",
      "raised": "#FFFFFF",
      "sunken": "#EDEAE4",
      "inverse": "#2E2B27"
    },
    "text": {
      "primary": "#2E2B27",
      "secondary": "#5F5A53",
      "tertiary": "#79736B",
      "disabled": "#AAA49A",
      "inverse": "#FFFFFF",
      "link": "#18756E",
      "linkHover": "#155E59",
      "onPrimary": "#1F1D1A",
      "onSecondary": "#FFFFFF",
      "onDanger": "#FFFFFF",
      "onSuccess": "#FFFFFF",
      "onInfo": "#FFFFFF"
    },
    "border": {
      "default": "#E7E3DC",
      "strong": "#D5D0C7",
      "focus": "#218C83",
      "subtle": "#F3F1EC"
    },
    "interactive": {
      "primary": "#E9782B",
      "primaryHover": "#D9651B",
      "primaryActive": "#B94F14",
      "primaryDisabled": "#F3B287",
      "secondary": "#218C83",
      "secondaryHover": "#18756E",
      "secondaryActive": "#155E59",
      "secondaryDisabled": "#83C9BE",
      "selection": "#FCE9DA",
      "selectionBorder": "#E9782B"
    },
    "focus": {
      "ring": "#218C83",
      "ringOnDark": "#F5D05D"
    },
    "overlay": {
      "scrim": "#1F1D1A",
      "scrimOpacity": 0.48
    }
  }
}
```

## Source file: `naranj-color-system/tokens/color.css`

```css
:root {
  /* Naranj Color System v1.0 — Light theme */

  /* Brand: Primary Citrus Orange */
  --naranj-brand-primary-50: #FFF6EF;
  --naranj-brand-primary-100: #FCE9DA;
  --naranj-brand-primary-200: #F8D1B5;
  --naranj-brand-primary-300: #F3B287;
  --naranj-brand-primary-400: #ED9257;
  --naranj-brand-primary-500: #E9782B;
  --naranj-brand-primary-600: #D9651B;
  --naranj-brand-primary-700: #B94F14;
  --naranj-brand-primary-800: #943F12;
  --naranj-brand-primary-900: #71320F;

  /* Brand: Secondary Learning Teal */
  --naranj-brand-secondary-50: #EFF9F7;
  --naranj-brand-secondary-100: #D9F0EC;
  --naranj-brand-secondary-200: #B5E1DA;
  --naranj-brand-secondary-300: #83C9BE;
  --naranj-brand-secondary-400: #4EAA9D;
  --naranj-brand-secondary-500: #218C83;
  --naranj-brand-secondary-600: #18756E;
  --naranj-brand-secondary-700: #155E59;
  --naranj-brand-secondary-800: #144C49;
  --naranj-brand-secondary-900: #123F3D;

  /* Brand: Accent Gold */
  --naranj-brand-accent-50: #FFFAE8;
  --naranj-brand-accent-100: #FFF1C2;
  --naranj-brand-accent-200: #FBE18A;
  --naranj-brand-accent-300: #F5D05D;
  --naranj-brand-accent-400: #F2C14E;
  --naranj-brand-accent-500: #DFA92D;
  --naranj-brand-accent-600: #B9851F;
  --naranj-brand-accent-700: #8E641B;

  /* Neutral */
  --naranj-neutral-0: #FFFFFF;
  --naranj-neutral-50: #FAF9F6;
  --naranj-neutral-100: #F3F1EC;
  --naranj-neutral-200: #E7E3DC;
  --naranj-neutral-300: #D5D0C7;
  --naranj-neutral-400: #AAA49A;
  --naranj-neutral-500: #79736B;
  --naranj-neutral-600: #5F5A53;
  --naranj-neutral-700: #45413C;
  --naranj-neutral-800: #2E2B27;
  --naranj-neutral-900: #1F1D1A;
  --naranj-neutral-950: #141311;

  /* Semantic: Success */
  --naranj-success-50: #EFF8F1;
  --naranj-success-100: #D9EEDC;
  --naranj-success-500: #2F855A;
  --naranj-success-600: #276C4A;
  --naranj-success-700: #20583D;

  /* Semantic: Warning */
  --naranj-warning-50: #FFF7E8;
  --naranj-warning-100: #FCE8BF;
  --naranj-warning-500: #A96812;
  --naranj-warning-600: #87520E;
  --naranj-warning-700: #68400D;

  /* Semantic: Danger */
  --naranj-danger-50: #FFF1F0;
  --naranj-danger-100: #F8DAD7;
  --naranj-danger-500: #C4473A;
  --naranj-danger-600: #A9362D;
  --naranj-danger-700: #852B25;

  /* Semantic: Info */
  --naranj-info-50: #EFF6FD;
  --naranj-info-100: #DCEBFA;
  --naranj-info-500: #3478B8;
  --naranj-info-600: #285F95;
  --naranj-info-700: #204B75;

  /* Semantic surfaces */
  --naranj-surface-canvas: #FAF9F6;
  --naranj-surface-page: #FFFFFF;
  --naranj-surface-subtle: #F3F1EC;
  --naranj-surface-raised: #FFFFFF;
  --naranj-surface-sunken: #EDEAE4;
  --naranj-surface-inverse: #2E2B27;

  /* Semantic text */
  --naranj-text-primary: #2E2B27;
  --naranj-text-secondary: #5F5A53;
  --naranj-text-tertiary: #79736B;
  --naranj-text-disabled: #AAA49A;
  --naranj-text-inverse: #FFFFFF;
  --naranj-text-link: #18756E;
  --naranj-text-link-hover: #155E59;
  --naranj-text-on-primary: #1F1D1A;
  --naranj-text-on-secondary: #FFFFFF;
  --naranj-text-on-danger: #FFFFFF;
  --naranj-text-on-success: #FFFFFF;
  --naranj-text-on-info: #FFFFFF;

  /* Borders and focus */
  --naranj-border-default: #E7E3DC;
  --naranj-border-strong: #D5D0C7;
  --naranj-border-subtle: #F3F1EC;
  --naranj-border-focus: #218C83;
  --naranj-focus-ring: #218C83;
  --naranj-focus-ring-on-dark: #F5D05D;

  /* Interactive */
  --naranj-interactive-primary: #E9782B;
  --naranj-interactive-primary-hover: #D9651B;
  --naranj-interactive-primary-active: #B94F14;
  --naranj-interactive-primary-disabled: #F3B287;
  --naranj-interactive-secondary: #218C83;
  --naranj-interactive-secondary-hover: #18756E;
  --naranj-interactive-secondary-active: #155E59;
  --naranj-interactive-secondary-disabled: #83C9BE;
  --naranj-interactive-selection: #FCE9DA;
  --naranj-interactive-selection-border: #E9782B;

  /* Overlay */
  --naranj-overlay-scrim: #1F1D1A;
  --naranj-overlay-scrim-opacity: 0.48;
}

```

## 4. Implementation requirements

1. Read `10_VISUAL_ART_DIRECTION.md` before composing new pages.
2. Read this document before creating or changing shared UI components.
3. Use the actual project token files and font assets; do not copy token values into scattered CSS declarations.
4. Do not create new brand colors, gradients, shadows, radii or typography scales without documenting the reason and obtaining approval where the source marks them as fixed.
5. Every component must define responsive behavior and all relevant states: default, hover (pointer-capable only), focus-visible, pressed, selected, disabled, loading, success and error.
6. Verify RTL layout, Persian numerals/text behavior, keyboard navigation, touch targets, reduced motion and contrast.
7. Do not allow visual decoration to compete with question answering, feedback or the teacher's primary task.
8. Keep student and teacher component density intentionally different where their tasks require it.

## 5. Explicitly unresolved

If a numeric value, breakpoint, component variant or token is not present in the approved source files, do not present a guessed value as an existing standard. Propose it separately, label it **Proposed**, and validate it against the real project before adoption.



## Typography system — approved Abar Low family

### Font files and available weights

The approved local Persian font family is **Abar Low**, with exactly these three supplied files:

| File | CSS weight | Role |
|---|---:|---|
| `AbarLow-Regular.woff2` | 400 | Primary reading weight |
| `AbarLow-SemiBold.woff2` | 600 | Main interface emphasis |
| `AbarLow-Bold.woff2` | 700 | Strong, limited emphasis |

Use these exact local files. Do not introduce another Persian font, use a fallback family as the intended design font, or request additional weights unless the product owner supplies them.

### Weight hierarchy

The interface must have a **quiet, controlled weight contrast**. Three weights are sufficient. Do not make every heading bold or use weight as the only hierarchy mechanism.

| Weight | Use | Avoid |
|---|---|---|
| 400 Regular | Body copy, descriptions, helper text, long-form content, question text, form labels, secondary metadata | Tiny low-contrast text |
| 600 SemiBold | Page and section headings, navigation labels, card titles, buttons, tabs, field labels when emphasis is needed, selected states | Applying it to every paragraph |
| 700 Bold | Page-level key title where needed, key score/number, important short status, rare high-priority callout | Long paragraphs, all cards, all buttons, repeated use on every heading |

**Default rule:** use 400 for most text, 600 for most hierarchy, and 700 only for a small number of high-priority anchors.

### Recommended type scale

These are proposed implementation tokens to be checked against the existing project before adoption. They are not a claim that the uploaded source contains a pre-existing numeric type scale.

| Token | Size | Weight | Line height | Typical use |
|---|---:|---:|---:|---|
| `display` | 32px | 700 | 1.2 | Rare hero / onboarding title |
| `h1` | 28px | 700 | 1.25 | Main page title on roomy screens |
| `h2` | 24px | 600 | 1.3 | Main section title |
| `h3` | 20px | 600 | 1.35 | Card / subsection title |
| `h4` | 18px | 600 | 1.4 | Compact section title |
| `body-lg` | 18px | 400 | 1.65 | Important explanatory copy |
| `body` | 16px | 400 | 1.7 | Default body and question text |
| `body-sm` | 14px | 400 | 1.6 | Supporting text and metadata |
| `label` | 14px | 600 | 1.4 | Form labels, tabs, compact controls |
| `caption` | 12px | 400 | 1.5 | Low-priority metadata only |
| `button` | 15–16px | 600 | 1.2 | Button labels |

On narrow mobile screens, reduce display/page heading sizes only when needed to prevent wrapping or crowding. Do not reduce body text below 14px for ordinary reading. Question text and math prompts should remain comfortably readable.

### Typography behavior rules

- Use typography size, line height, spacing and placement together; do not solve every hierarchy problem by increasing weight.
- Keep the number of distinct text styles per screen small. A typical screen should use no more than 4–5 hierarchy levels.
- Avoid placing 700-weight headings next to multiple other 700-weight blocks.
- Keep body copy at 400 wherever possible; use 600 for short emphasis, not entire paragraphs.
- Use 700 sparingly for one dominant title or a key numeric result, not both everywhere.
- Maintain consistent Persian punctuation, half-space, numeral and mixed-script handling.
- Use logical alignment and RTL-aware layout. Do not reverse the font glyphs or manually reorder Persian text.
- Do not use font weight to distinguish meaning that also requires a label, icon or semantic state.

### CSS implementation

```css
@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-Regular.woff2") format("woff2");
  font-style: normal;
  font-weight: 400;
  font-display: swap;
}

@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-SemiBold.woff2") format("woff2");
  font-style: normal;
  font-weight: 600;
  font-display: swap;
}

@font-face {
  font-family: "Abar Low";
  src: url("/fonts/AbarLow-Bold.woff2") format("woff2");
  font-style: normal;
  font-weight: 700;
  font-display: swap;
}

:root {
  --font-persian: "Abar Low", sans-serif;
  --font-weight-regular: 400;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
}

html[lang="fa"],
body {
  font-family: var(--font-persian);
  font-synthesis: none;
}
```

The `/fonts/` URL is illustrative: use the actual asset path in the repository. Do not rename the files unless the project build requires it.

### Typography acceptance checks

- Only the three supplied Abar Low weights are loaded.
- No synthetic 500, 800 or 900 weight is requested.
- Browser font synthesis is disabled.
- Regular is the dominant reading weight.
- SemiBold provides most interface hierarchy.
- Bold appears selectively and does not make the interface visually heavy.
- Heading/body hierarchy remains clear in Persian at 360px, 390px, 430px, tablet and desktop widths.
- Buttons, forms, question content, math notation and navigation are checked with real Persian copy.
