# NARANJ — Motion, Microinteractions and UI Quality

## Authority
This document is implementation guidance, not product authority. It must not alter product rules, flows, scoring, question validation, brand colors, fonts or mascot identity.

## Motion principles
- Motion must explain state, hierarchy, cause/effect or spatial continuity. If it adds no information, remove it.
- Prefer CSS transitions/keyframes for simple UI motion. Use WAAPI or a motion library only when timeline control, spring physics, layout transitions, gesture handling or coordinated exit behavior genuinely requires it.
- Animate primarily `transform` and `opacity`; avoid layout-thrashing properties.
- Respect `prefers-reduced-motion`. Provide a reduced or static equivalent.
- Do not rely on hover for essential actions; gate hover-only behavior to hover-capable pointers.
- Keep student practice interactions fast and predictable. Never delay answer submission, feedback or Continue behind decorative animation.
- Avoid confetti, bouncing, pulsing and mascot movement as constant background noise. Reserve celebration for meaningful milestones.
- Preserve keyboard focus and touch targets during transitions.

## Required interaction states
For each interactive component, specify: default, hover (where applicable), focus-visible, pressed, selected, disabled, loading, success, error, and empty state where relevant.

## Microinteraction rules
- Selection: clear selected state immediately; preserve readable contrast.
- Submission: acknowledge that the answer was submitted; prevent duplicate submission.
- Feedback: prioritize correctness explanation and next action over animation.
- Progress: animate only meaningful confirmed progress changes; avoid fake progress.
- Dialogs/drawers: manage focus, Escape behavior where appropriate, and restore focus to trigger.
- Drag/drop: provide non-drag alternatives when practical; keyboard support or equivalent controls.
- Responsive: do not make touch interactions depend on hover; avoid tiny drag handles.

## QA checklist
- Reduced-motion mode tested.
- Keyboard-only path tested.
- Touch interaction tested on narrow viewport.
- No motion blocks critical task completion.
- Animation does not cause content reflow or horizontal overflow.
- Motion timing is consistent and restrained.
- No animation changes the meaning of a score or mastery state.

## Skill guidance used
The supplied Animate, Emil Design Engineering, Design Taste Frontend and Impeccable packages were treated as supporting references. Their overlapping design-direction commands are not run as competing authorities. Product sources and approved Naranj design tokens always win.
