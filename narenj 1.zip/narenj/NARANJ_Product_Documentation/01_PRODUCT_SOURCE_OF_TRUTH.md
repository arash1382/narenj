# NARANJ — Product Source of Truth

**Purpose:** One authoritative working reference for product, UX, design, engineering and AI implementation.
**Status:** Consolidated from supplied product Q&A, clarification Q&A, UX Architecture v2.1, question-type workbook and skill workbook.
**Rule:** This document does not silently resolve contradictions. Items labelled Open remain open until the product owner decides.

## 1. Source hierarchy

1. Newer explicit product-owner decisions in the clarification Q&A and current conversation.
2. `نارنج.docx` — original product question/answer source.
3. `پاسخ ابهامات نارنج.docx` — supplementary clarification source; supersedes older answers only where it explicitly clarifies or changes them.
4. `Naranj_Product_UX_Architecture_v2.1` — consolidated UX architecture, subject to newer explicit decisions above.
5. `Question types (2).xlsx` — interaction model inventory and source-level validation notes.
6. `skill form - v5.ods` — curriculum/topic/skill source data.
7. Existing design-system documents and tokens — visual implementation constraints.
8. The four uploaded design/animation Skills — process guidance only; never product authority.

If a conflict is found, record it in the decision register and preserve both source positions until resolved.

## 2. Evidence labels

- **Confirmed** — explicitly stated in product source material.
- **Architecture rule** — specified in UX Architecture v2.1.
- **Owner override** — a newer explicit product-owner instruction superseding an older source.
- **Proposed** — a design recommendation, not a product decision.
- **Open** — source material does not decide it.
- **Technical validation** — requires engineering/security/data confirmation.

## 3. Source inventory and audit

| Source | Audited content | Role |
|---|---:|---|
| `نارنج.docx` | 384 paragraphs; 30 tables | Primary product Q&A |
| `پاسخ ابهامات نارنج.docx` | 8 paragraphs; 7 tables | Clarifications |
| UX Architecture v2.1 | 5194 lines; 0 numbered top-level sections | Consolidated UX architecture |
| Question types workbook | 62 rows × 7 columns; 21 named models A01–A21 | Interaction inventory |
| Skill workbook | two sheets: `main topics`, `skills` | Curriculum data |

### Skill workbook row audit
- `main topics`: 502 physical rows, 500 non-empty rows
- `skills`: 691 physical rows, 688 non-empty rows, 156 skill-title rows, 135 rows with learning objective, 11 rows with misconception text

**Important:** Counts above are workbook row audits, not a claim that every row is a validated, production-ready skill record. See `05_SKILL_CONTENT_SPEC.md` for raw rows and missing-data cautions.

## 4. Product definition

Naranj is a Persian-first educational practice platform. The initial product scope and role behavior are defined in the UX Architecture v2.1 and source Q&A. The architecture distinguishes Student and Teacher experiences and treats other roles as secondary / not fully specified for the current release.

The platform must not be turned into a generic LMS. Do not add features, workflows, roles, content or data fields merely because they are common in educational software.

## 5. Binding student-practice rules

The following practice-session rules are binding where explicitly stated in the product/UX source:
- One question at a time.
- Forward-only question progression; no returning to a previous question.
- A submitted answer cannot be edited.
- No retry after an incorrect answer.
- Timer is elapsed/count-up, not countdown.
- Using a hint does not reduce SmartScore.
- Feedback is followed by an explicit Continue action.
- A session ends at SmartScore 100 or when the student exits.
- Persist confirmed progress and support resume/recovery according to the session architecture.

Do not change these rules to match conventional quiz patterns.

## 6. Learning progress and rewards

- Mastery ladder: Not Started → Attempt → Familiar → Proficient → Mastered.
- Medals: 80 = bronze, 90 = silver, 100 = gold.
- Competition is based on personal growth; no public leaderboard.
- Student routes into learning include assigned, recommended and self-selected routes.

## 7. Role and teacher constraints

- Student and Teacher are the primary product roles.
- Teacher class context: one active class with a class switcher.
- Teacher can browse/preview the skill library, assign to a class or selected students, generate quizzes from the available question bank, and track student/class progress.
- Reordering assigned skills is unresolved; do not implement until defined.
- Student `STU-03 Skill Preview` remains unresolved; teacher preview is a separate capability.
- Do not infer that teacher quiz-taking behavior is specified merely because quiz generation is specified.

## 8. Onboarding owner override

**Owner override:** Avatar selection followed by an interactive guided tour is mandatory. This supersedes the older UXA v2.1 / DESIGN.md statements that avatar selection is optional or that a mandatory avatar wizard should be avoided. Implement the new owner decision, but do not invent detailed tour steps beyond the approved flow; use `08_CHARACTER_AND_ONBOARDING_SPEC.md`.

## 9. Recovery and authentication

**Confirmed:** account recovery supports both email and SMS. Do not replace this with username-only recovery or an invented recovery channel. Refer to the detailed authentication flow in the UX Architecture and source Q&A.

## 10. Question inventory

The source workbook contains **21** named interaction models, A01–A21. The exact source transcription is in `04_QUESTION_INTERACTION_SPEC.md`. The UXA includes its own workbook-derived section and governance notes. Do not claim a 20-type inventory.

## 11. Skill data integrity

The ODS workbook is the source for topics and skills. Preserve its Persian titles and field values. Do not fabricate:
- stable skill IDs where blank;
- prerequisites / post-requisites where blank;
- sequence where blank;
- question-type mappings where blank;
- objectives or misconceptions where blank.

Use the workbook as content source, not as evidence that a complete question bank exists. There is no production question bank in the supplied sources. Any demonstration question must be labelled as demo content.

## 12. Design authority

Use the supplied `DESIGN.md`, `COLOR_SYSTEM.md`, `color.tokens.json`, `color.css`, layout/component/typography files where present. Preserve approved brand colors, typography and existing mascot/character artwork. Do not randomly change brand identity.

The earlier design system states Abar Low font files and weights 400/600/700/800/900. Verify actual font asset names and available weights in the project before implementation; do not synthesize missing weights.

## 13. Current open decisions

At minimum, keep these unresolved until explicit product-owner confirmation:
- Student `STU-03 Skill Preview` behavior and content.
- Assigned-skill reordering rules.
- Detailed question-type answer contracts where the workbook leaves validation ambiguous.
- Multiple-solution grading for geometric construction questions.
- Missing skill IDs, prerequisite links, sequence and question-type mappings.
- Quiz-taking experience and its session behavior where not confirmed.
- Data/privacy boundaries and any backend-dependent analytics fields not fully settled by source.
- Secondary-role scope and permissions not finalized in the source.

## 14. Implementation gate

Before coding a feature:
1. Identify its source and evidence label.
2. Confirm it exists in product scope.
3. Check it does not violate the binding practice rules.
4. Check role permissions and data dependencies.
5. Check responsive, RTL, accessibility and empty/error states.
6. If any critical behavior is Open, stop and ask rather than inventing it.


## 15. Latest owner clarification — MVP roles and school-code entry

- MVP role focus: Student and Teacher.
- Entry uses a school code; the system determines the account role from the school/account context.
- Do not add a separate Student/Teacher role-selection screen if the entry flow already resolves it.
- Parent is not an MVP focus. Keep parent illustration categories future-compatible only; do not build parent-specific MVP flows or menus.
- Illustration counts may differ between categories. Do not force equal counts or create placeholder duplicates.
