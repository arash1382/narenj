# Naranj — Product UX Architecture v2.1

**Document ID:** NRNJ-UXA-002  
**Version:** 2.1 — revised from v2.0  
**Status:** Draft for product-team review and decision sign-off  
**Date:** 10 November 2026  
**Canonical source:** Revised DOCX; this Markdown companion is intended for search and AI ingestion.

NARANJ

PRODUCT UX ARCHITECTURE

Source-Based Product Analysis · UX Strategy · Information Architecture · User Flows · Interaction Behaviour


| Document ID | NRNJ-UXA-002 |
| --- | --- |
| Version | 2.0 — supersedes Naranj_UX_Architecture_v1.0.md |
| Document type | Product UX Architecture (pre-wireframe, pre-design-system) |
| Product phase | Product definition and UX architecture |
| Prepared by | Senior Product Design / UX Architecture / UX Research / Product Strategy |
| Audience | Product Owner, Product Manager, UX/UI designers, front-end engineers, content team, QA |
| Status | Draft for product-team review and decision sign-off |
| Language of record | Professional English (source terms preserved in Persian where meaning matters) |
| Date | 10 November 2026 |
| Evidence base | 3 source PDFs + 1 prior internal draft (see §2) |
| Known evidence gap | The Question Type specification workbook was supplied and transcribed in this revision; per-type release inclusion remains subject to MVP sign-off. |

TABLE OF CONTENTS

Section outline. Page numbers are printed in the footer of every page; the document is paginated by the reader application.

CONTENTS

1. EXECUTIVE SUMMARY

2. DOCUMENT CONTROL AND SOURCE METHODOLOGY

3. PRODUCT DEFINITION

4. PRODUCT GOALS AND VALUE PROPOSITION

5. USERS, ROLES, AND PERMISSIONS

6. MVP SCOPE AND PRIORITIES

7. UX STRATEGY AND PRINCIPLES

8. EXPERIENCE ARCHITECTURE

9. INFORMATION ARCHITECTURE

10. SITEMAP

11. PAGE INVENTORY

12. STUDENT EXPERIENCE

13. TEACHER EXPERIENCE

14. SECONDARY ROLE SCOPE

15. USER JOURNEYS AND FLOW DIAGRAMS

16. PRACTICE SESSION ARCHITECTURE

17. QUESTION TYPE AND ANSWER COMPONENT ARCHITECTURE

18. ASSIGNMENT AND CLASS MANAGEMENT

19. QUIZ GENERATOR

20. ANALYTICS, RECOMMENDATIONS, AND GAMIFICATION

21. UX BEHAVIOUR SPECIFICATION

22. SYSTEM STATES AND ERROR HANDLING

23. RESPONSIVE UX ARCHITECTURE

24. ACCESSIBILITY AND LOCALIZATION

25. MATHEMATICS UX

26. PRIVACY AND DATA BOUNDARIES

27. DESIGN ROADMAP

28. ACCEPTANCE CRITERIA

29. OPEN QUESTIONS AND DECISION REGISTER

30. SOURCE REFERENCES AND EVIDENCE TRACEABILITY


# NARANJ — PRODUCT UX ARCHITECTURE

Independent Product UX Architecture for Naranj

Source-Based Product Analysis · UX Strategy · Information Architecture · User Flows · Interaction Behaviour


| Field | Value |
| --- | --- |
| Document title | Naranj — Product UX Architecture |
| Document ID | NRNJ-UXA-002 |
| Version | 2.1 (revises v2.0; supersedes v1.0) |
| Document type | Product UX Architecture — pre-wireframe, pre-design-system |
| Product phase | Product definition and UX architecture (as stated in the brief) |
| Prepared by | Senior Product Design / UX Architecture / UX Research / Product Strategy |
| Audience | Product Owner, Product Manager, UX/UI designers, front-end engineers, content team, QA |
| Status | Draft for product-team review and decision sign-off |
| Language of record | Professional English (source terms preserved in Persian where meaning matters) |
| Date | 10 November 2026 |
| Evidence base | 3 source PDFs + 1 prior internal draft (see §2) |
| Known evidence gap | The Question Type specification workbook was supplied and transcribed in this revision; per-type release inclusion remains subject to MVP sign-off. |


## 1. EXECUTIVE SUMMARY


### 1.1 What this document is

This document is the complete, source-derived Product UX Architecture for Naranj (نارنج), a responsive web-based academic practice platform for students aged roughly 9–15, with teachers as the second primary user. It converts the currently available product definition material into an executable UX architecture: product definition, roles and permissions, information architecture, sitemaps, a page inventory with per-page specification, UX principles, end-to-end user flows with decision and error paths, the shared Practice Session architecture, the question-interaction architecture, behaviour specifications, system states, responsive and accessibility architecture, a design roadmap, acceptance criteria, and a decision register.

It deliberately does not produce visual UI, wireframe drawings, or a design system. It defines the architecture those artefacts must obey.


### 1.2 What Naranj is (short form)

[CONFIRMED] Naranj is a web-based educational practice platform in which a student practices a skill — one that a teacher has assigned, that the system has recommended, or that the student has selected from the Skill Library — receives educational feedback after each answer, sees their progress, and decides on the next practice. A teacher finds existing system content, assigns skills to a class or to specific students, generates quizzes from the system question bank, follows a teaching plan, and uses analytics reports to support learning. (S2 §1.1; S1 §1.1)


### 1.3 Ten architecture-level conclusions

These are the decisions this document locks in for design, each with its evidence status.


| # | Conclusion | Status |
| --- | --- | --- |
| 1 | The product has exactly two design-ready roles for the first release: Student and Teacher. Parent and School Admin are named roles with a shared-page archetype but no confirmed experience. | [CONFIRMED] + [OPEN DECISION] for secondary roles |
| 2 | There is no role selection at sign-in. Authentication resolves the role and routes the user to their role's landing page. | [CONFIRMED] (S2 §1.3, S1 §3.1) |
| 3 | Skill Library and Practice Session are two different experiences, not one page with modes. Practice Session is a focused, single-question environment. | [CONFIRMED] (S1 §6, S2 §1.3) |
| 4 | Question types are one session shell + one renderer + N answer components. A page layout per question type is architecturally forbidden. | [DESIGN RECOMMENDATION] |
| 5 | The content taxonomy is Subject → Grade → Topic → Subtopic → Skill → Question, with Subtopic confirmed and prerequisites attached to skills. | [CONFIRMED] (IA-001, IA-003) |
| 6 | Practice is strictly forward-only: no return to a previous question, no editing a submitted answer, no retry after an incorrect answer. | [CONFIRMED] (PRA-003, PRA-008, STU-017) |
| 7 | The session timer is elapsed time (count-up), never a countdown in practice. | [CONFIRMED] (S2 §5.5, S1 §6) |
| 8 | Gamification is personal-achievement only: coins, badges, goals, medals, no public ranking or leaderboard. | [CONFIRMED] (S1 §2, STU-019, BM-DU-004) |
| 9 | The teacher's core loop is data → action: every analytics surface must terminate in a follow-up assignment action. | [CONFIRMED] (S1 §8.3 "Action", S2 §6.6) |
| 10 | The MVP content scope is mathematics, grade 4 at first release (grades 4–6 for the following academic year), ~300 skills per grade (an estimate, not a firm count). | [CONFIRMED] (SCP-001, S1 §2) |


### 1.4 What is blocked, and by what


| Blocker | Consequence for this document | Owner needed |
| --- | --- | --- |
| Question Type workbook supplied and transcribed in v2.1 | The workbook is available and transcribed in §17.9 and Appendix A. The remaining open item is product-owner confirmation of which workbook interactions belong in the first release. | Product Owner / content team (PRA-001 states the product side owns this) |
| SmartScore formula undefined | Score display is specified as a slot with defined states (unknown/insufficient data/available), not as a formula. Achievement medals (80/90/100) are confirmed but their relationship to the "Mastered" status is not. | Product + content team |
| Multi-role accounts confirmed possible but role detection is automatic and there is no role picker | A routing rule for multi-role accounts is required before authentication design is frozen. See C-16 / D-03. | Product Owner |
| Student analytics indicators undefined (STU-015) | Student Progress page is specified structurally, with an explicit "indicator set pending" state. | Product Owner |
| Question quality of Quiz Generator parameters undefined | Quiz Generator is specified as a parameterised flow with a parameter registry marked "pending confirmation". | Product Owner |


### 1.5 How to read this document

- Read §2 first: it defines the label system, source precedence, source inventory, and the conflict register. Everything later inherits from it.
- Designers can start wireframing after §7, §8, §9, §10, §11 and §16 using only [CONFIRMED] and [DESIGN RECOMMENDATION] content.
- Engineering can start API contract discussion after §16, §17, §21, §22.
- Anyone who needs to resolve a product behaviour should go straight to §29 (Decision Register), which consolidates every unresolved item with an ID, impact and suggested resolution method.

## 2. DOCUMENT CONTROL AND SOURCE METHODOLOGY


### 2.1 Classification system (mandatory throughout)

Every substantive statement in this document carries one of the following labels. [CONFIRMED] is deliberately narrow: it means a source document says it, not that it is a good idea.


| Label | Meaning | Test for applying it | Source tag equivalent |
| --- | --- | --- | --- |
| [CONFIRMED] | An explicit product rule, requirement, or decision present in a supplied source document (including explicit product-team clarification answers). | A specific source location can be cited. If no citation exists, the label is not allowed. | [قطعی در بریف] |
| [DESIGN RECOMMENDATION] | A proposed UX solution grounded in professional judgement. Not an approved requirement. | The recommendation must state its rationale and the risk if rejected. | [طراحی پیشنهاد] |
| [OPEN DECISION] | A product behaviour that cannot be determined from available materials, or where sources disagree and the disagreement has not been resolved by the product team. | The decision register contains a matching D-xx entry. | [تصمیم نیازمند] |
| [TECHNICAL VALIDATION] | A matter requiring engineering, security, data or infrastructure validation before it can be designed as fact. | Names the technical question and who must answer it. | [فنی بررسی نیازمند] |
| [OUT OF CURRENT PRIORITY] | Exists in the broader product context but must not drive the current design phase, or is explicitly outside the MVP. | A source explicitly excludes it, or priority P2 with no first-release commitment. | [خارج از MVP] |
| [BENCHMARK EVIDENCE] | An observation from the four reviewed competitor products. Evidence, not requirement. | Must never be presented as Naranj behaviour. Any adoption needs its own decision entry. | [شاهد رقیب] |

Additional traceability labels used only in §2 and §30:


| Label | Meaning |
| --- | --- |
| [PRIOR DRAFT] | Content originating from Naranj_UX_Architecture_v1.0.md. This is a prior internal deliverable, not a product requirement source. Treated as evidence of nothing except prior thinking. |
| [DERIVED] | A count, mapping, or summary computed by this document from confirmed content (e.g. "14 role pages enumerated from S1+S2"). Traceable to sources but not itself a source statement. |
| [SUPPLIED AND REVIEWED IN v2.1] | The source material referenced by other sources is missing from the evidence set. Never converted into an assumption. |


### 2.2 Source hierarchy (applied strictly)

When sources disagree, precedence is applied in this order. This document never resolves a conflict by silent choice; every conflict is either resolved with the precedence rule stated or escalated to §29.

1.  Explicit product-team clarification answers — S3 (highest).

2.  Latest approved product requirements and briefs — S1 (نارنج.pdf, the later, broader "shared reference" brief).

3.  Detailed product specification documents — S1 sections that enumerate page-by-page requirements, and S2 (rowshana_design_brief_farsi) as the detailed page/flow specification of the same product.

4.  Existing UX architecture and flow documents — S2 §7 (the 20 flows), S4 (prior draft).

5.  Research and competitor benchmark observations — S1 §13.

6.  Own professional recommendations — always labelled, never merged into the above.


### 2.3 Source inventory


| ID | File | Identification (as read) | Pages | Role in this document | Status |
| --- | --- | --- | --- | --- | --- |
| S1 | نارنج.pdf | "سند مشترک طراحی، توسعه تیم محصول و بریف تجربه کاربری و فنی محصول" — Khord Design Studio (استودیو دیزاین خرد). Cover states internal version 0.1 and a date of 15 Aban. 16 numbered sections + a 4-competitor benchmark + open-question blocks per section + a per-section open-question ID scheme (PRD, SCP, AUTH, IA, STU, PRA, TCH, QUIZ, PLAN, ANL, PAR, ADM, SYS, STATE, A11Y, BM-*, SYN, QA). | 32 | Primary architecture source. Defines scope, priorities, page requirements, session architecture, states, RTL/math requirements, benchmark evidence. | Read in full |
| S2 | rowshana_design_brief_farsi (1).pdf | "تعریف محصول و بریف طراحی - روشنا" — Rowshana Product Team, created 24 Oct 2026. 10 sections: product value, users, MVP scope, content model, student page requirements, teacher page requirements, 20 core user flows (10 student / 10 teacher), product rules, shared states + UX writing, glossary. | 17 | Detailed page & flow specification. Its content is structurally the same product as Naranj (same 6-level taxonomy, same 14 role pages, same 20 flows, same SmartScore concept, same benchmark framing) but under the product name روشنا. | Read in full |
| S3 | پاسخ ابهامات نارنج.pdf | "Clarification responses for Naranj" — a table of answers to source open questions (PRD-001…005, SCP-001…007, AUT-001…009, IA-001…006, STU-001…025, PRA-001…010, TCH-001…021). Created 10 Nov 2026. | 5 | Highest-precedence source. Contains 83 question IDs (PRD 5, SCP 7, AUT 9, IA 6, STU 25, PRA 10, TCH 21): 66 substantive answers, 9 answered only as "بصورت شفاهی توضیح خواهم داد" (will explain verbally) — treated here as unanswered — and 8 left blank. | Read in full |
| S3b | پاسخ ابهامات نارنج (1).pdf | Byte-identical duplicate of S3 (identical MD5: ffa18cb963a45ad1adcbe45f956f50c9). | 5 | None. Noted to prove the evidence set was fully inspected and that no second, different clarification set exists. | Duplicate |
| S4 | Naranj_UX_Architecture_v1.0.md | Prior internal UX architecture draft (1,105 lines). | — | [PRIOR DRAFT] Superseded by this document. Retained only in §30 as a change record. The earlier source-status assessment was incomplete; v2.1 records the workbook as supplied and transcribes its interaction inventory. | Superseded |
| S5 | Question Type specification workbook (Excel) | Referenced by S2 §3.8 ("در فایل مربوط به قالب های سوال 17 مدل تیپ سوالی که در ixl وجود دارد ، ضمیمه شده است") and by S1 PRD-004 / SCP-006 (17 types exist in staging). | — | [SUPPLIED AND REVIEWED] — workbook interaction labels, UX descriptions, validation notes and examples transcribed in §17.9 / Appendix A. | Received in the project source set and inspected for v2.1. |

2.3.1 Provenance conflict: "روشنا" vs "Naranj"

[DERIVED] S2 names the product روشنا (Rowshana); S1 and S3 name it نارنج (Naranj). The two documents describe the same product family: identical taxonomy depth, identical 14 role pages, identical 20 core flows, identical "SmartScore" concept, identical benchmark set framing, and S1's open-question IDs are answered by S3 against Naranj. S1 is the later document and is the one the product team is clarifying.

Working assumption for this document: Naranj is the current product name and S1/S3 are authoritative; S2 is treated as the detailed page/flow specification of the same product under its earlier name. [OPEN DECISION] D-01 asks the product team to confirm whether Rowshana is (a) the same product renamed, (b) a sister product, or (c) an obsolete artefact. UX impact if assumption is wrong: branding, copy, and localization strings only — the architecture is unaffected, because the page and flow sets are identical. This assumption is flagged wherever S2-only requirements are used.


### 2.4 Evidence gaps (explicit, not filled by assumption)


| Gap ID | Gap | Consequence | Not invented because |
| --- | --- | --- | --- |
| RESOLVED IN v2.1 | Question Type workbook transcription | The workbook is available and its interaction inventory is transcribed; implementation-level answer contracts still need content/engineering sign-off. | Question types (2).xlsx; v2.1 §17.9 / Appendix A |
| GAP-02 | SmartScore formula and its response to correct/incorrect/hint/skip | Score shown as a value the system provides; no formula, no prediction | S1 BM-IXL-002, PRA-010, S2 glossary all state the formula must be approved |
| GAP-03 | Student analytics indicator set | Progress page specified structurally; indicator cards marked "pending" | STU-015 answered "هنوز قطعی نشده است" (not yet decided) |
| GAP-04 | Quiz Generator parameter set and quiz-taking experience | Quiz flows specified up to "taking a quiz" boundary, which is itself unresolved (QUIZ-006) | S2 §3.8 lists six candidate parameters but marks all as requiring approval |
| GAP-05 | Parent and School Admin experience | Only role intent + "shared pages with different analytics indicators" | S1 §9 explicitly says these roles are named, not documented, and should not be designed in detail yet |
| GAP-06 | Notification channels, rules, and events | Notifications specified as a shell + state model only | SYS-001…008 are unanswered in S3 |
| GAP-07 | Content publishing/workflow ownership (Content Admin) | Role described in one table row, no pages | S1 §2.2 states Content Admin is not defined as an independent role and question-bank ownership is open (SCP-005) |
| GAP-08 | Timezone/deadline boundary behaviour beyond "Iran time" | Deadline semantics modelled on Iran time only | TCH-020 confirms Iran time for MVP; multi-timezone is out of scope |


### 2.5 Source-quality observations


| Observation | Detail | Handling |
| --- | --- | --- |
| Digit-order ambiguity in extracted Persian text | Extracted PDF text renders some numerals in reversed visual order (e.g. ۵۱ for ۱۵, ۰۰۳ for ۳۰۰). | Every numeric fact used in this document is cross-checked against a second source or against S2's Latin-numeral text. Where a count could not be cross-checked it is marked [DERIVED]/approximate. |
| Citation convention for sub-section numbers | Section numbers are cited as they appear in the source (S1 §6.2, S2 §5.5). Because of the digit-order issue above, S1 and S2 sub-sections are additionally identified by subject in the traceability table (§30.1) — e.g. S2's student-analytics requirement is cited as S2 §4.5 / §5.4 (student analytics) wherever the number alone could be misread. | When a citation's number is ambiguous, the subject name governs; the source section it belongs to (S1 §5 vs S2 §5) is always stated. |
| Verbal-only answers | PRD-004, AUT-001, AUT-002, AUT-009, STU-009, STU-024, TCH-004, TCH-008, IA-006, PRA-001 partial → "will explain verbally". | Treated as unanswered. Listed in §29 with Resolution method: interview. |
| Unanswered question blocks | S1 raises roughly 150 open-question IDs. S3 covers 83 of them (66 substantive, 9 verbal-only, 8 blank). The blocks QUIZ, PLAN, ANL, PAR, ADM, SYS, STATE, A11Y, BM-\*, SYN, QA are entirely unanswered. | Entire blocks carried into §29 with an owner, a priority and a resolution method. |
| Priority vs release ambiguity | S1 §2.1 note states priority orders design, and SCP-002 confirms "more about design order". S3 PRD-003 states Parent/Admin may be excluded from the Dey release while SCP-003 says they have independent dashboards in MVP. | Conflict C-13; both statements preserved. |


### 2.6 Conflict register

Each conflict is recorded with both statements. "Resolved" means the precedence rule yields a defensible single answer; "Unresolved" means a product decision is required and a D-xx entry exists in §29.


| ID | Topic | Statement A | Statement B | Status | Resolution / Decision |
| --- | --- | --- | --- | --- | --- |
| C-01 | Product name | S2: روشنا (Rowshana) | S1/S3: نارنج (Naranj) | Unresolved (low impact) | Recency + clarification target → Naranj authoritative; see D-01 |
| C-02 | Is feedback a page? | S1 §2.1 and S2 §3.3 list "صفحه بازخورد سوال" (question feedback page) as a P0 page | S1 §6 defines Feedback as a region inside Practice Session | Resolved | Precedence 2/3: Practice Session is one environment with a feedback state (§16.6). "Page" in S1/S2 is used loosely for "P0 surface". No separate Feedback route is created. Evidence: S1 §6 "یک سؤال در هر لحظه" + S2 §1.3 "دو صفحه متفاوت". |
| C-03 | Timer semantics | S1 §6 / S2 §5.5: "زمان سپری شده" (elapsed time) | S1 A11Y-005 & QUIZ-005 ask about exam duration/extension | Resolved for practice, open for quiz | Practice = count-up [CONFIRMED]. Quiz duration = param not approved (D-22). |
| C-04 | Skill status vocabulary | S1 §4.1 lists statuses: Not Started, In Progress, Practicing, Mastered, Needs Review, Locked | S3 TCH-019 answers "assignment statuses" with: Not started, attempt, familiar, proficient, mastered | Unresolved | Two vocabularies; TCH-019 is likely a mastery scale, S1's list mixes availability + mastery. See C-05 and D-05. Both preserved; UI must not ship two competing scales. |
| C-05 | Assignment status vs mastery status | S1 §7.4 statuses: Scheduled, Active, Completed, Overdue | S3 TCH-019 gives mastery-like stages of the student in a skill | Unresolved | Assignment status (schedule) and per-student mastery are different axes; recommend two separate, non-competing models (D-05, §18.4). |
| C-06 | Retry after incorrect answer | S1 §6.1 leaves "Retry or immediate" open | S3 PRA-003: "خیر" (no retry) | Resolved | No retry [CONFIRMED]. Forward-only; recovery is a new attempt on the next question, not a retry of the same one. |
| C-07 | Backward navigation / answer editing | S1 §6 lists "قابلیت اصلاح پس از ارسال؟" as open | S3 PRA-008 "خیر"; STU-017 "سیستم فقط رو به جلو است" | Resolved | Forward-only, no editing, no review of previous answers during the session [CONFIRMED]. |
| C-08 | Class sign-in gate | S1 §3.3 asks whether Class Code is entered before or after sign-in | S3 AUT-003: after first login, and can be added at any time | Resolved | Class membership is not a gate; join-class is an anytime in-product action [CONFIRMED]. |
| C-09 | Assignment detail page | S1 STU-005 open: does clicking an assignment card open a detail page? | S3 STU-005: "فعلا تصمیم بر این است که بصورت مستقیم وارد بشیم" (enter directly) | Resolved | Card → Practice Session directly [CONFIRMED]. No student assignment-detail page. See C-10 for the conflict this creates. |
| C-10 | Assignment instructions visibility | S1 §7.4 / S2 §3.6: assignment has short instructions and pre-publish summary | Direct entry (C-09) removes the place where instructions would be read | Unresolved | D-09: where instructions surface (inline pre-practice sheet vs. inside session header vs. not shown). |
| C-11 | Subtopic in the model | S1 §4: "Subject → Grade → Topic → Subtopic?" with ? | S3 IA-001: "بله" (yes) | Resolved | Six levels confirmed: Subject → Grade → Topic → Subtopic → Skill → Question [CONFIRMED]. |
| C-12 | Skill versioning / deactivation | S1 §15 entity table lists "نسخه بندی" (versioning) as a field | S3 IA-004: "نه" (no) | Resolved (MVP) | No skill versioning in current scope [CONFIRMED]. Effect of content edits on historical data stays open (D-12). |
| C-13 | Parent / School Admin in MVP | S3 PRD-003: may be left out of the Dey release for time, though the two users share pages | S3 SCP-003: "بله" — they have independent dashboards in MVP | Unresolved | D-02. This document designs them as reuse of the teacher/student shell + analytics variant, and marks all their pages P2 / not-first-release. |
| C-14 | Multiple roles per account | S3 SCP-004: "بله" (a user can have multiple roles) | S1/S2: role is auto-detected at sign-in; no role selector exists on the sign-in screen; S2 §8.1 says dual-role is "not yet defined" | Unresolved — architectural | D-03. Requires a deterministic routing rule (e.g. last-used context) before authentication IA freezes. |
| C-15 | 17 question types | S1 PRD-004 asks whether all 17 are covered in the brief and whether all need design for MVP | S3 SCP-006: 17 types exist in staging | Unresolved (evidence missing) | Workbook (S5) is now supplied and transcribed in v2.1. Confirm MVP inclusion and per-type answer contracts. §17.9 / Appendix A + D-16. |
| C-16 | Rewards Store release | S1 §2: only real-money purchase is out of MVP; S1 priority table puts Rewards Store at P2 | S3 STU-025: "yes — if the designs are ready, including it in the first release is appropriate" | Unresolved | D-13. Treated as P2 design priority, release-decision pending, with a hard rule: no surface may imply real-money purchase. |
| C-17 | Honor Roll vs public ranking | S1 §2: public ranking/leaderboard is out of MVP; STU-019: Honor Roll is personal achievement | S2 §5.6 "غیررقابتی" | Resolved | Personal achievements only; no ranking, no peer comparison [CONFIRMED]. |
| C-18 | Recommendation basis | S1 §5.3: based on practice history, assignments and skill relations — not Diagnostic Assessment | S3 STU-013: default recommendations exist from curriculum/time plan even without history | Resolved | Three-tier recommendation basis: (1) adaptive signals, (2) assignment-derived, (3) curriculum default fallback [CONFIRMED]. Reason strings must reflect which tier fired (§20.4). |
| C-19 | Student Progress page exists without data | S3 STU-018: dashboard must exist with zeros when there is no data | S2 §4.5: "داده کم" (little data) is an empty state | Resolved | Zero-state dashboard is a valid state, not an empty state [CONFIRMED]. Charts that would mislead with n=1 must degrade to non-chart presentations [DESIGN RECOMMENDATION] (D-19). |
| C-20 | Learning alerts origin | S1 §7.1 "Learning Alert" implies a system-generated insight | S3 TCH-003: alerts are prepared by the content team | Resolved | MVP: alerts are content-curated rules, not ML [CONFIRMED]. Wording must not claim algorithmic detection. |
| C-21 | Teacher can select skills across grades/subjects | S1 TCH-005 unanswered | S3 TCH-005: "بله" | Resolved | Multi-grade, multi-subject selection allowed in one assignment [CONFIRMED]. |
| C-22 | Duplicate assignment detection | S1 TCH-016 asks the rule | S3 TCH-016: unlikely, but the system should warn; TCH-017: "duplicate" has no meaning in this concept | Resolved | Non-blocking duplicate warning at publish; no "Duplicate" action on an existing assignment [CONFIRMED]. |
| C-23 | Editing an assignment after students start | S1 TCH-017/TCH-018 open | S3 TCH-017: Edit/Reschedule/Cancel allowed; TCH-018: changes have no effect on already-recorded answers | Resolved | Edit/Reschedule/Cancel allowed; recorded answers immutable [CONFIRMED]. |
| C-24 | Mastery threshold | S3 STU-020: medals at SmartScore 80 / 90 / 100 | S3 PRA-007: a session completes at 100 or on student exit | Unresolved | D-06: what "Mastered" means, and whether 80 is the mastery threshold. |
| C-25 | Class removal effects | S1 TCH-012 open | S3 TCH-012: no effect on past records; from removal date forward, data is excluded from class aggregates | Resolved | Historical retention + aggregate exclusion [CONFIRMED]. Requires a "membership period" concept in the data model (§18.2). |
| C-26 | Sign-up path | S1 AUTH-002 / PRD-002 open; S3 "verbal" | S2 §1.3: students receive username/password from the school; no self-registration described | Resolved (provisional) | No self-service sign-up in the first release; account provisioning is out of product UI [CONFIRMED-provisional] pending verbal confirmation (D-04). |


## 3. PRODUCT DEFINITION


### 3.1 Product statement

[CONFIRMED — S2 §1.1, S1 §1.1]

Naranj is a responsive web-based education platform for practising and strengthening academic skills. A student practises a skill that a teacher has assigned, that the system has recommended, or that the student has chosen from the Skill Library; after each answer the student receives educational feedback, sees their progress, and decides what to practise next. A teacher finds existing system content, assigns skills to a class or to specific students, builds quizzes from the system question bank, follows a teaching plan, and uses analytical reports to support learning.

Two clarifications that shape everything downstream:

1.  [CONFIRMED] The teacher does not author or edit questions. Skills and questions are selected from existing system content. (S1 §2 "تألیف سؤال"; S2 §6.2 "هیچ دکمه‌ای برای ساخت یا ویرایش سؤال توسط معلم طراحی نشود")

2.  [CONFIRMED] The product is a responsive web application, explicitly not a native Android/iOS app. Laptop and tablet are the primary design targets, mobile is supported but secondary. (S1 §2, S2 §1.3)


### 3.2 The problem Naranj solves

[CONFIRMED — S1 §1.2, S2 §1.2] Four problems, stated in the sources and preserved here because each maps to a specific UX obligation:


| # | Problem (source meaning) | UX obligation created |
| --- | --- | --- |
| P-1 | The student does not know which skill to practise right now or where to start. | The landing page must answer "what do I do now?" in one glance and one action. Every discovery surface needs a next-step recommendation. |
| P-2 | Simply seeing "right/wrong" after a wrong answer is not enough; the student must understand the correct answer and the solution method. | Feedback is an instructional surface (result + correct answer + explanation + solving method), not a score event. |
| P-3 | The student must see recorded progress and return to practice without losing their way. | Progress must be visible and honest about what is saved; resume must be a first-class, one-click path. |
| P-4 | The teacher must find the right skill, assign it to the right recipient, follow the deadline, and act on reports — without hopping between scattered tools. | One teacher environment: class context is global, content selection is multi-select and re-usable across Assignment / Quiz / Plan, reports end in an action. |


### 3.3 Value proposition

[CONFIRMED — S2 §1.3, restated for both roles]


| Student value | Teacher value |
| --- | --- |
| Find the right skill quickly | Find existing skills by subject, grade, topic and class need |
| Practise with varied question types and understand the answer | Create skill assignments and system-question-based quizzes |
| See progress, SmartScore and achievements | See class progress, individual performance, and skills needing attention |
| Continue practice without getting lost | Move from a report directly to the next action, e.g. assigning a skill |


### 3.4 Educational context of operation


| Dimension | Confirmed context | Source |
| --- | --- | --- |
| Audience age | 9–15 years | S2 §1.3, S1 §1.3 |
| Audience scope | All students (not gender-segregated) | S3 PRD-002 |
| Subject scope at MVP | Mathematics; language and science are on the development roadmap | S2 §1.3, S1 §2 |
| Grade scope | Grade 4 for the first (Dey) release; at least grades 4, 5, 6 for the following academic year | S3 SCP-001 |
| Content volume | ~300 skills per grade — an estimate, not a confirmed count | S1 §2 |
| Language | Product is bilingual by decision; which languages, and the translation scope, are not confirmed | S2 §1.3 (bilingual decision) + S1 A11Y-001 (open) |
| Directionality | RTL is the operative direction, with mixed-direction content (mathematics, Latin numerals, LTR technical tokens) | S1 §12 |
| Institutional context | School-provisioned accounts; classes are created by a teacher or school admin; a class code lets students join | S2 §1.3, S3 TCH-009, AUT-003 |
| Assessment context | No initial Diagnostic Assessment in the MVP | S2 §1.3, S1 §2, S3 SCP-007 (definition supplied, excluded) |
| Release horizon | First release targeted at the start of Dey (late December); "1 Dey" appears as the internal target | S3 PRD-003 |


### 3.5 Core product capabilities (capability map)

[CONFIRMED capabilities] — these exist in the source requirement set. The right-hand column states the architectural consequence, not a design opinion.


| Capability | What it lets a user do | Roles | Status | Architectural consequence |
| --- | --- | --- | --- | --- |
| Authentication & role routing | Sign in with school-issued credentials; be routed to the correct role home | All | CONFIRMED (S2 §1.3, S1 §3.1) | One shared sign-in; no role picker; role resolved server-side |
| Password recovery | Recover access via email or SMS | All | CONFIRMED (AUT-005) | Recovery flow with two channels; still needs identity-verification logic (D-15) |
| Class membership | Join a class with a code; be added manually by a teacher | Student, Teacher, Admin | CONFIRMED (AUT-003, TCH-011) | Join-class is an anytime action, not a sign-in gate; membership is a data relationship with a start/end date |
| Skill discovery | Browse Subject → Grade → Topic → Subtopic → Skill; search titles; filter | Student, Teacher | CONFIRMED (S2 §1.4, IA-005) | One taxonomy service consumed by two differently-shaped browsers |
| Skill preview | See a skill's learning objective and a few sample questions | Teacher (student variant open) | CONFIRMED for teacher (TCH-006) | Preview is a contextual drawer/route, not a page per skill |
| Practice session | Answer one question at a time; get instructional feedback; see elapsed time and score | Student | CONFIRMED (S1 §6) | Dedicated focused environment, own layout, own state model |
| Assignment | Select one or more skills, choose class and/or students, set deadline and short instructions, review, publish, track | Teacher | CONFIRMED (S2 §4.6, S3 TCH-014…TCH-021) | Multi-step builder + review step + immutable publish event |
| Quiz generation | Choose parameters, generate from question bank, preview, regenerate, publish | Teacher | CONFIRMED (S1 §8.1, S2 §4.6) | Parameterised generator with a preview gate; quiz taking is not yet defined |
| Analytics | Class, student, and subject/topic/skill level reporting; learning gaps; action | Teacher; student variant | CONFIRMED in intent (S1 §8.3, S2 §6.6) | Metric definition required before any chart is designed (D-11) |
| Recommendations | Suggested next skills with a short, human-readable reason | Student | CONFIRMED (S1 §5.3, STU-012…STU-014) | A recommendation is a skill + a reason + a source tier; dismissal is allowed |
| Progress & mastery | Per-skill progress, SmartScore, accuracy, time | Student, Teacher | CONFIRMED in intent, metric undefined | Score display is a slot with an explicit "not available" state |
| Gamification | Coins, badges, goals, medals (bronze/silver/gold at SmartScore 80/90/100), streaks, certificates | Student | CONFIRMED (STU-004, STU-020, STU-021, STU-022) | Reward surfaces are additive layers; they may never block or precede the learning action |
| Rewards store | Spend in-product coins on avatars/customisation | Student | CONFIRMED feature, release decision open (C-16, STU-025) | Transaction-safe purchase with idempotency and balance authority on the server |
| Timetable & teaching plan | See scheduled sessions, plan topics/skills, link assignments/quizzes | Teacher | CONFIRMED page, rules open (S1 §8.2) | Calendar-style surface; only P1 |
| Class management | Create class, manage roster, class code, transfer, co-teachers | Teacher, Admin | CONFIRMED (S3 TCH-009…TCH-013) | Class is the global context object for the teacher shell |
| Notifications | Deadline/assignment/quiz notifications | All | CONFIRMED as a need, rules and channels open (SYS-001…008) | Shell-level inbox with a documented state model; event catalogue pending |


### 3.6 MVP boundaries

[CONFIRMED — explicit exclusions] The following are outside the MVP and must not appear in first-release design work (they may appear as clearly-labelled future surfaces only if the product team asks):


| Out of MVP | Evidence |
| --- | --- |
| Attendance/diagnostic Diagnostic Assessment at onboarding | S2 §1.3, S1 §2, SCP-007 |
| Real-money purchase, in-app payments | S1 §2 |
| Public ranking, leaderboard, public honor ranking | S1 §2, STU-019, S2 §5.6 |
| Social feed, messaging between users | S1 §2 |
| AI Tutor / conversational learning assistant | S1 §13.1 (benchmark only; SYN-003 asks whether it is on the roadmap) |
| Teacher authoring or editing questions | S1 §2, S2 §6.2 |
| SSO / enterprise login | AUT-007 ("خیر") |
| Native mobile applications | S2 §1.3 |

[DESIGN RECOMMENDATION] Treat the above as architectural no-go zones, not merely deferred features: no navigation slot, no empty placeholder, no "coming soon" affordance. Rationale: placeholders create the appearance of scope and consume attention in a low-clutter product. Risk if rejected: scope creep and student expectation of unavailable features.


### 3.7 Relationship model (entities and their UX meaning)

[CONFIRMED entities — S1 §15, S2 §1.4] This is the conceptual model that navigation, permissions, and page composition must obey.

Diagram 1. Source file: diagrams/01_entity_model.mmd

Key relationships, each with a UX consequence:


| Relationship | Confirmed rule | UX consequence |
| --- | --- | --- |
| Skill → Question | A skill has questions; the question is the practice unit | Practice Session is always inside a skill; a question never appears outside a skill context |
| Skill → Subtopic | A skill belongs to exactly one topic/grade context (IA-002 "خیر" to multi-parent) | Navigation can be strictly hierarchical; a skill cannot appear in two branches |
| Skill → Skill (prerequisite) | Prerequisites are defined together with skills, and are primarily an input to the recommender (IA-003) | Prerequisites inform recommendation reasoning, not a hard gate. [CONFIRMED] |
| Student ↔ Class | Membership affects data aggregation and the teacher's roster, not the student's own experience (AUT-006) | The student UI must not gate content on class membership |
| Assignment → Skill | An assignment carries one or more skills (S2 §4.4), order not mandatory (TCH-014) | The assignment is a container of skills, not a linear playlist; the student sees skills, not "step 3 of 5" |
| Assignment → Recipients | A class or selected students, across multiple classes (TCH-015) | Recipient selection must support both "whole class" and "named individuals" without ambiguity |
| Practice Session → Assignment | Sessions may be launched from an assignment or freely | Progress must record the context of practice (assigned vs free) because analytics distinguishes them (BM-IXL-004) |
| Answers → SmartScore → Analytics | Answers are the raw evidence; indicators are derived | No indicator may be shown without a defined denominator and time window (S1 §14) |
| Coin/Badge/Medal | Derived from streaks and completed skills (STU-022); medals at 80/90/100 SmartScore (STU-020) | Reward calculation is server-side and atomic; UI only displays |


### 3.8 Core product loops

Two loops are named in both briefs. Their completeness is verified below against the sources.

3.8.1 Student Learning Loop

[CONFIRMED — S2 §1.4] Sign in → assignment / recommendation / library → skill → practice session → answer → feedback → progress → continue

Diagram 2. Source file: diagrams/02_student_learning_loop.mmd

Verification against sources:


| Loop step | Confirmed? | Note |
| --- | --- | --- |
| Sign in with automatic role detection | Yes | S2 §1.3 |
| Landing page is the role's landing page | Yes | S1 §1.3, S2 §1.3 |
| Three entry routes to practice (assigned / recommended / self-selected) | Yes | S2 §1.3 |
| Practice Session separate from Skill Library | Yes | S1 §6 |
| Answer → submit → evaluation → feedback | Yes | S1 §6.1 (7-step answer cycle) |
| Feedback contains correct answer + explanation + solution method | Yes | S1 §6, S2 §8.2 |
| Progress visible and honest about saved state | Yes | S1 §11.1 |
| Loop can terminate at SmartScore 100 or by student exit | Yes | S3 PRA-007 |
| Loop returns cleanly to landing | Yes | S2 §5.5 "خروج امن" |

[OPEN DECISION in the loop] Two steps the sources do not close: (a) whether a completed assignment is re-enterable and how that is shown on the card (STU-010 confirms re-practice is allowed, but the card state is undefined); (b) whether the "progress" step is a distinct page visit or an inline summary after each skill (S1 §6.3 says session end shows result + next action, which suggests inline first).

3.8.2 Teacher Instructional Loop

[CONFIRMED — S2 §1.4] Review class context → select skill or inspect learning gap → assign practise or build quiz → follow results → decide the next instructional support

Diagram 3. Source file: diagrams/03_teacher_instructional_loop.mmd

Verification against sources:


| Loop step | Confirmed? | Note |
| --- | --- | --- |
| Landing is action-oriented and class-context aware | Yes | S1 §7.1, S2 §6.1 |
| Class context persistent across screens | Yes | S1 §7.1 "Context باید در همه‌ی صفحات مشخص باشد" |
| Skill discovery with preview (objective + sample questions) | Yes | TCH-006 |
| Multi-select skills into assignment/quiz/plan | Yes | S2 §6.2, TCH-005 |
| Assignment created with recipients + deadline + review + publish | Yes | S2 §4.4, S1 §16.2 |
| Quiz generated from bank with preview/regenerate | Yes | S1 §8.1 |
| Analytics reach an action (follow-up assignment) | Yes | S1 §8.3 "Action", S2 §6.6 |
| Learning gaps are explainable, not black-box labels | Yes | ANL-002 (open rule) + S1 §14 "تفسیر داشته باشد" |

[OPEN DECISION in the loop] The teacher loop's entry is under-specified: S1 §7.1 orders the landing content as (1) today's programme and current requirements, (2) recent assignments/quizzes with alerts, (3) class summary and upcoming plan — but the relative priority between "react to a deadline" and "plan ahead" is a product decision (D-08).


### 3.9 Product definition — what Naranj is not

Derived from the evidence base, stated to prevent scope drift:

- Not a learning management system. No timetable ownership of the school, no gradebook of record, no school calendar authority (TCH-020 limits deadline semantics to Iran time; PLAN-001 asks whether the official school calendar is considered — unanswered).
- Not a question-authoring tool. Teachers select; the content team authors (PRA-001, S2 §6.2).
- Not a social product. No feed, no ranking, no messaging (S1 §2).
- Not an assessment-of-record system. Quizzes exist, but grading rules, attempts and result visibility are all unconfirmed (QUIZ-005, QUIZ-007).
- Not an AI tutor. S1 §13.1 explicitly limits the ambition to "guided, content-bound help" and marks conversational AI as needing policy and oversight.

## 4. PRODUCT GOALS AND VALUE PROPOSITION


### 4.1 Primary success metric

[CONFIRMED — S3 PRD-001] The primary product indicator is the rate of effective, repeated weekly practice by students (نرخ تمرین مؤثر و تکرارشونده هفتگی), supported by two secondary indicators:

1.  Assignment Completion Rate

2.  Active teacher usage rate

The clarification notes that fuller detail lives inside the PRD (which was not supplied). [SUPPLIED AND REVIEWED IN v2.1] The operational definitions (numerator, denominator, weekly window, what counts as "effective") are therefore unavailable and must not be invented here.


### 4.2 UX goals (derived from the confirmed metrics)

[DERIVED] Because the primary metric is repeated weekly practice, the UX must optimise for return, not for time-on-page or session length. Every design decision below is traceable to that:


| UX goal | What it means operationally | Where it is enforced in this document |
| --- | --- | --- |
| G-1 Reduce the distance from sign-in to practice | One primary action on the landing page; card → session in one step | §11 STU-02, §12.2, F-STU-07 |
| G-2 Make every practice session safely interruptible | Confirmed answers persist; resume is one action | §16.7, §22 |
| G-3 Make feedback instructional | Result + correct answer + explanation + solution method | §16.6, §25 |
| G-4 Make progress legible without over-claiming | Score slots with explicit "not enough data" states | §20.3, §22.4 |
| G-5 Keep the teacher's path from data to action short | Every analytics surface carries a follow-up action | §13.7, §20.6 |
| G-6 Never let motivation mechanics displace learning | Rewards are additive, never gating | §7.7, §20.7 |


### 4.3 Non-goals for the first release


| Non-goal | Reason |
| --- | --- |
| Maximising session duration | Contradicts the "one question at a time, low distraction" principle and offers no evidence of learning |
| Competitive social engagement | Explicitly excluded (S1 §2, STU-019) |
| Full accessibility certification claim | WCAG level is itself unconfirmed (A11Y-003); this document specifies a target to be confirmed, not a claim |
| Multi-language content parity | Bilingual is confirmed as a decision, the language set is not (A11Y-001) |


### 4.4 Constraint register


| Constraint | Type | Consequence |
| --- | --- | --- |
| Responsive web only (no native apps) | Product | Touch targets, viewport policy, and no reliance on native affordances (§23) |
| Laptop + tablet primary, mobile secondary | Product | Layout priority and information-density rules are laptop/tablet-first (§23.2) |
| Ages 9–15 | Audience | Reading level, copy tone, no punitive language, larger touch targets, low text density |
| Mathematics-heavy content | Content | Math rendering, numeric input, RTL/LTR mixing, equivalent-answer validation (§25) |
| RTL with LTR math | Localization | Direction scoping in every component; no mirrored math (§24.2) |
| Content authored centrally, not by teachers | Operational | No authoring UI; preview becomes the teacher's quality gate (§13.3) |
| No Diagnostic Assessment | Product | Cold-start recommendation must rely on curriculum defaults (C-18) |
| Iran time for deadlines | Technical | Single timezone in MVP; explicit timezone label on every deadline (TCH-020) |


## 5. USERS, ROLES, AND PERMISSIONS


### 5.1 Role inventory and design readiness


| Role | Confirmed in sources? | Design readiness | Priority | What the sources actually give us |
| --- | --- | --- | --- | --- |
| Student (دانش‌آموز) | Yes — primary | Ready | P0 | Goals, needs, 7 page requirement blocks, 10 flows, states |
| Teacher (معلم) | Yes — primary | Ready | P0 | Goals, needs, 7 page requirement blocks, 10 flows, class/assignment rules |
| Parent (والد) | Named only | Not ready | P2 | Only: view child's assignments and progress at an authorised level; deadlines and support needs; privacy and disconnect; "shares pages with the teacher/student roles; only analytics indicators differ" |
| School Admin (مدیر مدرسه) | Named only | Not ready | P2 | Only: create/manage school; create accounts; create classes and assign teachers; aggregate and individual school-level reporting; year/grade transitions; audit |
| System Admin (ادمین سیستم) | Added by clarification (SCP-005) | Not defined at all | — | Only that the role must exist and that it is the role responsible for content/question-bank administration. No pages, permissions, or flows. |
| Content Admin / content team | Implied as an organisational function, not a product role | Not a product role | — | Owns question bank, learning alerts, answer-evaluation decisions (SCP-005, TCH-003, PRA-010). Treated as a back-office capability, not an in-product role. |

[DESIGN RECOMMENDATION] Design only Student and Teacher in the current phase. For Parent and School Admin, design nothing new: reuse the authenticated shell, the notification centre, profile/settings, and the analytics surface with a restricted indicator set — and defer until the product team confirms C-13/D-02. Rationale: the sources give role intent without a single confirmed screen, and inventing parent or admin experiences would violate the brief's own instruction. Risk if rejected: rework of navigation and permission scaffolding if parent/admin are actually in the Dey release.


### 5.2 Role profiles

5.2.1 Student


| Dimension | Definition | Source |
| --- | --- | --- |
| Primary goal | Know which skill to practise now, understand answers, see progress, stay motivated | S2 §2.1 |
| Age/reading level | 9–15; copy must be short, precise, polite, encouraging | S2 §1.3, §9.2 |
| Common situations | Doing a deadline-bound assignment; optional practice after school; resuming unfinished practice; acting on a system suggestion; viewing medals; buying a virtual item | S2 §2.1 |
| Key tasks | Start/continue assignment; browse library; search; practice; read feedback; use a hint; exit safely; review progress; view achievements; spend coins; join a class | S1 §5, S2 §5 |
| Data they may see | Their own answers, progress, scores, achievements, coins, assignments addressed to them; the skill catalogue | S2 §8.1 |
| Data they may not see | Any other student's data; class aggregates; teacher analytics; other classes | S2 §8.1 |
| Access boundaries | Everything inside their own account; content is not gated by class membership (AUT-006) | S3 |
| Unresolved | Whether they can change grade/subject freely (STU-006 answered "yes" — so confirmed), whether completed skills are re-enterable from the card (STU-010 yes for practice, card state open), whether recommendation dismissal persists | S3 |

5.2.2 Teacher


| Dimension | Definition | Source |
| --- | --- | --- |
| Primary goal | Spend little time to create an assignment, follow student activity, and take an instructional decision about weaknesses | S2 §2.2 |
| Common situations | Lesson preparation; skill selection; assigning to a class or selected students; building a quiz; following deadlines; reviewing reports; planning the next session | S2 §2.2 |
| Key tasks | Switch class; manage roster; find/preview/select skills (single and multi); create/review/publish/edit/reschedule/cancel an assignment; generate/preview/regenerate/publish a quiz; read class/student/skill analytics; create a follow-up assignment; maintain a teaching plan | S1 §7–8, S2 §6 |
| Data they may see | Their own classes, their students' data within authorised scope, class aggregates, their own assignments/quizzes/plans | S2 §8.1 |
| Data they may not see | Classes they do not teach; other schools; school-level aggregates (that is the School Admin's surface); individual student data outside authorized scope (ANL-003 unanswered) | S1 §2.2, ANL-003 |
| Access boundaries | The teacher's authorisation boundary is the class, not the organisation. Primary vs secondary teacher differ in access level (TCH-013 "فرق معلم اصلی و فرعی در میزان دسترسی‌شون هست") — the content of that difference is undefined | S3 TCH-013, D-10 |
| Unresolved | Exact access delta primary/secondary; whether a teacher can see individual student data belonging to a class they don't teach; audit expectations | TCH-013, ANL-003, STATE-005 |


### 5.3 Role and permission matrix

Legend: F = full (create/edit/manage) · R = read within scope · S = self/own only · — = no access · ? = unresolved in sources.


| Capability | Student | Teacher (primary) | Teacher (secondary) | Parent | School Admin | System Admin |
| --- | --- | --- | --- | --- | --- | --- |
| Sign in / password recovery | S | S | S | ? | ? | ? |
| Add class code / join class | F (self) | — | — | — | — | — |
| Create class | — | F | ? (probably —) | — | F | F |
| Edit class metadata (title, school, subject, year) | — | F | ? | — | F | F |
| Manage class code (generate/renew/void) | — | F | ? | — | F | F |
| Add student manually to roster | — | F (TCH-011) | ? | — | F | F |
| Remove student / transfer | — | F | ? | — | F | F |
| View roster | S (own classes) | R | R | — | R | R |
| Browse Skill Library | R | R | R | — | ? | R |
| Preview skill (objective + sample questions) | ? (teacher-only confirmed) | R | R | — | ? | R |
| Practise a skill | F | ? (not described) | ? | — | ? | ? |
| Create/edit/delete questions or skills | — | — (explicitly forbidden) | — | — | — | F (SCP-005 intent) |
| Create assignment | — | F | ? | — | ? | ? |
| Select recipients (class / individuals) | — | F (authorised only) | ? | — | ? | ? |
| Publish / edit / reschedule / cancel assignment | — | F (TCH-017) | ? | — | ? | ? |
| Track assignment progress (all students in class) | — | R | ? | R (child only, level ?) | R | ? |
| View own assignment status/results | R | R | R | R (child, level ?) | R | ? |
| Generate / preview / regenerate / publish quiz | — | F | ? | — | ? | ? |
| Take a quiz | ? (undefined, QUIZ-006) | — | — | — | — | — |
| View student answer-level log | — | ? (BM-IXL-003) | ? | — | ? | ? |
| View class analytics | — | R | ? | — | R | R |
| View individual student analytics | — | R (authorised) | ? | R (child, level ?) | R (ADM-004) | ? |
| View own analytics | S | — | — | — | — | — |
| View school-level aggregate analytics | — | — | — | — | R | R |
| Create follow-up assignment from a report | — | F | ? | — | — | — |
| Maintain timetable / teaching plan | — | F (if authorised — PLAN-002) | ? | — | ? | ? |
| View/earn coins, badges, medals | S | — | — | — | — | — |
| Spend coins in store | S | — | — | — | — | — |
| Edit own profile | S (SYS-005 open) | S (SYS-005 open) | S | ? | ? | ? |
| Manage notification preferences | ? (SYS-003) | ? | ? | ? | ? | ? |
| Audit log access | — | — | — | — | ? (ADM-004) | ? |
| Account deletion/suspension | — | — | — | — | ? (SYS-007) | ? |

Notes on the matrix

- [CONFIRMED] A teacher may only select recipients they are authorised for: "معلم فقط گیرنده مجاز را انتخاب می‌کند" (S1 §16.2).
- [CONFIRMED] The student sees only their own reports and assets; the teacher only authorised class/student reports (S2 §8.1).
- [OPEN DECISION] Every ? in the matrix is a real permission gap. The high-impact ones are consolidated in D-10 (primary/secondary teacher), D-17 (parent data level), D-18 (admin operational scope), D-28 (profile editability), D-20 (student answer-level visibility to teachers).
- [TECHNICAL VALIDATION] Permission must be enforced server-side per request, with the class as the authorisation boundary; the UI must render "permission denied" without disclosing data (S1 §11 Permission Denied rule).

### 5.4 Account and identity model


| Question | Answer | Source / status |
| --- | --- | --- |
| Who creates accounts? | The school provides the student's username/password; teacher accounts are created by admin or school. Sign-up route is not confirmed. | S2 §1.3 + AUT-002 (verbal) → [OPEN DECISION] D-04 |
| Is there a role picker at sign-in? | No | [CONFIRMED] S2 §1.3, S1 §3.1 |
| Can one account hold multiple roles? | Yes | [CONFIRMED] SCP-004 |
| How is the role chosen for a multi-role account? | Not defined | [OPEN DECISION] D-03 |
| Is SSO supported? | No | [CONFIRMED] AUT-007 |
| Password recovery channels | Email and SMS | [CONFIRMED] AUT-005 |
| Identity verification for recovery | Not defined | [OPEN DECISION] D-15 |
| When is a class code entered? | After first sign-in; code entry is available at any time | [CONFIRMED] AUT-003 |
| Class code rules (length, expiry, attempts, reuse) | Technical team decides | [TECHNICAL VALIDATION] D-14 |
| What if a student has no class? | "No meaningful difference" for the student; class matters for data structure and teacher rosters | [CONFIRMED] AUT-006 |
| Remember-me / shared device policy | Technical team decides | [TECHNICAL VALIDATION] D-21 |


### 5.5 Permission-derived UX requirements


| Requirement | Rationale |
| --- | --- |
| Navigation must be generated from the resolved role, not from a static menu | Multi-role accounts (C-14) make any static menu wrong for some users |
| Every page must define a "permission denied" state | S1 §11 requires a Permission Denied state that does not disclose data |
| Session expiry must be recoverable without losing confirmed practice answers | S1 §11.1 + §22 |
| Data visibility must be stated in plain language on analytics surfaces | Teachers must know whether they are seeing a class aggregate or an individual; parents must know their authorised level (PAR-003 open) |
| A student must never see a class-level construct exposed as "your class ranking" | Ranking is excluded (STU-019); class exists for teachers' data structure only (AUT-006) |


## 6. MVP SCOPE AND PRIORITIES


### 6.1 Priority definitions

Following the source note that priority determines design, test and delivery order rather than feature value (S1 §2.1 note; SCP-002):


| Priority | Definition used in this document | Design obligation |
| --- | --- | --- |
| P0 — Core | Required for the primary learning loop to function end to end. Without it, no user can complete the product's core job. Must be wireframed, tested, and delivered first. | Full specification in this document: all 18 attributes, all states, responsive and accessibility rules. |
| P1 — MVP completion | Required for the MVP to be usable by a real teacher in a real class, and to complete the student's motivational/progress loop. Designed in the same cycle as P0 but after it. | Full page specification; interaction detail may be resolved during wireframing. |
| P2 — Motivational / deferrable | Enhances the experience; not required for the core loop; may ship later without breaking the product. | Structure and states specified; visual detail deferred. |


### 6.2 Page priority

[CONFIRMED — S1 §2.1, S2 §3.3]


| Priority | Student | Teacher |
| --- | --- | --- |
| P0 | Sign in; Student Landing; Skill Library; Practice Session; Question Feedback (see C-02: implemented as a session state, not a route) | Sign in; Teacher Landing; Skill Library; Class management / student roster; Assignments; Analytics |
| P1 | Recommendations wall; Student Analytics | Quiz Generator; Timetable & Teaching Plan |
| P2 | Honor Roll; Rewards Store | — |

[DERIVED] Note the asymmetries: the student's discovery experience is P0 while their analytics is P1; the teacher's analytics is P0 while their quiz generator and planning are P1. This reflects the difference in loops: the student must be able to reach practice immediately; the teacher must be able to act on data immediately.


### 6.3 What the MVP must prove

[DESIGN RECOMMENDATION] Given the confirmed success metric (repeated weekly practice; assignment completion; active teacher use), the MVP design must demonstrate three things:

1.  A student can go from sign-in to an answered question in one interaction and without reading a page of text.

2.  A student who leaves mid-skill can resume without any loss of confirmed answers and without wondering whether their work was saved.

3.  A teacher can go from "this skill is weak in my class" to a published follow-up assignment in under four screens.

Each is testable; each becomes a task in the validation plan (§27.6).


### 6.4 MVP inclusion/exclusion summary


| In scope | Out of scope (explicit) | Deferred / unresolved |
| --- | --- | --- |
| Sign-in + recovery (email/SMS) | Self sign-up | Multi-role routing rule (D-03) |
| Role landing pages | Public marketing site beyond a single product landing page | Public landing content (AUTH-001 verbal) |
| Skill Library (student & teacher) with search | Rich content authoring/preview for teacher | Student skill preview (not confirmed) |
| Practice Session with all 17 question types | AI tutor | Workbook-derived per-type inventory (§17.9 / Appendix A) |
| Instructional feedback + hints | Retry after incorrect answer | Hint content policy |
| Assignments (create → review → publish → track → edit/reschedule/cancel) | Duplicate action | Editing effect on live assignments (partially confirmed: no effect on recorded answers) |
| Quiz generation (parameters → generate → preview → regenerate → publish) | Quiz taking experience | Quiz parameters, attempts, grading (D-22) |
| Teacher analytics (class/student/skill) + follow-up action | School-level analytics | Metric definitions (D-11) |
| Student analytics (zero-state capable) | Peer comparison | Indicator set (D-19/GAP-03) |
| Recommendations with reasons + dismissal | Diagnostic assessment | Recommendation inputs (STU-011 verbal) |
| Coins, badges, goals, medals, certificates | Public ranking | Coin earning rates (STU-022 partial) |
| Rewards store (in-product coins) | Real-money purchase | First-release inclusion (D-13) |
| Class management, roster, class code, co-teachers | Year/grade rollover automation | Primary/secondary access delta (D-10) |
| Timetable & teaching plan (P1) | School calendar integration | Conflict/rescheduling rules (PLAN-004) |
| Notifications shell + state model | Channel strategy (SMS/email/push) | Event catalogue, channels (D-23) |


## 7. UX STRATEGY AND PRINCIPLES


### 7.1 Strategy in one page

[DESIGN RECOMMENDATION] Naranj's experience strategy is "one obvious next step, with the evidence of learning always one layer away."

- For the student, the product is a guided practice lane: every screen answers "what do I practise now?" and then gets out of the way.
- For the teacher, the product is an action console: every screen answers "what needs me today?" and ends in an action.
- For both, complexity is not removed but relocated: the content hierarchy, the question inventory, the metric definitions and the permission model all exist, but they are surfaced progressively and only in the context where they are needed.
This strategy is the basis for the low-clutter direction in §8 and for every principle below.


### 7.2 Principles

Each principle is written as an operating rule with a testable interface consequence. Principles marked [CLIENT DIRECTION] are confirmed by the commissioning brief rather than by the uploaded sources; all others are derived from confirmed source requirements.

P-01 · Progressive Disclosure


| Field | Content |
| --- | --- |
| Definition | Show the minimum needed to take the current decision; reveal depth on demand, in place, without losing context. |
| Why it matters for Naranj | The confirmed content model has six levels (Subject → Grade → Topic → Subtopic → Skill → Question) and ~300 skills per grade. Rendering that hierarchy flat is the single biggest usability risk in the product. |
| Expected user behaviour | The student opens one topic, scans 5–10 skills, starts one. The teacher filters to a topic, then previews one skill, then multi-selects. |
| Interface behaviour | Two-level reveal: Topic list → expanded Topic containing skills. Subtopic appears as an in-list grouping label, not a separate navigation level, unless a topic has no subtopics. Detail (objective, sample questions, class performance) appears in a drawer/panel. |
| Practical design implications | Never render more than ~15 skill rows in one view without pagination or progressive loading (S1 §4.1 requires frictionless loading at real data volume). Search and filters are always visible even when browse is collapsed. |
| Correct implementation | Skill Library: grade/subject context bar, then collapsible topic sections; each row shows skill name + status; a row action "Preview" opens a side panel with objective and sample questions. |
| Mistake to avoid | A full tree expanded by default, or a separate page for every subtopic, forcing 4 clicks before the student sees a single skill. |

P-02 · Recognition over Recall


| Field | Content |
| --- | --- |
| Definition | Present the options and the current state; never require the user to remember a name, a code, a filter, or a previous screen. |
| Why it matters for Naranj | Students must recognise which skill they were practising (names are long and similar); teachers work across several classes and must not have to remember which class context they are in. |
| Expected user behaviour | The student resumes from a visible "Continue" card rather than searching for the skill name. The teacher confirms the active class before acting. |
| Interface behaviour | Context is always displayed: active class in the teacher header (TCH-002 confirms a switcher at the top of the page); active subject/grade in the library; skill name + topic in the practice session header. Filters and selections persist visibly, and the set of selected skills is shown throughout the assignment builder (S2 §6.2). |
| Practical design implications | Every screen that depends on a context must display it in the same position. Selection counts are visible ("3 skills selected") with an expandable list. No action may silently apply to a different class than the one displayed. |
| Correct implementation | Assignment builder keeps a persistent mini-summary: class name, recipient count, selected skill count, deadline — visible on every step. |
| Mistake to avoid | A teacher publishing to the wrong class because the class was only visible on step 1. |

P-03 · Cognitive Load Reduction


| Field | Content |
| --- | --- |
| Definition | Reduce simultaneous decisions, simultaneous numbers, and simultaneous text on any surface. |
| Why it matters for Naranj | The confirmed audience is 9–15 and the confirmed practice surface must hold a question, its media, an answer input, a timer, and a score. That is already at the limit of working memory. |
| Expected user behaviour | The student's attention goes to the question, not the chrome. The teacher scans one summary, not a dashboard of twelve widgets. |
| Interface behaviour | Inside a practice session, score and timer are visually secondary (S2 §5.5: "امتیاز و زمان نباید مزاحم تمرکز روی سؤال شوند"). Outside practice, one primary decision per screen. Language is short and age-appropriate (S2 §9.2). |
| Practical design implications | Cap simultaneous numeric indicators per card at 2. Cap the student landing page at one primary action plus two supporting sections above the fold. Cap teacher landing "alert" items at 3 with a "view all" path. No decorative chart may occupy a primary zone. |
| Correct implementation | Practice Session header holds skill name, question number, elapsed time, and score in a single low-emphasis row, with the question area beginning immediately below. |
| Mistake to avoid | A dashboard with five charts, a streak calendar, a coin balance, and three task lists competing on the same screen. |

P-04 · Clear Visual Hierarchy


| Field | Content |
| --- | --- |
| Definition | Every screen has exactly one visually dominant element that corresponds to the primary action. |
| Why it matters for Naranj | Two documented failures are hierarchy failures: the source explicitly forbids motivational content from hiding the learning action (S2 §5.1), and forbids important action information being buried under decorative charts (S2 §6.1). |
| Expected user behaviour | The eye lands on the one thing to do; secondary things are visibly secondary. |
| Interface behaviour | A three-tier hierarchy: primary action (single, filled, top of the action zone) → content (lists, cards, the question) → support (score, time, secondary links, motivational widgets). Hierarchy is expressed by size, position, and emphasis — never by colour alone. |
| Practical design implications | Designers must be able to point at one element per screen and name it the primary action. If two candidates exist, the screen is wrong. |
| Correct implementation | Student Landing: one urgent assignment card in the primary zone with a single "Start" action; progress/coins below the fold. |
| Mistake to avoid | Giving "View rewards store" the same visual weight as "Continue assignment". |

P-05 · One Primary Action per Screen


| Field | Content |
| --- | --- |
| Definition | One screen, one obvious action; other actions are secondary and never compete. |
| Why it matters for Naranj | This is an explicit benchmark-derived design decision in the source set: "یک اقدام اصلی در هر صفحه" (S1 §14). |
| Expected user behaviour | Users do not hesitate; the most common task is always the easiest. |
| Interface behaviour | Secondary actions are visually subordinate or moved to contextual menus. In multi-step flows, "Next/Review" is the single primary control and "Cancel/Back" is quiet. |
| Practical design implications | A screen with two filled buttons of equal weight is a defect. Destructive actions are never the primary action. |
| Correct implementation | Assignment review step: "Publish" is the only primary; "Edit" and "Save as draft" (if drafts exist — see D-07) are secondary. |
| Mistake to avoid | Practice Session with both "Check" and "Next" enabled at once. |

P-06 · Context Preservation


| Field | Content |
| --- | --- |
| Definition | The user's context — class, filters, selection, position, draft — survives navigation, refresh, and return. |
| Why it matters for Naranj | Confirmed rule: filters, recipients, and drafts must not be cleared without reason during normal navigation (S1 §11.1). Teacher flows are long (class → library → select → builder → publish); losing selection is a real cost. |
| Expected user behaviour | The teacher filters to topics, previews three skills, returns, and the filter is still there. |
| Interface behaviour | Selection state and filters live in the URL or a session store; returning to a listing restores scroll position and filters where feasible. "Back" never destroys a completed step. |
| Practical design implications | Any list that supports filtering must define its persistence behaviour. Drill-down must be reversible (breadcrumb or back preserves state). |
| Correct implementation | From Teacher Analytics, "Assign skill" launches the builder pre-filled with the skill and the class; cancelling returns to the same report view with the same filters. |
| Mistake to avoid | Starting assignment creation from the Skill Library and returning the teacher to an unfiltered first-level library. |

P-07 · Consistency and Predictability


| Field | Content |
| --- | --- |
| Definition | The same concept behaves the same way everywhere, especially statuses, labels, and action patterns. |
| Why it matters for Naranj | The source explicitly requires that status labels ("شروع"، "ادامه"، "تکمیل‌شده"، "تکلیف‌شده"، "پیشنهادشده") mean the same thing on every page (S2 §9.2). The conflict between two status vocabularies (C-04/C-05) makes this the highest-risk consistency area in the product. |
| Expected user behaviour | Users learn one pattern and apply it everywhere; they trust that "Completed" means completed. |
| Interface behaviour | One status vocabulary per axis (§18.4), one button pattern for start/continue, one place for the primary action, one pattern for drawers, one pattern for confirmation. |
| Practical design implications | A status glossary is a deliverable (§18.4). Any new status requires a definition, a colour, an icon, a label, and a permitted transition. |
| Correct implementation | "ادامه" always resumes an in-progress skill; "شروع" always starts a not-started skill; both appear in the same position on every card type. |
| Mistake to avoid | Assignment list saying "Active" while the roster says "In progress" and the student card says "Attempt" for the same condition. |

P-08 · Feedback and System Status Visibility


| Field | Content |
| --- | --- |
| Definition | The system always tells the user what it is doing, whether their work is saved, and what happens next. |
| Why it matters for Naranj | Confirmed: an answer must never be shown as "Saved" until the server confirms it; the difference between Pending and Saved is a stated requirement (S1 §6.3, §11). Weekly return (the primary metric) depends on the student trusting that their work is kept. |
| Expected user behaviour | The student never re-answers a question out of doubt; the teacher never double-publishes. |
| Interface behaviour | Explicit, textual states: saving / saved / not saved / offline. Publish and purchase are idempotent and guarded. Loading states disable repeat actions. |
| Practical design implications | Every mutation needs a status model, not just a spinner. Every page needs Loading / Empty / Error definitions. |
| Correct implementation | After submitting an answer: the submit control enters "checking" and disables; on confirmation, a persistent "saved" indicator appears in the session footer; on network failure, the answer is marked "not saved" with a retry path. |
| Mistake to avoid | A checkmark shown optimistically before the server confirms. |

P-09 · Error Prevention and Recovery


| Field | Content |
| --- | --- |
| Definition | Prevent errors before they happen; when they happen, preserve the user's work and offer one clear recovery path. |
| Why it matters for Naranj | The source states: on error, preserve input, explain, offer retry (S1 §11). Teacher flows contain irreversible-looking actions (publish, cancel); student flows contain vulnerable moments (network loss mid-answer). |
| Expected user behaviour | Users recover without leaving the task or losing work. |
| Interface behaviour | Validate locally before submit (incomplete/invalid answers flagged before sending); confirm destructive actions with consequences stated; never lose drafts; make failure states explain what was and was not saved. |
| Practical design implications | Every flow needs an alternate/error path table (§15). Every confirmation dialog must state the consequence in the user's terms ("Students who started will keep their recorded answers"). |
| Correct implementation | Cancelling a published assignment: dialog explains that recorded answers remain and that the assignment disappears from students' lists. |
| Mistake to avoid | A generic "Are you sure?" with no consequence, or a blank form after a failed publish. |

P-10 · Short Path to Value


| Field | Content |
| --- | --- |
| Definition | The shortest possible distance between arriving and doing the thing the product exists for. |
| Why it matters for Naranj | Confirmed: an assignment card leads directly into practice, with no detail page (STU-005). The primary metric rewards repeated practice, so every extra step costs the metric. |
| Expected user behaviour | Sign in → start → answer within seconds. |
| Interface behaviour | No intermediate confirmation screens; no "read this first" panels; no mandatory tour. Where content must be shown (e.g. instructions), it is shown inside the destination, not as a gate. |
| Practical design implications | Count steps for each core task and treat any step above the minimum as debt. Preserve the confirmed no-detail-page rule, but see C-10/D-09 for how instructions are still surfaced. |
| Correct implementation | Tapping an assignment card opens the Practice Session with the first skill, showing a one-line instruction strip inside the session. |
| Mistake to avoid | Inserting an assignment overview page "for clarity", then a skill list, then a confirmation. |

P-11 · Explainable Recommendations


| Field | Content |
| --- | --- |
| Definition | Any system suggestion shows why it was made, in the user's language, based on data that actually exists. |
| Why it matters for Naranj | Confirmed: every recommended skill carries a short, understandable reason; if there is not enough data, a recommendation is not mandatory; avoid vague labels like "suggested by AI" (S2 §5.3, §8.6). |
| Expected user behaviour | The student trusts the suggestion enough to act, and can choose not to. |
| Interface behaviour | Each card shows: skill name, one-sentence reason, and the start/continue action. Dismissal is available (STU-014 confirms the student may reject/hide). If the reason cannot be produced from real data, the surface falls back to the curriculum-default tier with an honest reason. |
| Practical design implications | Recommendation components require a reason type (assignment-derived / history-derived / prerequisite-derived / curriculum default) so copy can be generated honestly (§20.4). |
| Correct implementation | "Because you have not practised division with remainder yet and your class assignment includes it." |
| Mistake to avoid | "Recommended for you" with no reason, or a reason implying diagnostic knowledge the system does not have (diagnostic assessment is out of MVP). |

P-12 · Learning-Centered Motivation


| Field | Content |
| --- | --- |
| Definition | Motivation mechanics are supplementary: they never gate learning, never punish, and never become the main event. |
| Why it matters for Naranj | Confirmed: coins/badges/goals exist in MVP but must not hide the learning action (S2 §5.1); achievement is personal, not competitive (STU-019); no punishment for wrong answers without justification (S1 §13.2); streak/social pressure is a risk to be avoided (S1 §13.2, S1 §14). |
| Expected user behaviour | Students are encouraged by progress they actually made; they never practise only to farm coins. |
| Interface behaviour | Reward indicators are present but visually subordinate; rewards appear after the learning event (completion, achievement) and never interrupt a session; no loss-aversion mechanics (no "you will lose your streak"), no hearts/lives, no timed pressure in practice. |
| Practical design implications | Re-practice of a completed skill earns no coins (STU-010) — the UI must state this neutrally rather than as a penalty. Streak displays must be informational, with a neutral no-shame state when broken (policy open — BM-DU-002). |
| Correct implementation | Session completion shows result and next step first, then the earned coin/badge as a secondary line. |
| Mistake to avoid | A modal coin animation that blocks "Continue", or a broken-streak warning designed to create anxiety. |

P-13 · Accessibility and Inclusive Interaction


| Field | Content |
| --- | --- |
| Definition | Every core function is operable by keyboard and by touch, understandable by a screen reader, and not dependent on colour. |
| Why it matters for Naranj | Confirmed requirements: no colour-only correct/incorrect signalling; keyboard-operable primary actions with visible focus; a non-drag alternative for drag-and-drop; touch target sizing validated on mobile; WCAG level itself unconfirmed (S1 §12). |
| Expected user behaviour | A student who cannot drag, or who cannot perceive colour differences, can complete any question type. |
| Interface behaviour | Semantic structure, logical focus order, labelled controls, visible focus, text+icon status (not colour alone), and an explicit alternative input for any spatial interaction. |
| Practical design implications | Accessibility is a property of the question component contract, not a later audit (§17.4). Every question type's acceptance criteria include a keyboard-only pass. |
| Correct implementation | Matching question: drag is optional; each left item has a "select item" control and each right item a labelled combobox, with all pairings reachable by keyboard. |
| Mistake to avoid | Correctness communicated by green/red borders only, or a drag-only pairing question with no fallback. |

P-14 · Data Honesty


| Field | Content |
| --- | --- |
| Definition | Never display a number, chart, or label that implies more precision, certainty, or authority than the data supports. |
| Why it matters for Naranj | Confirmed requirement: every indicator must have a definition, denominator and time window, and be interpretable (S1 §14); reports must not be judgmental (S2 §4.5); "weak" labels must not be used without a basis (S2 §6.6); SmartScore's formula is unconfirmed. |
| Expected user behaviour | Users interpret indicators correctly and do not over-generalise from one session. |
| Interface behaviour | Indicators show a definition on demand, a data window, and a sample size; when data is insufficient, the value is shown as "not enough data" rather than zero-with-meaning. Charts degrade gracefully at n=1. |
| Practical design implications | Every metric needs: name, definition, denominator, window, minimum sample, and a "not available" presentation. |
| Correct implementation | Teacher skill report shows "12 of 18 students practised this skill in the last 7 days" rather than a bare percentage. |
| Mistake to avoid | A trend line drawn from two data points, or "Class average: 34%" with no window or denominator. |

P-15 · Forward-Only Integrity and Safe Exit


| Field | Content |
| --- | --- |
| Definition | Practice moves forward only; exiting is always safe and never destroys confirmed work. |
| Why it matters for Naranj | Confirmed: no return to a previous question, no editing a submitted answer, no retry after an incorrect answer (PRA-003, PRA-008, STU-017); confirmed: exit requires confirmation and the session is recoverable (S1 §6, §6.3). |
| Expected user behaviour | The student commits to an answer and moves on; leaving is not risky. |
| Interface behaviour | No "previous" control in the session. The exit control is always available, always confirmed, always safe. Recovery restores the last confirmed state (exact restoration fidelity is a technical question — D-24). |
| Practical design implications | Feedback cannot be contingent on revisiting; explanations must be complete at the moment of feedback. The session summary is the only place where past questions could be reviewed — and that is currently not supported (STU-017). |
| Correct implementation | Exit dialog: "Your answers so far are saved. You can continue this skill from your home page." with "Exit" and "Keep practising". |
| Mistake to avoid | A browser-back gesture that silently discards an unsubmitted answer with no warning. |


### 7.3 Principle conflicts and precedence

Principles can collide. The following precedence is applied in this document:


| Situation | Winning principle | Reason |
| --- | --- | --- |
| Encourage the student vs keep the question focused | P-03 / P-12 (focus and learning first) | Confirmed rule that score, time and rewards must not distract from the question |
| Show more data vs reduce load | P-01 (progressive disclosure) plus P-14 (honesty) | Data is disclosed on demand, and only when it is defined |
| Short path vs capture instructions | P-10 wins for entry; the instruction is relocated into the destination | Confirmed direct-entry decision (STU-005) |
| Consistency vs correctness of a one-off case | P-07 wins unless P-14 (honesty) is violated | Consistency is a confirmed requirement for status language |


## 8. EXPERIENCE ARCHITECTURE


### 8.1 The simplicity direction

[CONFIRMED — client direction] The commissioning brief requires that Naranj be simple to understand and efficient to use, drawing UX qualities (not visuals) from Iranian consumer web products referenced as Bama and Snapp: clear entry points, simple navigation, low information density, strong hierarchy, fast access to common actions, predictable interactions, information presented when needed, minimal unnecessary decisions, guided journeys.

Source note for traceability: this requirement comes from the engagement's own brief (§9), not from S1–S3. It is treated as a confirmed design constraint but is labelled separately so that the product team can see which requirements are external to their own documents.

8.1.1 Translation into Naranj design rules


| Reference quality | Naranj rule (binding for wireframes) | Applies to |
| --- | --- | --- |
| Clear entry points | Every screen is enterable from a named point, and that entry point is listed in the sitemap (§10). No orphan screens, no screen reachable only by deep link. | All |
| Simple navigation | Maximum 5 items in the primary navigation per role; one level of sub-navigation; no mega-menus; no nested tabs deeper than two levels. | All |
| Low information density | Maximum 3 content zones above the fold on landing pages; maximum 2 numeric indicators per card; maximum 6 columns in any table (more via row expansion); body copy on student surfaces ≤ 2 sentences per instruction. | All |
| Strong information hierarchy | One primary action per screen (P-05); a fixed zone order: context bar → page title + primary action → content → support. | All |
| Fast access to common actions | The three most common role actions are reachable in ≤ 1 interaction from the role's landing page (student: continue/start practice; teacher: switch class, create assignment, open analytics). | Landing pages |
| Predictable interactions | The same control does the same thing everywhere: one drawer pattern, one modal pattern, one confirmation pattern, one toast/inline-status pattern, one empty state pattern. | All |
| Information when needed | Detail (skill objective, sample questions, metric definitions, receipts, logs) is always one layer deeper, never on the entry surface. | Library, analytics, store |
| Minimal unnecessary decisions | No configuration choice is presented unless the user's outcome depends on it; defaults are pre-selected and visible. Examples: notification preferences, filter defaults, session settings. | All forms |
| Guided journeys | Multi-step flows (assignment builder) show progress, keep a visible summary, and never lose state. | Teacher flows |

8.1.2 What simplicity must not remove

[DESIGN RECOMMENDATION] The following capabilities are complex but required, and must be relocated rather than deleted:


| Complex capability | Relocation |
| --- | --- |
| Six-level content hierarchy | Browse shows Topic + skills; Subtopic is an in-list grouping; search and filters are always available; grade/subject context is a compact selector |
| 17 question types | One session shell + renderer; the type is invisible to the student, only the answer input changes |
| Metric definitions and denominators | Consistent definition pattern (info affordance → definition, window, n) |
| Multi-class, multi-grade skill selection | Persistent selection tray with count and expandable list |
| Permission breadth | Role-derived navigation; permission-denied states; no disabled controls without a stated reason |
| Deadlines across many assignments | Landing shows the nearest deadline prominently; the rest are a sorted list |


### 8.2 Three experience layers

Diagram 4. Source file: diagrams/04_experience_layers.mmd


| Layer | Purpose | Navigation model | Rule |
| --- | --- | --- | --- |
| Public | Explain the product; provide one sign-in entry | Single page + auth routes | No product data, no role hints beyond copy |
| Authenticated shell | Persistent role environment | Primary nav (≤5) + context bar + utilities | Global navigation is absent only in focus modes |
| Focus modes | Concentrate the user on one task | Exit + in-task steps only | Must provide a safe exit and a visible save state at all times |


### 8.3 Shell architecture

8.3.1 Anatomy of the authenticated shell


| Zone | Contents | Behaviour | Student variant | Teacher variant |
| --- | --- | --- | --- | --- |
| Z-1 Context bar (top) | Product mark; student: subject/grade context when relevant; teacher: active class switcher (TCH-002) + deadline window indicator | Persistent; class switcher opens a list; switching class refetches all class-scoped data | Grade/subject shown only inside the Library and Progress pages, not globally | Class context is global and never silently changed |
| Z-2 Page title + primary action | Page name (left/start), primary action (right/end) | Title is unambiguous; exactly one primary action | — | — |
| Z-3 Content zone(s) | The page's main information | Max 3 zones above the fold on landing pages | One dominant practice block | Data + action pairing |
| Z-4 Support zone | Progress, motivational widgets, secondary links, help | Visually subordinate; collapses below content | Coins, streak, badges live here | Alerts, saved views, "how this is calculated" |
| Z-5 Utilities | Notifications, profile, settings, sign out | Available everywhere in the shell | Same | Same |
| Z-6 Session/persistence indicator | Save status when a mutation is in flight | Textual and persistent, not a transient toast | Critical in practice | Critical in builder/publish |

8.3.2 Focus-mode shell (Practice Session)

- Global navigation is removed (P-03, P-15).
- Retained: skill identity, question position, elapsed time, score slot, exit control, save indicator.
- [CONFIRMED] One question is on screen at a time (S1 §6).
- The exit control is always visible and never hidden behind a menu (S2 §5.5 "خروج امن").

### 8.4 Page composition templates

[DESIGN RECOMMENDATION] Four composition templates cover every page in the inventory. Wireframes must declare which template they use; a page that fits none of them is a design smell.


| Template | Structure | Used by |
| --- | --- | --- |
| T-A · Action Landing | Context bar → 1 primary action block (with its reason/urgency) → 1–2 supporting sections → support zone | Student Landing, Teacher Landing |
| T-B · Browse & Select | Context bar → search + filters → hierarchical list with progressive disclosure → persistent selection tray (teacher) → row actions (start / preview / select) | Skill Library (both roles), Roster |
| T-C · Work Surface | Context bar → item identity + status → data/table → action row that converts data into action | Analytics (class, student, skill), Assignment tracking, Assignment list |
| T-D · Guided Flow | Step indicator + persistent summary → current step content → single primary "Next/Review/Publish" → cancel | Assignment builder, Quiz generator, Join class, Create class, Reset password |

Practice Session is a fifth, specialised composition (T-E · Focus Session) defined in §16.


### 8.5 Student vs teacher experience differentiation

[CONFIRMED framing] The commissioning brief requires the two experiences to differ explicitly; the sources support it substantively (student = guided practice; teacher = operational console).


| Dimension | Student experience | Teacher experience |
| --- | --- | --- |
| Emotional target | Focused, guided, encouraging, easy to understand, learning-centred, minimal distraction | Operational, structured, efficient, context-aware, data-informed, action-oriented |
| Primary question answered | "What do I practise now?" | "What needs me today, and what do I do about it?" |
| Information density | Low. One dominant block, 1–2 supporting blocks, large type, generous spacing | Medium. Dense-but-structured tables allowed, with filters and scannable rows |
| Navigation weight | 4–5 destinations; practice reached in 1 action | 5 primary destinations + always-visible class context |
| Default landing emphasis | The nearest-deadline assignment, then resume, then recommendation | Today's requirements, then alerts, then class summary |
| Numbers shown | Progress/score only when defined; time only as elapsed | Indicators with denominators and windows; no bare percentages |
| Vocabulary | Encouraging, non-judgmental, short (S2 §9.2) | Operational, data-based, consequence-stating (S2 §9.2) |
| Error tone | Reassuring, one recovery action | Precise: what failed, what is saved, what to do |
| Motivation mechanics | Present but subordinate | Absent (no coins/badges for teachers in sources) |
| Density rule | Max 3 content zones; max 2 numeric indicators per card | Max 3 summary indicators per row; tables up to 6 columns; row expansion for detail |
| Selection model | Single selection (one skill to practise) | Multi-selection with a persistent tray |
| Session model | Full-attention focus mode | Guided flows with steps and review |


### 8.6 Practical rules — component-by-component

8.6.1 Navigation

- Primary navigation: ≤5 items, fixed order, same position on every screen of the shell.
- Sub-navigation: at most one level (tabs inside a page); tab state must be reflected in the URL.
- Breadcrumbs: required only in Browse and Analytics drill-downs (Subject → Grade → Topic), and they must be navigable, not decorative.
- The active item is always marked by more than colour (weight + indicator).
- Mobile: primary navigation becomes a bottom bar (≤5 items) or a single menu — recommendation in §23.4.
8.6.2 Cards

- A card answers one question and offers one action.
- Maximum 3 data points per card (e.g. skill name, status, score) plus one action.
- Card action text is a verb tied to state: "شروع / Start", "ادامه / Continue", "مرور / Review".
- No card may be a navigation dead end: every card leads somewhere.
- Cards carrying urgency (overdue, due today) must state the urgency in text, not only in colour.
8.6.3 Tables (teacher)

- Maximum 6 visible columns; everything else moves to row expansion or a detail drawer.
- Sticky header and sticky first column (student name) when scrolling horizontally.
- Row-level actions appear on selection, not on hover only (hover-only actions are inaccessible on tablet).
- Sort state is always visible and resettable.
- Bulk selection uses a header checkbox plus per-row checkboxes with a visible count.
- Every table needs: sortable columns, a filter summary, an empty state with the reason, a "no results for these filters" state, and a loading skeleton.
8.6.4 Filters

- Filters are always visible (not only in a collapsed drawer) on Browse surfaces.
- Filters show their active state as removable chips.
- The filter set is limited to what the content model supports: Subject, Grade, Topic, Subtopic, plus status for teacher views.
- Applying a filter never loses the selected items (teacher selection tray survives filtering).
8.6.5 Forms

- One column of fields on student surfaces; two columns maximum on teacher surfaces at laptop width.
- Labels above fields; no placeholder-as-label.
- Inline validation on blur, not on every keystroke; submit disabled only with a stated reason.
- Multi-step flows keep a persistent summary and allow backward navigation without data loss.
- Destructive or irreversible actions require a confirmation that states consequences.
8.6.6 Dashboards

- Student Progress and Teacher Analytics follow the same skeleton: window selector → headline indicators → breakdown by subject/topic/skill → action.
- No chart without a stated window, denominator, and (where relevant) sample size.
- Charts degrade to tables/lists at low data volume.
- [CONFIRMED] Teacher analytics must end in an action (S1 §8.3; S2 §6.6) — so every analytics page carries an "Assign / Create assignment" affordance with the analysis context pre-filled.
8.6.7 Contextual actions

- Actions appear where their object is: on the assignment row, on the student row, on the skill row.
- Actions that require a different scope (e.g. publishing) escalate to a flow; they do not fire inline.
- Inline actions with side effects require optimistic-state protection (disabled + status), never a silent repeat on double-tap.

### 8.7 Density budget per surface

[DESIGN RECOMMENDATION] A concrete, reviewable budget. Designers should treat exceeding it as a review failure unless justified in writing.


| Surface | Max zones above fold | Max numeric indicators | Max actions in primary zone | Density level |
| --- | --- | --- | --- | --- |
| Public landing | 2 | 0 | 1 (Sign in) | Very low |
| Sign in | 1 | 0 | 1 | Very low |
| Student Landing | 3 | 2 per card | 1 primary + 2 secondary | Low |
| Student Skill Library | 2 (filters + list) | 1 per row | 1 per row | Low–medium |
| Practice Session | 2 (question + answer) | 2 (time, score) | 1 (Submit) | Very low |
| Feedback state | 2 (result + explanation) | 1 (score delta if approved) | 1 (Continue) | Low |
| Student Progress | 3 | 3 headline | 1 (next skill action) | Medium |
| Honor Roll / Store | 3 | 1 (balance) | 1 per item | Low–medium |
| Teacher Landing | 3 | 2 per card | 1 primary + quick actions | Medium |
| Teacher Skill Library | 2 | 1 per row | Multi-select + 1 flow action | Medium |
| Assignment builder | 2 (+ summary rail) | 3 (recipients, skills, deadline) | 1 (Next/Review/Publish) | Medium |
| Assignment tracking | 3 | 3 headline | 1 (follow-up action) | Medium–high |
| Teacher Analytics | 3 | 3 headline, 1 per chart | 1 (assign follow-up) | Medium–high |


## 9. INFORMATION ARCHITECTURE


### 9.1 Global product structure

[CONFIRMED] The public/authenticated split is confirmed by the clarification answer STU-001: a general landing page that everyone sees, containing general product information, from which users sign in; after sign-in each user sees the landing page of their role.


| Context | Purpose | Entry | Exit | Global navigation |
| --- | --- | --- | --- | --- |
| Public site | Explain Naranj to any visitor; provide the single sign-in entry | Direct URL | Sign in, password recovery | None (single page; anchor links only) |
| Authentication | Establish identity; resolve role | Public landing, deep link, expired session redirect | Role landing | None |
| Student environment | Guided learning and practice | Authentication | Sign out, focus modes | 4–5 destinations |
| Teacher environment | Class operations, assignment, quiz, analytics | Authentication | Sign out, focus modes | 5 destinations + global class context |
| Focus modes | Practice Session, Assignment builder, Quiz generator, Join class | From within the environment | Safe exit back to origin | Suppressed |
| Shared utilities | Notifications, profile, settings, help | Utilities area in the shell | Back to previous | Available in shell, suppressed in focus modes |
| Secondary-role environments | Parent, School Admin | Not design-ready | — | Reuse of shell, analytics variant only |
| System/edge surfaces | Session expired, permission denied, not found, offline, error | Global | Recovery path | Minimal, single recovery action |

[DESIGN RECOMMENDATION] Do not create a role-picker or "choose your portal" screen. It would contradict the confirmed automatic role resolution and add a decision the user does not need. Multi-role routing is handled silently (D-03).


### 9.2 Student information architecture

9.2.1 Destinations


| # | Destination | Purpose | Priority | Reached from |
| --- | --- | --- | --- | --- |
| 1 | Home (صفحه آغازین) | Answer "what do I practise now?"; start/continue; see urgent assignments, resume block, recommendations, progress snapshot | P0 | Sign-in; global nav; every safe exit |
| 2 | Skill Library (کتابخانه مهارت) | Find and choose a skill independently | P0 | Global nav; Home "browse" link; empty states |
| 3 | Practice Session (جلسه تمرین) | Answer questions; receive feedback | P0 | Assignment card; recommendation card; skill row; resume block |
| 4 | Session summary | Result, next step, reward acknowledgment | P0 (state of #3) | Session completion |
| 5 | Recommendations (دیوار پیشنهادها) | Explore all suggested skills with reasons | P1 | Home recommendation block ("view all"); global nav (if retained) |
| 6 | Progress (تحلیل عملکرد) | Understand own progress and decide next | P1 | Global nav; Home progress snapshot; session summary |
| 7 | Honor Roll (تالار افتخارات) | Personal achievements, medals, certificates | P2 | Global nav or Home support zone |
| 8 | Rewards Store (فروشگاه جوایز) | Spend coins on avatars/customisation | P2 | Home coin indicator; Honor Roll |
| 9 | Join class (ورود با کد کلاس) | Join a class at any time | P1 | Home (class/account area); settings; post-sign-in prompt on later visits |
| 10 | Profile & settings | Account, display, language, default class context | P1 | Utilities |
| 11 | Notifications | Assignment/deadline notices | P1 | Utilities |

9.2.2 Student primary navigation decision

[DESIGN RECOMMENDATION] Primary navigation = Home · Skill Library · Progress · Achievements/Prizes with Recommendations and Join class as contextual destinations (Home module + utilities). Rationale:

- The confirmed student loop needs Home (route in), Library (self-directed discovery), Practice (focus mode, not nav), Progress (loop closure).
- Recommendations is confirmed as a distinct page (STU-012 mentions a dedicated recommender page with more items) but its job — "show me suggested skills with reasons" — is already the third block of Home. Making it a fifth top-level item competes with Library for the same mental task.
- Honor Roll and Rewards Store are motivational (P2); grouping them under a single "My achievements" entry (with store as a sub-tab) keeps the navigation at 4 items while preserving both confirmed pages.
- Risk if rejected: a 6-item navigation on a 375 px viewport becomes a scrolling bar; the "view all recommendations" path must exist somewhere regardless.
Fallback (if the product team requires all confirmed pages as top-level items): max 5 items = Home · Library · Recommendations · Progress · Achievements(→ Store). Join class then lives in utilities only.

9.2.3 Student hierarchy

Diagram 5. Source file: diagrams/05_student_hierarchy.mmd

9.2.4 Student navigation model


| Navigation type | Content | Where |
| --- | --- | --- |
| Primary | Home, Skill Library, Progress, Achievements & Prizes | Shell, persistent (desktop: side/top; mobile: bottom) |
| Secondary (in-page) | Subject/Grade selector, topic accordion, Progress filters, Honor Roll/Store tabs | Inside each destination |
| Contextual | "Start / Continue / Review", "View all recommendations", "Back to assignment" | On cards, rows, drawers |
| Utility | Notifications, Profile & settings, Join class, Sign out, Help | Utilities area |
| Suppressed | All of the above except exit + save status | Practice Session |


### 9.3 Teacher information architecture

9.3.1 Destinations


| # | Destination | Purpose | Priority | Reached from |
| --- | --- | --- | --- | --- |
| 1 | Home | Today's requirements, alerts, class summary, quick actions | P0 | Sign-in; nav; safe exits |
| 2 | Class context switcher (global control) | Change the active class | P0 | Context bar on every shell screen; settings for default class |
| 3 | Classes (list) | All classes; create class; open class | P0 | Nav; Home class summary |
| 4 | Class detail / Roster | Class metadata, roster, class code, co-teachers, per-class shortcuts | P0 | Classes list |
| 5 | Skill Library (teacher) | Find, preview, and select skills for assignment/quiz/plan | P0 | Nav; Home quick action; Analytics ("assign this skill") |
| 6 | Assignments (list) | All assignments with status filters | P0 | Nav; Home alerts; Class detail |
| 7 | Assignment builder (guided flow: recipients → skills → schedule/instructions → review) | Create an assignment | P0 | Skill Library (selection), Assignments, Analytics, Class detail |
| 8 | Assignment tracking (detail) | Per-student status, per-skill progress, edit/reschedule/cancel, follow-up | P0 | Assignments list; Home alerts; students' rows in Analytics |
| 9 | Quiz Generator | Parameterised quiz creation from the question bank | P1 | Nav or Home quick action; Skill Library selection |
| 10 | Quiz preview / regenerate | Inspect generated questions before publishing | P1 | Quiz Generator |
| 11 | Quiz results | Result visibility per published quiz | P1 (rules open) | Assignments/Quizzes list |
| 12 | Analytics (class / student / skill) | Find needs; act | P0 | Nav; Home class summary; roster row; assignment tracking |
| 13 | Timetable & Teaching Plan | Sessions, topics, linked assignments/quizzes | P1 | Nav or Classes sub-item |
| 14 | Profile & settings | Default class (TCH-001), display, language | P1 | Utilities |
| 15 | Notifications | Deadline/alert notices | P1 | Utilities |

9.3.2 Teacher primary navigation decision

[DESIGN RECOMMENDATION] Primary navigation = Home · Classes · Assignments · Skill Library · Analytics. Quiz Generator and Timetable are reached as contextual actions (Home quick actions, Library selection action, Classes sub-view). Rationale:

- The sources list seven teacher destinations (S2 §4.3). Seven top-level items violates the ≤5 rule (§8.1.1) and, more importantly, splits one mental model: the teacher thinks in terms of class → what I set → how it went.
- Quiz generation is a creation action, like assignment creation, and the source already frames both as "select skills → choose action (Assignment / Quiz / Plan)" (TCH-008 open; S2 §6.2 "افزودن مهارت به تکلیف، آزمون یا برنامه تدریس"). Making Quiz a destination rather than an action would create two parallel creation paths.
- Timetable/Teaching Plan is a planning surface used less frequently than assignments; it belongs under Classes (a class has a timetable) or as a Home card.
- Risk if rejected: teachers who use quizzes daily would need two extra taps. Mitigation: a persistent "Create" affordance with three choices (Assignment / Quiz / Plan) in the page-title zone.
[OPEN DECISION] D-07 captures the final navigation decision; the page inventory supports either arrangement without structural change.

9.3.3 Teacher hierarchy

Diagram 6. Source file: diagrams/06_teacher_hierarchy.mmd

9.3.4 Teacher navigation model


| Navigation type | Content | Where |
| --- | --- | --- |
| Primary | Home, Classes, Assignments, Skill Library, Analytics | Shell, persistent |
| Global context | Active class switcher; academic window where relevant | Context bar, always visible |
| Secondary (in-page) | Class tabs (Overview / Roster / Code & teachers / Timetable); Assignment tabs (Overview / Progress); Analytics level (Class / Students / Skills) | Inside destinations |
| Contextual | Row actions (Preview, Assign, View report), selection tray actions (Create assignment / Create quiz) | Rows, trays, drawers |
| Utility | Notifications, Profile & settings, Help, Sign out | Utilities |
| Suppressed | All except exit + save status | Assignment builder, Quiz generator |


### 9.4 Secondary-role structure (and what is missing)

[CONFIRMED] Parent and School Admin are named roles whose pages and permissions are not specified (S1 §9), and who "share similar pages" with the other roles, differing only in the indicators they see on the analytics page (S2 §6.6 note). System Admin is required to exist (SCP-005) but is entirely undefined.


| Role | Existing structure (reuse) | Missing requirements |
| --- | --- | --- |
| Parent | Authenticated shell → child selector → Home (child's assignments, deadlines, support needs) → Progress (authorised level) → Notifications → Profile | Which data is visible vs confidential (PAR-003); whether parent is read-only (PAR-004); how the parent–child relationship is created and approved (PAR-002); whether active in MVP (PAR-001 / C-13); notification expectations |
| School Admin | Authenticated shell → school overview → accounts → classes & teacher assignment → aggregate analytics → audit | Operational scope (ADM-002); school-level indicators (ADM-003); individual-data access and audit (ADM-004); year/grade rollover mechanics (SYS-007); whether a dashboard exists in MVP (ADM-001) |
| System Admin | None. Only: content/question-bank administration; account and role administration | Everything: identity, navigation, permissions, workflows, audit, error handling for content publication, and the relationship with the content team's tooling (SCP-005) |

[DESIGN RECOMMENDATION] For Parent and School Admin, do not design new shells. Design one role-variant specification for: (a) the child/scope selector, (b) the analytics indicator set, (c) read-only discipline. Nothing else. This preserves the "shared pages" statement without inventing experience.


### 9.5 Content taxonomy

9.5.1 Confirmed taxonomy

[CONFIRMED — S1 §4, S2 §1.4, S3 IA-001/IA-002/IA-003/IA-005]

Subject (درس)

└── Grade (پایه)

└── Topic (موضوع)

└── Subtopic (زیرموضوع)      ← confirmed to exist (IA-001)

└── Skill (مهارت)      ← belongs to exactly one topic context (IA-002)

└── Question (سؤال)


| Level | Confirmed fields / behaviour | UX role |
| --- | --- | --- |
| Subject | Identity, title, language, publication status; MVP = Mathematics | Top-level content filter; roadmap adds language and science |
| Grade | Identity, title, educational system, order; Grade is the context/filter basis (S2 §1.4) | Global context selector in Student Library; filter in Teacher Library |
| Topic | Identity, title, parent, order | The accordion unit of browsing |
| Subtopic | Identity, parent, order (exists) | Grouping label inside a topic; not a separate navigation level by default |
| Skill | Identity, title, description, prerequisites, relations, status; stable | The actionable unit: the row the user starts or selects |
| Question | Identity, type, text, media, answer, solution, validation rules | The unit of practice; never browsed by users |
| Prerequisite (skill → skill) | Defined alongside skills; primarily a recommender input | Used for reason strings and recommendation ordering, not for locking content (no evidence of gating) |
| Search | Titles of skill, subtopic, topic at each grade; a search box on the main page for module titles (IA-005) | Global search inside Skill Library |

[CONFIRMED] A skill cannot belong to multiple topics/grades (IA-002 = "خیر"). This makes the hierarchy a strict tree and lets navigation mirror it exactly.

[CONFIRMED] No skill versioning in the current scope (IA-004). [OPEN DECISION] What happens to historical assignment data if a skill's content changes (D-12).

[CONFIRMED] Grade scope for MVP: grade 4 at first release; grades 4–6 planned for the next academic year (SCP-001). [DESIGN RECOMMENDATION] Therefore the Grade selector must be future-proof (multi-grade data model, single-grade content), and must not be hard-coded to "grade 4" anywhere in the interface.

9.5.2 Taxonomy ↔ navigation relationship


| Taxonomy level | Student navigation | Teacher navigation | Never |
| --- | --- | --- | --- |
| Subject | Context selector inside Library / Progress | Filter in Library; can be mixed in one assignment (TCH-005) | Top-level nav item |
| Grade | Context selector; student may change it (STU-006) | Filter | A page per grade |
| Topic | Accordion section (expand/collapse) | Accordion section | A page per topic |
| Subtopic | Grouping label inside the accordion | Grouping label | A page per subtopic |
| Skill | Row with status + start/continue; optional preview | Row with checkbox, status, class performance, preview | A page per skill (preview is a panel) |
| Question | Invisible | Visible only inside preview/sample | Browse surface |

[CONFIRMED] The source states the browsing order must be visibly Subject → Grade → Topic → Skill and the user must always know their position (S2 §5.2). This is the basis of P-02 and the breadcrumb rule.


### 9.6 Search and discovery


| Aspect | Rule | Status |
| --- | --- | --- |
| Search scope | Skill, Subtopic, and Topic titles, within the selected grade context; plus module titles from the main page search entry | [CONFIRMED] IA-005 |
| Search placement | Always visible on the Library surface (not hidden behind an icon) | [DESIGN RECOMMENDATION] |
| Search behaviour | Type-ahead with results grouped by level (Topic / Subtopic / Skill); selecting a result navigates to the skill row in its hierarchy context, not to a detached page | [DESIGN RECOMMENDATION] |
| Search + filters | Filters act as a scope on search, and search does not clear filters | [DESIGN RECOMMENDATION] |
| No results | State must state what was searched, in which grade, and offer "clear filters" and "browse instead" | [DESIGN RECOMMENDATION] |
| Result volume | Must remain usable at ~300 skills/grade; require pagination or incremental loading (S1 §4.1) | [CONFIRMED requirement, mechanism open] |
| Cross-grade search | [OPEN DECISION] D-25 — whether search spans grades or respects the selected grade | Unresolved (IA-005 only confirms titles per grade) |
| Persistence | Query and filter state survive drill-down and back | [DESIGN RECOMMENDATION] (P-06) |


### 9.7 Proposed route and ID conventions

[DESIGN RECOMMENDATION] A stable naming scheme keeps design, engineering, and analytics aligned. Route strings are illustrative; they exist so that every page in §11, §15, and §30 can be referenced unambiguously.


| Role | Pattern | Examples |
| --- | --- | --- |
| Public | /, /login, /forgot-password, /reset-password | PUB-02 = /login |
| Student | /app/… | /app/home, /app/library, /app/practice/{skillId}, /app/recommendations, /app/progress, /app/achievements, /app/store, /app/join-class |
| Teacher | /teach/… | /teach/home, /teach/classes, /teach/classes/{id}, /teach/library, /teach/assignments, /teach/assignments/new, /teach/assignments/{id}, /teach/quizzes/new, /teach/analytics, /teach/analytics/students/{id}, /teach/timetable |
| Shared | /account, /notifications, /help | Utilities |
| Edge | /session-expired, /403, /404, /offline | SYS pages |

[TECHNICAL VALIDATION] Route-level permission checks, deep-link behaviour after session expiry, and whether class context is a route segment or a session setting are engineering decisions that affect shareable links (D-26).


## 10. SITEMAP


### 10.1 Public and authentication sitemap

Diagram 7. Source file: diagrams/07_public_auth_sitemap.mmd


### 10.2 Student sitemap (with navigation classification)


| Level | Node | Nav type | Notes |
| --- | --- | --- | --- |
| 1 | Student Home STU-01 | Primary | The role landing page (S1 §1.3) |
| 1 | Skill Library STU-02 | Primary | Separate experience from practice (S1 §6) |
| 1 | Progress STU-07 | Primary | P1 |
| 1 | Achievements & Prizes STU-08 / STU-10 | Primary (grouped) | P2; store as sub-tab |
| 2 | Recommendations STU-06 | Contextual (from Home) | P1; fallback to primary if required |
| 2 | Subject/Grade selector | Secondary (in-page) | Confirmed student may change grade/subject (STU-006) |
| 2 | Topic accordion / Subtopic group / Skill row | Secondary (in-page) | Progressive disclosure |
| 2 | Search | Secondary (in-page) | Confirmed (IA-005) |
| 3 | Practice Session STU-04 | Focus mode | Nav suppressed; safe exit + save state |
| 3 | Session summary STU-05 | Focus-mode state | Result + next action + reward acknowledgment |
| 3 | Achievement detail STU-09 | Modal/drawer | Medal condition, date, certificate |
| 3 | Item detail & purchase STU-11 | Modal | Confirm purchase, insufficient coins |
| — | Join class STU-12 | Contextual/utility | Anytime action (AUT-003) |
| — | Notifications SYS-01 | Utility | P1 |
| — | Profile & settings STU-13 | Utility | P1 |


### 10.3 Teacher sitemap

Diagram 8. Source file: diagrams/08_teacher_sitemap.mmd


### 10.4 Shared, modal, drawer and utility map


| Element | Type | Used by | Rule |
| --- | --- | --- | --- |
| Notification centre SYS-01 | Route or panel | Both | Read/unread, archive (SYS-004 open); never blocks the primary action |
| Profile & settings | Route | Both | Profile field editability open (SYS-005) |
| Session expired SYS-02 | Full-page state | Both | Must offer "return to where I was" and never lose confirmed practice answers |
| Permission denied SYS-03 | Full-page state | Both | No data disclosure; one recovery action |
| Not found SYS-04 | Full-page state | Both | Link to role home |
| Offline SYS-05 | Non-blocking banner + local state | Both | Must distinguish saved vs unsaved (S1 §11) |
| Error SYS-06 | Inline or full-page | Both | Retry + what was saved |
| Class switcher | Selector/popover in context bar | Teacher | One active class at a time (TCH-002) |
| Skill preview TCH-08 | Drawer/panel | Teacher (student optional) | Objective + sample questions (TCH-006) |
| Selection tray | Persistent bar | Teacher | Count + expandable list + create action |
| Assignment review TCH-11 | Step in flow | Teacher | Must show skills, recipients, deadline, instructions (S1 §16.2) |
| Confirm dialogs | Modal | Both | Destructive/irreversible only; states consequence |
| Definition popover | Popover | Both | Metric definition, window, denominator (P-14) |
| Toasts/inline statuses | Non-modal | Both | Support only; never carry the only copy of critical state |


### 10.5 Navigation sitemap legend and non-negotiable rules


| Rule | Justification |
| --- | --- |
| Practice Session appears in no navigation bar | It is a focus mode; entering it from nav would break skill context |
| No page exists for a single skill, topic, or question | Hierarchy is navigated in-place (P-01); only skills get rows and previews |
| No "Feedback" route exists | Feedback is a Practice Session state (C-02) |
| Class is a context, not a nav destination, for the teacher's scoped surfaces | TCH-002 confirmation of a single active class; changing it re-scopes every page |
| Every route has one defined entry point | "Clear entry points" rule (§8.1.1) |
| Utilities live in one place for both roles | Consistency (P-07) and a smaller navigation |


## 11. PAGE INVENTORY


### 11.1 How this inventory is structured

- Full specification (18 attributes) is provided for every P0 page, plus the shared state pages. These are the pages a designer can start wireframing immediately.
- Standard specification (10 attributes) is provided for P1 pages: the attributes that require product decisions are listed, while generic states follow the shared state model in §22.
- Structural specification (6 attributes) is provided for P2 pages and secondary-role skeletons.
- Attribute definitions:

| # | Attribute | Meaning |
| --- | --- | --- |
| 1 | Page name / ID | Stable identifier used across this document |
| 2 | Role | Who can open it |
| 3 | Priority | P0 / P1 / P2 (definitions in §6.1) |
| 4 | Primary user goal | The one thing the page must let the user do |
| 5 | Information displayed | The content inventory |
| 6 | Primary action | The single dominant action (P-05) |
| 7 | Secondary actions | Subordinate actions |
| 8 | Key interactions | Behaviours on the page |
| 9 | Entry points | Where the user comes from |
| 10 | Exit points | Where the user can go |
| 11 | Dependencies | Data/services/decisions the page needs |
| 12 | Empty state | What is shown with no data |
| 13 | Loading state | What is shown while fetching |
| 14 | Error state | What is shown on failure |
| 15 | Permission state | What is shown without access |
| 16 | Responsive | Laptop / tablet / mobile behaviour |
| 17 | UX recommendations | Page-specific guidance |
| 18 | Related flows | Flow IDs from §15 |


### 11.2 Page index


| ID | Page | Role | Priority | Spec level |
| --- | --- | --- | --- | --- |
| PUB-01 | Public landing | Public | P0 | Standard |
| PUB-02 | Sign in | All | P0 | Full |
| PUB-03 | Forgot password | All | P0 | Standard |
| PUB-04 | Reset password | All | P0 | Standard |
| PUB-05 | Invalid / expired link | All | P0 | Structural (state page) |
| STU-01 | Student Home | Student | P0 | Full |
| STU-02 | Skill Library | Student | P0 | Full |
| STU-03 | Skill preview (student) | Student | P1 | Structural (existence open) |
| STU-04 | Practice Session | Student | P0 | Full |
| STU-05 | Session summary | Student | P0 | Full |
| STU-06 | Recommendations | Student | P1 | Standard |
| STU-07 | Progress | Student | P1 | Standard |
| STU-08 | Honor Roll | Student | P2 | Structural |
| STU-09 | Achievement detail | Student | P2 | Structural |
| STU-10 | Rewards Store | Student | P2 | Standard |
| STU-11 | Item detail / purchase | Student | P2 | Structural |
| STU-12 | Join class | Student | P1 | Standard |
| STU-13 | Profile & settings | Both | P1 | Standard |
| SYS-01 | Notifications | Both | P1 | Standard |
| TCH-01 | Teacher Home | Teacher | P0 | Full |
| TCH-02 | Classes list | Teacher | P0 | Standard |
| TCH-03 | Class detail | Teacher | P0 | Standard |
| TCH-04 | Roster | Teacher | P0 | Full |
| TCH-05 | Create / edit class | Teacher | P0 | Standard |
| TCH-06 | Class code & co-teachers | Teacher | P1 | Standard |
| TCH-07 | Skill Library (teacher) | Teacher | P0 | Full |
| TCH-08 | Skill preview panel | Teacher | P0 | Full |
| TCH-09 | Assignments list | Teacher | P0 | Full |
| TCH-10 | Assignment builder | Teacher | P0 | Full |
| TCH-11 | Assignment review & publish | Teacher | P0 | Full |
| TCH-12 | Assignment tracking | Teacher | P0 | Full |
| TCH-13 | Quiz Generator | Teacher | P1 | Standard |
| TCH-14 | Quiz preview & regenerate | Teacher | P1 | Standard |
| TCH-15 | Quiz results | Teacher | P1 | Structural (rules open) |
| TCH-16 | Timetable | Teacher | P1 | Standard |
| TCH-17 | Lesson plan editor | Teacher | P1 | Standard |
| TCH-18 | Analytics — class | Teacher | P0 | Full |
| TCH-19 | Analytics — student | Teacher | P0 | Full |
| TCH-20 | Analytics — skill | Teacher | P1 | Standard |
| PAR-01…03 | Parent: child selector, home, progress | Parent | P2 | Structural skeleton |
| ADM-01…04 | Admin: school overview, accounts, classes, analytics/audit | School Admin | P2 | Structural skeleton |
| SADM-01…02 | System admin: content bank, users/roles | System Admin | — | Not designed (GAP-07) |
| SYS-02…06 | Session expired, permission denied, not found, offline, error | All | P0 | Structural (state pages, detailed in §22) |


### 11.3 Full specifications — Student P0 pages

11.3.1 PUB-02 · Sign in


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Sign in — PUB-02 |
| 2. Role | All |
| 3. Priority | P0 |
| 4. Primary user goal | Get into their own Naranj environment with school-issued credentials |
| 5. Information displayed | Product identity; username/identifier field; password field; sign-in action; "forgot password" link; error region. No role selector (S2 §1.3). No sign-up link (provisional, D-04). |
| 6. Primary action | Sign in |
| 7. Secondary actions | Forgot password; switch language (if language selector is global) |
| 8. Key interactions | Field validation on blur; submit disabled while empty or in flight; Enter submits; password visibility toggle; error shown inline above the form; role resolved silently after success |
| 9. Entry points | Public landing; deep link to a protected route; expired-session redirect; password reset completion |
| 10. Exit points | Student Home / Teacher Home (by role); Forgot password; root cause of a redirect preserved |
| 11. Dependencies | Authentication service; role resolution; error taxonomy (invalid credentials / disabled account / expired session); language setting |
| 12. Empty state | Not applicable (form). Initial state = empty fields, no error |
| 13. Loading state | Submit enters "signing in" state; form disabled; no layout shift |
| 14. Error state | Invalid credentials (no disclosure of which field); account disabled; service unavailable with retry; too many attempts (rule open — D-14) |
| 15. Permission state | n/a |
| 16. Responsive | Laptop: single centred column, max ~400 px content width; tablet: same; mobile: full-width fields, 44 px+ targets, keyboard-safe layout |
| 17. UX recommendations | Never reveal whether the username exists. Keep the destination route so the user lands where they intended. Do not add "remember me" unless the shared-device policy is decided (D-21). |
| 18. Related flows | F-STU-01, F-STU-02, F-TCH-01, F-AUTH-03 |

11.3.2 STU-01 · Student Home


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Student Home (صفحه آغازین دانش‌آموز) — STU-01 |
| 2. Role | Student |
| 3. Priority | P0 |
| 4. Primary user goal | Immediately know what to practise first and start or continue it in one action |
| 5. Information displayed | (Zone 1) Urgent/nearest-deadline assignment(s): skill name, teacher name, deadline, status (overdue / due today / upcoming / completed) with start-or-continue action. (Zone 2) Resume unfinished practice: skill name, last state, "continue". (Zone 3) 3–5 recommendations with a reason each and a start action (STU-012). (Support zone) Today's/weekly goal, coins, streak, last badge — informational only. Ordering of assignments is by nearest deadline (STU-002). |
| 6. Primary action | Start or continue the nearest-deadline assignment |
| 7. Secondary actions | Continue unfinished practice; start a recommendation; view all recommendations; open Skill Library; open Progress |
| 8. Key interactions | Card tap → Practice Session (direct entry, STU-005); recommendation dismissal (STU-014); pull-to-refresh / retry; scroll for support zone |
| 9. Entry points | Sign-in; session-expiry recovery; safe exit from practice; global nav |
| 10. Exit points | Practice Session; Recommendations; Skill Library; Progress; Achievements; Notifications; Profile |
| 11. Dependencies | Assignment service (per-student), recommendation service (with reason tier), progress snapshot, rewards state, current date/time in Iran time |
| 12. Empty states | (a) First sign-in, no assignment: welcome + one recommendation + library entry. (b) No assignment but has history: resume block becomes primary. (c) No assignments, no history, no recommendations (content unavailable): explain and offer browse. (d) Loading failure: error with retry, never an empty-looking page |
| 13. Loading state | Skeleton per zone (not a full-page spinner); zones resolve independently; the urgent block must resolve first |
| 14. Error state | Zone-level error with retry; partial rendering allowed; if the assignment zone fails, state clearly that assignments could not be loaded (students must not assume they have none) |
| 15. Permission state | Not applicable (own data only) |
| 16. Responsive | Laptop: two-column (main actions left/start, support column end) at ≥1280 px; tablet: single column, urgent block first; mobile: single column, urgent card compressed to 3 data points, support zone below the fold |
| 17. UX recommendations | (1) The urgent assignment must be the visually dominant element (P-04). (2) Never show a completed assignment in the urgent block — see open card-state question (D-06b). (3) Motivational widgets must not appear above the assignment block (S2 §5.1). (4) State the deadline in human terms ("due tomorrow") plus the absolute date. (5) If more than 3 assignments, show 3 + "view all" and sort by nearest deadline (STU-002). |
| 18. Related flows | F-STU-05, F-STU-06, F-STU-08, F-STU-09, F-STU-11, F-STU-12 |

11.3.3 STU-02 · Skill Library (student)


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Skill Library (کتابخانه مهارت) — STU-02 |
| 2. Role | Student |
| 3. Priority | P0 |
| 4. Primary user goal | Find a skill independently and start or continue it |
| 5. Information displayed | Subject/Grade context (changeable — STU-006); search box; topic accordion; subtopic grouping labels; skill rows with title, status, score if available, and badges for "assigned"/"recommended"; optional short description |
| 6. Primary action | Start / continue a skill (row action) |
| 7. Secondary actions | Change subject/grade; search; expand/collapse topics; filter by status; (optional) view skill description |
| 8. Key interactions | Accordion expand; search-as-you-type; filter chips; row → Practice Session; back preserves scroll, filter, and query |
| 9. Entry points | Global nav; Home "browse"; empty states on Home and Recommendations |
| 10. Exit points | Practice Session; Home; Progress |
| 11. Dependencies | Content taxonomy service; skill status per student; search index over titles; pagination at ~300 skills/grade |
| 12. Empty states | (a) No skills in this topic → state the topic and offer the next topic/grade. (b) No result for filter/search → show the query + "clear filters". (c) Content not published for this grade → explain and offer an available grade. (d) Access denied to some content → state it without exposing other content |
| 13. Loading state | Skeleton rows inside expanded topics; the accordion header is interactive immediately |
| 14. Error state | Topic-level error with retry; search failure must be visible and must not look like "no results" |
| 15. Permission state | If a grade/subject is not available to the account, show an explanatory state with the available context, no data leak |
| 16. Responsive | Laptop: filters as a left rail + list; tablet: filters in a collapsible bar above the list; mobile: full-width list, sticky search, context selector as a sheet |
| 17. UX recommendations | (1) The user must always see Subject + Grade + Topic position (S2 §5.2) — a breadcrumb or sticky context header. (2) Status must use text + icon, never colour alone. (3) Do not render the whole tree; collapse by default and keep search visible. (4) Because practice is a separate experience (S1 §6), the row action navigates away — no inline practice. (5) A "continue where you left off" row pinned above the tree reduces search cost. |
| 18. Related flows | F-STU-09, F-STU-10, F-STU-08 |

11.3.4 STU-04 · Practice Session

See §16 for the complete architecture. The page-level specification is:


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Practice Session (جلسه تمرین) — STU-04 |
| 2. Role | Student |
| 3. Priority | P0 |
| 4. Primary user goal | Answer the current question and understand the result |
| 5. Information displayed | Skill + topic name; question number/position; elapsed time; score slot; question prompt + media; answer input; hint (when available); submit; feedback region; save indicator; exit |
| 6. Primary action | Submit answer (then "continue") |
| 7. Secondary actions | Use hint; exit (confirmed); (no previous-question navigation — forward-only) |
| 8. Key interactions | Type/select/drag/dictate-as-defined per question type; local validation; submit → evaluate → feedback → continue; interrupt-safe |
| 9. Entry points | Assignment card; recommendation card; library row; resume block; return from a recovery state |
| 10. Exit points | Next question; session summary; safe exit to origin (Home / Library / assignment context) |
| 11. Dependencies | Question renderer registry; answer validator; evaluation service; hint content; session persistence; score service (formula pending); SmartScore availability |
| 12. Empty state | Skill has no questions available (content gap) → explain and offer another skill. Never a blank session |
| 13. Loading state | Question skeleton; never show a partially rendered answer control; next question preloaded where safe |
| 14. Error state | Question load failure (retry/next), submission failure (preserve input, mark unsaved, retry), evaluation timeout, offline (see §22) |
| 15. Permission state | Skill not accessible to this account → return to Library with explanation |
| 16. Responsive | Laptop: single centred column with a compact header row; tablet: same with larger controls; mobile: header compresses to two lines, sticky submit, keyboard-aware layout, math zoom |
| 17. UX recommendations | (1) Score and time must be visually secondary (S2 §5.5). (2) Never auto-advance after feedback — require an explicit continue (kids need time to read). (3) No countdown, no time pressure, no lives. (4) Exit must be reachable at all times and must state what is saved. |
| 18. Related flows | F-STU-12…F-STU-17 |

11.3.5 STU-05 · Session summary


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Session summary — STU-05 |
| 2. Role | Student |
| 3. Priority | P0 |
| 4. Primary user goal | Understand what happened and what to do next |
| 5. Information displayed | Skill name; session outcome (questions answered, correct/incorrect counts where permitted); score/level movement if approved; achievement or coin earned (secondary); next recommended step; return path |
| 6. Primary action | Continue to the next step (next skill / back to assignment / back to Home) |
| 7. Secondary actions | Review your progress (opens Progress); view achievements |
| 8. Key interactions | Single continue; optional expand "what did I learn" summary; never a dead end |
| 9. Entry points | Session completion (score 100 or student exit — PRA-007) |
| 10. Exit points | Home; Progress; next skill in the assignment; Achievements |
| 11. Dependencies | Session result; achievement engine; assignment context (was this assigned?); score availability |
| 12. Empty state | Zero answers submitted before exit → do not present a "result"; present a neutral "you left without answering" with resume |
| 13. Loading state | Result computation state; if the score is not yet confirmed, say so rather than showing a provisional number |
| 14. Error state | Result unavailable → show answers submitted and a note that the score is being calculated/unavailable; never invent a result |
| 15. Permission state | n/a |
| 16. Responsive | Single column at all widths; one primary button full-width on mobile |
| 17. UX recommendations | (1) Result and next step first, reward second (P-12). (2) Do not display accuracy percentages derived from fewer than a meaningful number of answers. (3) Where the session was launched from an assignment, offer "back to the assignment" explicitly. |
| 18. Related flows | F-STU-18, F-STU-17 |


### 11.4 Full specifications — Teacher P0 pages

11.4.1 TCH-01 · Teacher Home


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Teacher Home (صفحه آغازین معلم) — TCH-01 |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | See what needs attention today and act on it |
| 5. Information displayed | Active class (context bar); today's programme/sessions; assignments and quizzes active, near-deadline, overdue; recent completion results; alerts for skills/students needing attention (max 3 + view all); per-class progress summary; upcoming teaching plan; quick actions |
| 6. Primary action | Act on the most urgent item (e.g. "View assignment", "Create assignment") |
| 7. Secondary actions | Switch class; create assignment/quiz; open Analytics; open Timetable; open Assignments |
| 8. Key interactions | Class switch re-scopes the whole page; alert → relevant report/detail; quick actions launch flows with the active class pre-filled |
| 9. Entry points | Sign-in; nav; safe exit from flows |
| 10. Exit points | Assignments; Assignment tracking; Analytics; Skill Library; Classes; Timetable |
| 11. Dependencies | Class list + active class (TCH-001/TCH-002); assignment service; learning-alert content (TCH-003); analytics summary; timetable |
| 12. Empty states | (a) No classes yet → guided "create class" state (TCH-009 fields); (b) class with no assignments → "create your first assignment"; (c) no alerts → an explicit "nothing needs attention" rather than a blank card; (d) no data for analytics summary → explain and link to assigning practice |
| 13. Loading state | Zone skeletons; the "today" zone resolves first |
| 14. Error state | Zone-level retry; if analytics fail, the assignment zone must still render (teaching is not blocked by reporting) |
| 15. Permission state | If the active class is no longer accessible (removed/transferred), fall back to another class with an explicit notice |
| 16. Responsive | Laptop: 3-zone layout, quick actions in the title row; tablet: 2-column, alerts above the fold; mobile: single column, quick actions as a compact row, tables become list items |
| 17. UX recommendations | (1) Active class and time window must be visible in every card (S2 §6.1) — no card may be ambiguous about its scope. (2) Never bury an actionable alert under a decorative chart (S2 §6.1). (3) Alert count must be capped and explainable (TCH-003: content-curated). (4) Quick actions must be role-consistent and pre-fill the class context. |
| 18. Related flows | F-TCH-01, F-TCH-02, F-TCH-03, F-TCH-10, F-TCH-16, F-TCH-19, F-TCH-20 |

11.4.2 TCH-04 · Roster (Class management / student list)


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Roster — TCH-04 (part of Class detail TCH-03) |
| 2. Role | Teacher (primary), secondary teacher (access level open — D-10) |
| 3. Priority | P0 |
| 4. Primary user goal | See who is in the class and manage membership |
| 5. Information displayed | Students with name (and identifier if meaningful), membership status, joined date, per-student activity snapshot, last activity, quick links to student analytics; class code entry point; add-student action |
| 6. Primary action | Add or invite a student (or open a student's report — see note) |
| 7. Secondary actions | Search/filter roster; remove student; transfer; open class code; open co-teachers; export (unconfirmed) |
| 8. Key interactions | Search; sort; row action menu; confirmation with consequences on removal; multi-select for "assign to selected students" |
| 9. Entry points | Classes list; Class detail; Home class summary; assignment recipient step ("manage roster") |
| 10. Exit points | Student analytics; Assignment builder (with students pre-selected); Class detail; Skill Library |
| 11. Dependencies | Membership model with start/end dates (C-25); user directory; permission rules |
| 12. Empty states | Class with no students → show class code prominently + "add student" + explanation of both join methods |
| 13. Loading state | Skeleton rows; page-level header renders immediately |
| 14. Error state | Retry; distinguish "roster unavailable" from "roster empty" |
| 15. Permission state | Secondary teacher may have read-only roster (D-10) → actions hidden, explanation shown |
| 16. Responsive | Laptop: table with 5–6 columns; tablet: table with 4 columns + row expansion; mobile: list with stacked fields |
| 17. UX recommendations | (1) Removal must state the consequence confirmed in TCH-012: past records remain; from removal onward the student's data is excluded from class aggregates. (2) Never allow removal without confirmation. (3) Preserve the roster's search/filter when returning from a student report (P-06). (4) If manual add is used (TCH-011), the flow must be a lookup, never free-text creation of an account. |
| 18. Related flows | F-TCH-04, F-TCH-05, F-TCH-06 |

11.4.3 TCH-07 · Skill Library (teacher)


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Teacher Skill Library — TCH-07 |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | Evaluate existing skills and select one or more for an assignment, quiz or plan |
| 5. Information displayed | Subject/grade/topic/subtopic filters; skill rows with title, objective snippet, level (if defined), current class performance where valid data exists; selection checkboxes; preview action; selected count |
| 6. Primary action | Create an assignment (or quiz) from the selection |
| 7. Secondary actions | Preview a skill; change filters; select all in a topic; clear selection |
| 8. Key interactions | Multi-select with a persistent tray; preview opens a panel without losing selection or filters; selection survives filter changes (S2 §6.2); no create/edit question controls exist anywhere |
| 9. Entry points | Global nav; Home quick action; Analytics "assign this skill"; Assignment builder step 2 ("browse library") |
| 10. Exit points | Assignment builder; Quiz generator; Lesson plan; Skill preview panel; Analytics |
| 11. Dependencies | Taxonomy; skill metadata (objective, level); preview sample questions; class-performance data (TCH-007 definition open) |
| 12. Empty states | No skills for filters → explain and offer relaxation; no sample questions for a skill → say so in the preview, do not hide the skill |
| 13. Loading state | Skeleton rows; selection tray persists |
| 14. Error state | Retry; selection must not be lost on a failed load |
| 15. Permission state | Content outside the teacher's scope (unpublished/other grades) → not listed, or listed as unavailable with a reason (open: TCH-005 allows cross-grade selection) |
| 16. Responsive | Laptop: filter rail + list + sticky tray; tablet: collapsible filters + list + tray; mobile: list + bottom tray with count |
| 17. UX recommendations | (1) The selection tray is the load-bearing component: count, expandable list, remove, and the create action. (2) Cross-grade/multi-subject selection must be allowed but must show which grade each skill belongs to in the tray (TCH-005 "بله" + risk of mixing grades unknowingly). (3) Class performance shown per skill must state whether it is based on assigned practice, free practice, or both (BM-IXL-004 open). |
| 18. Related flows | F-TCH-07, F-TCH-08, F-TCH-09, F-TCH-10, F-TCH-13 |

11.4.4 TCH-08 · Skill preview panel


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Skill preview — TCH-08 (drawer/panel, not a route) |
| 2. Role | Teacher (student variant open — STU question unanswered) |
| 3. Priority | P0 |
| 4. Primary user goal | Judge whether a skill is appropriate before using it |
| 5. Information displayed | Skill title; learning objective; a few sample questions per skill (TCH-006); grade/topic context; prerequisites (IA-003); (if valid) class performance summary |
| 6. Primary action | Add to selection / create from this skill |
| 7. Secondary actions | Next/previous skill within the same list; close and return |
| 8. Key interactions | Opens over the list without navigation; keyboard dismissible; sample questions are read-only, never editable |
| 9. Entry points | Skill Library row; Analytics skill row; assignment tracking skill row |
| 10. Exit points | Back to the originating list with state intact; into builder |
| 11. Dependencies | Skill metadata; sample question rendering (reuses the question renderer in read-only mode — §17.3); performance data |
| 12. Empty state | Skill has no sample questions → state it plainly and still show the objective |
| 13. Loading state | Panel skeleton; the skill title renders immediately |
| 14. Error state | Retry inside the panel; never blank |
| 15. Permission state | n/a |
| 16. Responsive | Laptop: right-side panel ~40% width; tablet: overlay panel ~60%; mobile: full-screen sheet |
| 17. UX recommendations | (1) Preview is where teacher trust is built, because the teacher cannot author content (S2 §6.2). (2) Show at least one question with its answer and explanation so the teacher can judge quality — a preview without the answer is not a preview. (3) Read-only mode must reuse the same renderer as practice: a preview that looks different from the real experience misleads. |
| 18. Related flows | F-TCH-08 |

11.4.5 TCH-09 · Assignments list


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Assignments — TCH-09 |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | Find an assignment and see its state at a glance |
| 5. Information displayed | Assignment rows: title/identifier (auto-generated if user titles are not supported), skills (count + preview), recipients (class and/or count), deadline, status, per-student completion summary; filters by class, status, date; sort by deadline/created |
| 6. Primary action | Open assignment tracking |
| 7. Secondary actions | Create assignment; filter; sort; quick actions (permitted per state) |
| 8. Key interactions | Filter chips; row → tracking; inline status; no destructive action inline without confirmation |
| 9. Entry points | Nav; Home alerts; Class detail; Publish confirmation |
| 10. Exit points | Assignment tracking; Builder (new); Analytics; Home |
| 11. Dependencies | Assignment service; status vocabulary (C-05, D-05); deadline semantics (Iran time, TCH-020) |
| 12. Empty states | No assignments at all → "create your first assignment" with a one-line explanation of what an assignment is; no results for filters → show filters + clear |
| 13. Loading state | Skeleton rows + filter bar rendered |
| 14. Error state | Retry; never present a failed load as "no assignments" |
| 15. Permission state | Classes not accessible are not listed |
| 16. Responsive | Laptop: table; tablet: table with 4 columns; mobile: card list (title, class, deadline, status) |
| 17. UX recommendations | (1) The status vocabulary must match the tracking page and the student card (P-07, §18.4). (2) Overdue must be textually explicit, not only red. (3) Show the class on every row even when filtered — scope ambiguity is the most dangerous error in this page. |
| 18. Related flows | F-TCH-11, F-TCH-14, F-TCH-15 |

11.4.6 TCH-10 / TCH-11 · Assignment builder and review


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Assignment builder TCH-10 (steps 1–3) + Review & publish TCH-11 (step 4) |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | Send the right skills to the right students by the right deadline, with certainty about what will happen |
| 5. Information displayed | Persistent summary (class, recipients count, skills count, deadline); Step 1 recipients (whole class / selected students, cross-class allowed TCH-015); Step 2 skills (selection from library, ordering optional per TCH-014, remove, review each); Step 3 schedule + instructions (start/publish date, deadline, short instructions if supported); Step 4 full review |
| 6. Primary action | Next → Review → Publish |
| 7. Secondary actions | Back (state preserved); cancel with confirmation; save draft (only if drafts are confirmed — D-07) |
| 8. Key interactions | Multi-step with progress indicator; recipient validation (at least one); skill validation (at least one); deadline validation (must be future, Iran time); duplicate warning at publish (non-blocking, TCH-016); publish is idempotent (no double-send) |
| 9. Entry points | Skill Library selection; Assignments list; Home quick action; Analytics follow-up; Class detail; Roster multi-select |
| 10. Exit points | Publish → confirmation → tracking or list; Cancel → origin |
| 11. Dependencies | Roster/membership; taxonomy; deadline policy; notice/instructions support (C-10/D-09); idempotency key; status model |
| 12. Empty states | No recipients selected → blocked Next with an inline reason; no skills selected → blocked with a link to the library; no students in class → offer class code/manual add |
| 13. Loading state | Step transitions show a local saving state; publish shows a blocking publish state |
| 14. Error state | Publish failure → keep all data, explain what did not happen, offer retry; validation errors are inline and specific; conflict (assignment edited elsewhere) → explain and offer reload |
| 15. Permission state | Recipients limited to authorised classes/students (S1 §16.2); unauthorised students are not selectable and the reason is stated |
| 16. Responsive | Laptop: content column + summary rail; tablet: summary as a sticky bar; mobile: stepper with summary collapsed into a banner |
| 17. UX recommendations | (1) The review step is mandatory and must show skills, recipients, deadline and instructions in one view (S1 §16.2). (2) Ordering must be explicitly optional in the UI so teachers don't infer a required sequence (TCH-014). (3) The duplicate warning must describe what is duplicated (same skills + same class + overlapping window). (4) Never lose a builder in progress on session expiry — see §22.5. |
| 18. Related flows | F-TCH-10, F-TCH-11, F-TCH-12, F-TCH-13 |

11.4.7 TCH-12 · Assignment tracking


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Assignment tracking — TCH-12 |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | See who has done what and decide the next instructional action |
| 5. Information displayed | Assignment summary (skills, recipients, window, status); per-student rows with status and per-skill progress; aggregate (not-started / in-progress / completed counts); per-student action (open student analytics); edit/reschedule/cancel actions per rules (TCH-017) |
| 6. Primary action | Follow up: assign a corrective skill to selected students |
| 7. Secondary actions | Reschedule; cancel; open student report; filter/sort by status; back to list |
| 8. Key interactions | Multi-select students → "assign follow-up"; row → student report; destructive actions confirmed with consequences |
| 9. Entry points | Assignments list; Home alert; Analytics |
| 10. Exit points | Student analytics; Builder (follow-up, pre-filled); Assignments list |
| 11. Dependencies | Per-student assignment state; skills; membership period (removed students); edit rules (TCH-017/TCH-018) |
| 12. Empty states | No students started yet → state clearly that the assignment is scheduled/active and nothing has been recorded, with the deadline |
| 13. Loading state | Summary renders first, table skeleton below |
| 14. Error state | Retry; do not show zeros as if they were data |
| 15. Permission state | Secondary-teacher read-only mode if applicable (D-10) |
| 16. Responsive | Laptop: table + summary; tablet: table with expansion; mobile: student list with status chips |
| 17. UX recommendations | (1) Editing after students start must be presented with the confirmed rule that recorded answers are unaffected (TCH-018) — literally state it in the edit dialog. (2) Removed students must not silently vanish; show them as "no longer in class" with a note about aggregate exclusion (TCH-012). (3) The follow-up action must carry the analysis context (which skill failed) into the builder. |
| 18. Related flows | F-TCH-15, F-TCH-17, F-TCH-19, F-TCH-20 |

11.4.8 TCH-18 · Analytics — class


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Analytics — class level — TCH-18 |
| 2. Role | Teacher |
| 3. Priority | P0 |
| 4. Primary user goal | Identify the student or skill that needs support and convert it into action |
| 5. Information displayed | Window selector; class summary (completion of assignments/quizzes, activity); breakdown by subject/topic/skill with denominators and n; students needing support; skills needing support; every metric with a definition affordance |
| 6. Primary action | Create a follow-up assignment from the identified need |
| 7. Secondary actions | Change window; change class; open student report; open skill report; export (unconfirmed) |
| 8. Key interactions | Window/class change re-queries; drill-down to student/skill; "assign" pre-fills the builder; sort by need |
| 9. Entry points | Nav; Home class summary; Class detail; Assignment tracking |
| 10. Exit points | Student analytics; Skill analytics; Builder; Home |
| 11. Dependencies | Metric definitions (D-11), aggregation latency (ANL-006), data availability rules, gap-detection rule (ANL-002) |
| 12. Empty state | New class / no practice yet → explain what will appear once students practise, offer "assign practice"; do not render empty charts (ANL-005) |
| 13. Loading state | Skeletons per widget with the window label visible |
| 14. Error state | Widget-level retry; aggregate unavailable ≠ zero |
| 15. Permission state | Teacher sees only authorised classes; individual data per ANL-003 (open) |
| 16. Responsive | Laptop: summary row + two-column breakdown; tablet: stacked widgets; mobile: single column summary + list-based breakdown, no wide charts |
| 17. UX recommendations | (1) No "weak student" labels without an explicit basis (S2 §6.6). (2) Every number must carry a denominator and a window (P-14). (3) Keep the path from insight to action ≤ 2 interactions (S1 §8.3). (4) Distinguish assigned practice from free practice in every metric where both exist (BM-IXL-004). |
| 18. Related flows | F-TCH-19, F-TCH-20, F-TCH-21, F-TCH-22 |

11.4.9 TCH-19 · Analytics — student


| Attribute | Specification |
| --- | --- |
| 1. Page / ID | Analytics — student level — TCH-19 |
| 2. Role | Teacher (parent/admin variants later) |
| 3. Priority | P0 |
| 4. Primary user goal | Understand one student's position and decide support |
| 5. Information displayed | Student header (name, class, membership); activity window; skills practised with status/score; assignment completion history; time on practice; response-level detail (only if BM-IXL-003/ANL-003 confirm it) |
| 6. Primary action | Assign a follow-up skill to this student |
| 7. Secondary actions | Change window; open skill report; back to class analytics; view assignment history |
| 8. Key interactions | Window change; skill row → skill report or preview; assign → builder pre-filled with this student |
| 9. Entry points | Class analytics; roster; assignment tracking |
| 10. Exit points | Builder; Skill analytics; Class analytics |
| 11. Dependencies | Per-student evidence; privacy scope (ANL-003); data latency |
| 12. Empty state | Student with no activity → state it neutrally ("no practice recorded in this window"), offer assign; never imply failure |
| 13. Loading state | Header renders immediately; widgets skeleton |
| 14. Error state | Retry; distinguish "no data" from "load failed" |
| 15. Permission state | If the student has left the class, show historical scope + exclusion note (TCH-012) |
| 16. Responsive | Laptop: header + 2-column widgets; tablet/mobile: single column |
| 17. UX recommendations | (1) Non-judgmental language: describe evidence, not character. (2) If a per-question log is approved, it must be read-only and contextual (with the question shown), never a raw dump. (3) Always offer the action at the point of insight. |
| 18. Related flows | F-TCH-20, F-TCH-21, F-TCH-22 |


### 11.5 Standard specifications — P1 pages


| ID | Page | Goal | Information | Primary action | Key states / dependencies | UX recommendations | Related flows |
| --- | --- | --- | --- | --- | --- | --- | --- |
| PUB-01 | Public landing | Explain the product and provide one sign-in entry | Product summary, audience, one sign-in entry, language switch | Sign in | No data dependency; content owner open (AUTH-001 verbal) | One entry point only; no feature marketing that implies excluded features (no AI tutor, no ranking) | F-STU-01, F-TCH-01 |
| PUB-03 | Forgot password | Start recovery | Identifier field, channel choice (email/SMS — AUT-005), submit | Send recovery | Depends on identity-verification rule (D-15); rate limiting (D-14) | Never disclose whether the account exists; always show the same confirmation | F-AUTH-02 |
| PUB-04 | Reset password | Set a new password | New password + confirm, policy text, submit | Set password | Depends on password policy (technical) | Show the policy before submission; success leads to sign-in | F-AUTH-02 |
| STU-03 | Skill preview (student) | Judge a skill before practising | Objective, sample question(s), current status | Start skill | Existence unconfirmed for students (STU has no preview requirement) | Only build if confirmed; otherwise the library row carries a short description instead | F-STU-09 |
| STU-06 | Recommendations | Explore all suggestions with reasons | Grouped suggestions by topic/reason, each with reason + action, dismissal | Start a recommended skill | Depends on recommendation inputs (STU-011 verbal); count rule 3–5 per subject/indicator (STU-012) | Do not invent a "for you" algorithm narrative; each reason must state its tier | F-STU-11 |
| STU-07 | Progress | Convert results into a motivating, honest view of progress | Window selector; skills started/completed; progress by subject/topic; score trend where valid; questions answered, accuracy, time; recent activity; goal progress | Go to the next skill from an insight | Depends on indicator set (STU-015) — must ship with a defined minimum set; must exist with zeros (STU-018) | Non-judgmental; charts need windows and n; IXL is cited as a pattern reference only (STU-016) | F-STU-19 |
| STU-10 | Rewards Store | Spend coins with full clarity | Balance; item grid (image, name, price, ownership); equipped state; my items | Buy / equip | Depends on earning rules (STU-022), non-refundable (STU-023), release decision (D-13) | No real-money wording anywhere; confirm purchase with balance before/after; prevent duplicate purchase | F-STU-21 |
| STU-12 | Join class | Enter a class code at any time | Code field, submit, current classes list | Join | Depends on code rules (D-14); code can be entered any time (AUT-003); no effect on student experience (AUT-006) | Frame class membership as being connected to a teacher, not as unlocking content | F-STU-04 |
| STU-13 / TCH-21 | Profile & settings | Manage account and defaults | Name/display fields, language, teacher default class (TCH-001), notification prefs (SYS-003) | Save | Depends on field editability (SYS-005) and school-locked fields (SYS-006) | Clearly mark school-managed, read-only fields | — |
| SYS-01 | Notifications | See notices that matter | Unread/read, categories, archive (SYS-004), deep links | Open the linked item | Depends on channel/event rules (SYS-001/002) | Notifications must never be the only place a deadline appears | — |
| TCH-02 | Classes list | Choose or create a class | Classes with grade/subject/year, student count, my role (primary/secondary) | Open class / create class | Depends on TCH-009 required fields; TCH-013 co-teaching | Show role per class explicitly | F-TCH-02 |
| TCH-03 | Class detail | Understand one class and reach its tools | Metadata, roster summary, class code, co-teachers, quick links, timetable entry | Open roster or assign | Depends on permissions (D-10) | Tabs, not deep nesting | F-TCH-03 |
| TCH-05 | Create / edit class | Create a usable class | Title, school, subject, academic year (all required, TCH-009), save | Create | Validation; duplicate class warning | Only these four fields; do not add fields the sources don't confirm | F-TCH-03 |
| TCH-06 | Class code & co-teachers | Distribute access; share teaching | Code display/regenerate/void, join instructions, co-teacher list with levels | Generate / copy code | Depends on expiry rules (D-14), co-teacher access delta (D-10) | Show the code in a copyable, print-friendly block for classroom use | F-TCH-05 |
| TCH-13 | Quiz Generator | Configure and generate a quiz from the bank | Recipients; content scope (subject/grade/topic/skill); parameters (count, level, time, attempts, order, result visibility — all pending); generate | Generate | Depends on parameter registry (D-22); insufficient-bank handling (QUIZ-003) | Never offer a parameter that is not approved; explain insufficiency concretely ("only 6 questions exist for this scope; reduce to 6 or widen the scope") | F-TCH-16, F-TCH-17 |
| TCH-14 | Quiz preview & regenerate | Verify the output before publishing | Generated question list (read-only), question count, per-question type/level, regenerate, publish | Publish | Depends on whether individual questions may be removed (QUIZ-004) | Read-only reuses the question renderer; never allow editing question text | F-TCH-17, F-TCH-18 |
| TCH-16 | Timetable | See the schedule and plan | Day/week view; class sessions; planned topic/skill; lesson status; assignments/quizzes differentiated from sessions | Open a session → plan | Depends on school calendar (PLAN-001), who builds plans (PLAN-002), lesson granularity (PLAN-003) | Events of different types must be visually distinct yet linked (S2 §5.5) | F-TCH-22, F-TCH-23 |
| TCH-17 | Lesson plan editor | Plan a session's topics/skills | Session info; topic/skill selection; notes; status; link to create assignment/quiz | Save plan | Depends on PLAN-003/PLAN-004 | Keep it lightweight: a plan is a short list of skills, not a document editor | F-TCH-23 |
| TCH-20 | Analytics — skill | Understand a skill's class performance | Skill header + objective; window; students practised; distribution; actions | Assign follow-up | Depends on TCH-007 metric definition (open) | Show whether the evidence comes from assignment or free practice | F-TCH-19, F-TCH-22 |


### 11.6 Structural specifications — P2 and secondary roles


| ID | Page | Role | Priority | Purpose | Must not do |
| --- | --- | --- | --- | --- | --- |
| STU-08 | Honor Roll | Student | P2 | Show earned medals/badges/certificates, locked ones with unlock conditions, progress to the next award | No ranking, no peer comparison (STU-019) |
| STU-09 | Achievement detail | Student | P2 | Detail: condition, date earned, certificate download/print (STU-021) | No share-to-social feature |
| STU-11 | Item detail / purchase | Student | P2 | Preview, price, balance, confirm, owned/equipped state | No refund affordance (STU-023) |
| TCH-15 | Quiz results | Teacher | P1/P2 | Results per published quiz | Rules undefined (QUIZ-005/007) — must not display grades as authoritative |
| PAR-01 | Child selector | Parent | P2 | Choose which child's view to see | Not designed until PAR-002 confirms the relationship model |
| PAR-02 | Parent home | Parent | P2 | Child's assignments, deadlines, support needs | No action buttons if parent is read-only (PAR-004 open) |
| PAR-03 | Parent progress | Parent | P2 | Authorised indicators only | Must not expose data flagged confidential (PAR-003 open) |
| ADM-01 | School overview | School Admin | P2 | School-level summary | No individual data without audit (ADM-004) |
| ADM-02 | Accounts | School Admin | P2 | Create/manage teacher and student accounts | No self-service bulk import until confirmed |
| ADM-03 | Classes & teachers | School Admin | P2 | Create classes; assign teachers | Must respect primary/secondary semantics (TCH-013) |
| ADM-04 | School analytics & audit | School Admin | P2 | Aggregate indicators; audit access | No unlogged individual-data access (ADM-004) |
| SADM-01/02 | Content bank; users & roles | System Admin | — | Not designed. Requirement exists (SCP-005), specification does not | Must not be inferred from competitor tooling |


### 11.7 Inventory completeness check

- [DERIVED] 5 public/auth pages · 14 student pages · 22 teacher pages · 3 shared/utility · 5 edge-state pages · 3 parent · 4 school-admin · 2 system-admin placeholders.
- Every page in the inventory has a named entry point in §10 (no orphans) and at least one defined exit.
- Every P0 page in the inventory has a full 18-attribute specification.
- Pages deliberately absent: a page per skill, a page per topic, a page per question, a feedback page, an assignment detail page for students (C-09), a role-selection page, a leaderboard page, a diagnostic-assessment page.

## 12. STUDENT EXPERIENCE


### 12.1 Experience narrative

The student's experience is a guided practice lane with exactly three states of mind to serve:


| State of mind | The student is thinking… | The surface that answers it |
| --- | --- | --- |
| Arriving | "What do I have to do?" | Student Home (STU-01) |
| Searching | "Where is that thing I need?" | Skill Library (STU-02), Recommendations (STU-06) |
| Practising | "Is this right, and why?" | Practice Session (STU-04) + feedback state |
| Leaving | "Did it count? What now?" | Session summary (STU-05), Progress (STU-07) |

[CONFIRMED] The student may start a skill in three ways — assigned by a teacher, recommended by the system, or self-selected (S2 §1.3). All three routes converge on the same Practice Session, so the session must not vary by route except in the context it preserves (assignment context, recommendation reason).


### 12.2 The daily student journey


| Step | Surface | What must be true | Evidence |
| --- | --- | --- | --- |
| 1 | Sign-in | No role selection; lands directly on Student Home | [CONFIRMED] S2 §1.3 |
| 2 | Student Home | The nearest-deadline assignment is the dominant element; assignments ordered by nearest deadline | [CONFIRMED] STU-002 + S1 §5.1 ordering |
| 3 | Entry | One action moves the student into practice; no detail page | [CONFIRMED] STU-005 |
| 4 | Practice Session | One question at a time; skill identity visible; elapsed time; score slot | [CONFIRMED] S1 §6 |
| 5 | Answer | Type-appropriate input; local validation before submit | [CONFIRMED] S1 §6.2 |
| 6 | Feedback | Result + correct answer + explanation + solution method; no retry; forward only | [CONFIRMED] S1 §6, PRA-003, PRA-008 |
| 7 | Continue | Explicit continue; never auto-advance | [DESIGN RECOMMENDATION] |
| 8 | Session end | Completes at score 100 or on exit; summary shown | [CONFIRMED] PRA-007 |
| 9 | Return | Safe exit; confirmed answers preserved; resume available on Home | [CONFIRMED] S1 §6.3 |


### 12.3 First-run experience

[CONFIRMED constraints] There is no diagnostic assessment (S2 §1.3), no mandatory onboarding flow is described, and no tour is required by any source. Class membership does not gate content (AUT-006), and the class code may be entered at any time after first sign-in (AUT-003).

[DESIGN RECOMMENDATION] First-run design: three lightweight, dismissible moments, none of which blocks practice:

1.  First Home visit: a short welcome line explaining the two ways to start (assignment or library) — inline, not modal. Rationale: the student's first question is "what is this place?", and answering it inline preserves the one-action-to-practice rule (P-10).

2.  First empty assignment zone: if no assignment exists, the recommendation block becomes primary with a curriculum-default reason (C-18). Rationale: never show an empty state where a learning step could exist.

3.  First Practice Session: a single first-question hint ("choose an answer, then press Check"). Rationale: the answer contract differs per question type; one sentence reduces submission errors without a tutorial.

4.  Class code: surfaced as a quiet, dismissible prompt on Home after first sign-in, and permanently available in utilities. Rationale: confirmed as an anytime action, and it has no functional urgency for the student (AUT-006).

Explicitly rejected: a multi-step onboarding wizard, a level test, a forced profile completion, an avatar-selection gate. None are supported by the sources, and all delay the primary metric.


### 12.4 Composition rules specific to the student experience


| Rule | Rationale |
| --- | --- |
| The urgent assignment always occupies the first content zone on Home | Confirmed content order (S1 §5.1) |
| Motivational widgets never appear above the assignment or resume block | Confirmed: rewards must not hide the learning action (S2 §5.1) |
| Only one start target is visually primary at a time | P-05 |
| Skill names are shown in full wherever they are the object of an action; truncation is allowed only in dense lists, with the full name available | Skill names are long and similar; mis-selection is the most likely student error in the Library |
| Numbers are only shown when their meaning is defined; otherwise the slot states "not enough data" | P-14 + SmartScore formula undefined |
| No countdown, no lives, no time pressure anywhere in practice | No source supports them; practice timer is elapsed only (C-03) |
| Copy is ≤ 2 sentences per instruction, in the S2 tone ("your answer is correct; ready for the next question?") | [CONFIRMED] S2 §9.2 |


### 12.5 Student edge conditions


| Condition | Required behaviour | Status |
| --- | --- | --- |
| No class membership | No functional difference; Home works normally; class-code prompt is available | [CONFIRMED] AUT-006 |
| Multiple assignments with different deadlines | Ordered by nearest deadline; overdue explicitly distinguished | [CONFIRMED] STU-002, S1 §5.1 |
| Unfinished practice, saved | Resume block on Home; one action to resume | [CONFIRMED] S1 §5.1 |
| Unfinished practice, not saved (offline) | Must not appear as resumable; explain what was and was not saved | [CONFIRMED] S1 §6.3/§11 |
| Recommendations with no data | Curriculum-default recommendations with an honest reason, or no recommendation block | [CONFIRMED] STU-013, S2 §5.3 |
| Recommendation dismissed | Dismissal allowed; persistence of dismissal is open | [CONFIRMED] STU-014 (persistence = D-27) |
| Repeating a completed skill | Allowed; no coins added; time still counted | [CONFIRMED] STU-010 |
| Reaching 100 | Session completes; no further questions in that session | [CONFIRMED] PRA-007 |
| Grade/subject change | Allowed by the student | [CONFIRMED] STU-006 |
| Reviewing past answers/solutions | Not supported — system is forward-only | [CONFIRMED] STU-017 |


### 12.6 Student experience anti-patterns


| Anti-pattern | Why it is wrong here |
| --- | --- |
| A dashboard of widgets with no dominant action | Violates the confirmed content order and P-04 |
| A skill detail page between the card and practice | Contradicts the confirmed direct-entry decision (STU-005) |
| Score animation that must be dismissed before continuing | Delays learning and violates P-12 |
| Showing "accuracy %" after three answers | Violates P-14 and the metric-definition requirement |
| A recommendation tile without a reason, or with an AI-flavoured reason | Explicitly forbidden by S2 §5.3 |
| Gating content behind class membership | Contradicts AUT-006 |
| A back button inside the session | Contradicts forward-only (PRA-008, STU-017) |


## 13. TEACHER EXPERIENCE


### 13.1 Experience narrative

The teacher's experience is an operational console: structured, context-aware, data-informed, action-oriented. The design goal is time-to-decision, not engagement. Three recurring jobs, in the order the sources privilege them:


| Job | Question the teacher asks | Primary surfaces |
| --- | --- | --- |
| J-1 React | "What needs me right now?" | Teacher Home (TCH-01), Assignments (TCH-09), Tracking (TCH-12) |
| J-2 Set work | "I need to send these skills to these students by then." | Skill Library (TCH-07) → Builder (TCH-10/TCH-11) |
| J-3 Diagnose and follow up | "Who or what needs support, and what do I do?" | Analytics (TCH-18/TCH-19/TCH-20) → follow-up builder |

[CONFIRMED] The class context must be identifiable on every page and card (S1 §7.1, S2 §6.1); exactly one class is active at a time with an easy switcher at the top of the page (TCH-002); the default class is the last one visited, with a setting to override (TCH-001).


### 13.2 Class context model


| Rule | Detail | Status |
| --- | --- | --- |
| One active class at a time | All class-scoped pages read from the active class | [CONFIRMED] TCH-002 |
| Default class = last visited | Restored on the next sign-in | [CONFIRMED] TCH-001 |
| User can set a default class explicitly | In settings | [CONFIRMED] TCH-001 |
| Switching class re-scopes the page | Data, roster, assignments, analytics all refetch | [DESIGN RECOMMENDATION] |
| Switching never loses in-progress work | If a builder is in progress, the switcher is disabled or prompts | [DESIGN RECOMMENDATION] |
| Class is visible even when filtered | Every assignment/analytics row exposes its class scope | [DESIGN RECOMMENDATION] (P-02) |


### 13.3 The trust problem: preview as the quality gate

Because the teacher cannot author or edit questions (S2 §6.2), the preview is the only place where content quality is judged. The preview must therefore show, for each skill: the learning objective and a few sample questions (TCH-006) — and, by recommendation, at least one question with its answer and explanation, because a preview without answers cannot establish that the content is correct.

[OPEN DECISION] STU/TCH-006-extension: whether the student also gets a preview is not answered anywhere; the recommendation is to give the teacher full preview and the student only a one-line description in the library row.


### 13.4 Teacher daily journey


| Step | Surface | What must be true |
| --- | --- | --- |
| 1 | Sign-in → Home | Active class restored (TCH-001); today's requirements first; alerts capped at 3 |
| 2 | Choose a starting point | React (tracking) / Set work (library) / Diagnose (analytics) |
| 3 | From tracking | Per-student status; reschedule/cancel with stated consequences; follow-up action available |
| 4 | From library | Filters → preview → multi-select → create assignment or quiz |
| 5 | Builder | Recipients → skills → schedule/instructions → review → publish; summary always visible |
| 6 | Publish | Confirmation names class, recipients, skills, deadline; then "view tracking" |
| 7 | Diagnose | Analytics → identify → assign follow-up with context pre-filled |
| 8 | Plan | Timetable → session → lesson plan (topics/skills) → optionally create assignment/quiz |


### 13.5 Composition rules specific to the teacher experience


| Rule | Rationale |
| --- | --- |
| Every scoped surface names its class and time window | Confirmed (S2 §6.1) |
| Tables cap at 6 columns; detail moves to drawers | §8.6.3 |
| Selection is persistent and visible | Confirmed requirement for multi-select (S2 §6.2) |
| The builder is a guided flow with a mandatory review | Confirmed review-before-publish (S1 §16.2) |
| Every analytics surface terminates in an action | Confirmed (S1 §8.3; S2 §6.6) |
| No metric without definition, denominator, window | Confirmed interpretability requirement (S1 §14) |
| No student characterisations ("weak student") without an explicit, stated basis | Confirmed (S2 §6.6) |
| Quick actions pre-fill the active class | Prevents the most expensive teacher error (wrong scope) |
| Destructive actions state consequences in student terms | P-09, and confirmed edit-after-start rule (TCH-018) |


### 13.6 Teacher edge conditions


| Condition | Required behaviour | Status |
| --- | --- | --- |
| No classes | Guided creation state using the four confirmed required fields (title, school, subject, year) | [CONFIRMED] TCH-009 |
| Multiple classes | Switcher; list view; role per class | [CONFIRMED] TCH-002, TCH-013 |
| Recipients from multiple classes | Allowed, no restriction | [CONFIRMED] TCH-015 |
| Assignment duplicate (same skills/class/window) | Non-blocking warning at publish | [CONFIRMED] TCH-016 |
| Editing after students started | Allowed; recorded answers unaffected; must be stated | [CONFIRMED] TCH-017/018 |
| Cancelling / rescheduling | Allowed post-publish | [CONFIRMED] TCH-017 |
| Student removed from class | Records retained; excluded from class aggregates from the removal date | [CONFIRMED] TCH-012 |
| Deadline passing | Iran time is the MVP reference; system alarms rather than teacher reminders | [CONFIRMED] TCH-020/021 |
| Missing/insufficient data | Explicit insufficient-data state, never zeros-as-data | [CONFIRMED] ANL-005 + S1 §11 |
| Secondary teacher | Reduced access; the delta is undefined | [OPEN DECISION] D-10 |


### 13.7 Teacher experience anti-patterns


| Anti-pattern | Why it is wrong here |
| --- | --- |
| A KPI dashboard with no action links | Contradicts the confirmed data→action requirement |
| Class context only on the first screen of a flow | Causes wrong-scope publishing |
| Percentages without denominators | Violates P-14 and S1 §14 |
| A "weak students" board | Violates the non-judgmental requirement (S2 §6.6) |
| Quiz generator with unapproved parameters | Invents product rules |
| A per-question authoring or editing surface | Explicitly forbidden (S2 §6.2) |
| A giant single-step "create assignment" form | Loses the review gate and the summary |


## 14. SECONDARY ROLE SCOPE


### 14.1 Position

[CONFIRMED] Parent and School Admin are named roles; their pages and permissions are not specified (S1 §9). S2 adds that their pages resemble those of the two primary roles and differ mainly in the analytics indicators shown (S2 §6.6 note). System Admin must exist (SCP-005) and has no specification at all.

[OPEN DECISION] D-02 must be answered before any secondary-role design work begins: are Parent and School Admin in the first release? S3 contains two answers that point in different directions (PRD-003 vs SCP-003).


### 14.2 What can be built now, and what cannot


| Role | Can be specified now | Cannot be specified now |
| --- | --- | --- |
| Parent | Shell reuse; scope selector concept; read-only discipline; notification need | Data visibility level, relationship approval, whether they can act, indicator set |
| School Admin | Shell reuse; class/account creation intent; audit requirement | Operational scope, school indicators, individual-data rule, rollover mechanics |
| System Admin | Existence and responsibility (content bank, accounts/roles) | Everything else — no source material supports page-level design |


### 14.3 Design guidance for secondary roles (when released)

1.  Do not create a new shell. Reuse the authenticated shell, utilities, notification centre, and the analytics skeleton (T- C).

2.  One scope selector, one indicator set. The only true differentiation is whose data and which indicators — so build the analytics surface with an indicator registry keyed by role.

3.  Read-only default. Until PAR-004 and ADM-002 are answered, every secondary-role surface must be read-only; no action buttons that mutate learning data.

4.  Audit by default. Any individual-data access by a school admin must be logged (ADM-004) — design the "why am I seeing this" affordance now, not later.

5.  Privacy language. Parent surfaces must state the authorised scope in plain language (PAR-003 open).

6.  No new gamification. No coins, badges, or rankings for parents/admins; these are student mechanics only.


### 14.4 Explicit limitation statement

This document does not define the parent, school-admin, or system-admin experience. It defines their position in the architecture (shell, permissions, analytics variant) and lists the decisions required to proceed. Any deliverable that draws parent or admin screens before D-02, PAR-002/003/004, ADM-002/003/004 and SCP-005 are answered would be inventing requirements.


## 15. USER JOURNEYS AND FLOW DIAGRAMS


### 15.0 How flows are documented

Every flow carries: ID · role · goal · entry point · preconditions · main path · decision points · alternative paths · error paths · completion state · pages · system behaviour · open questions. Flows that carry the product's core value are also drawn as Mermaid flowcharts with decision diamonds and failure branches. Where a branch cannot be resolved from the evidence, it is drawn as an explicit "OPEN" node and mapped to a decision ID.

Conventions in the diagrams: rectangles = actions/states, diamonds = decisions, dashed edges = failure or recovery, double-bordered/annotated nodes = unresolved.

Legend for flows: S = student, T = teacher, A = authentication (cross-role).


### 15.1 Student flows

F-S-01 · Public landing → student sign-in


| Field | Detail |
| --- | --- |
| Role / goal | Visitor/student — reach their own environment from the public site |
| Entry point | Public landing page (PUB-01), or a direct link to a protected route |
| Preconditions | A school-issued account exists (provisional, D-04) |
| Main path | 1. Visitor lands on PUB-01. 2. Reads product summary. 3. Activates the single sign-in entry. 4. PUB-02 renders with credentials fields. 5. Enters username + password. 6. Submits. 7. Server authenticates and resolves the role. 8. User is routed to the role landing (Student Home for a student). |
| Decision points | (a) Already authenticated? → skip to role landing. (b) Deep link target differs from role landing? → honour the deep link if permitted, else role landing. (c) Multi-role account? → OPEN: which landing (D-03). |
| Alternative paths | Forgot password → F-S-03. Language switch before sign-in (if global selector exists). |
| Error paths | Invalid credentials → inline error, no field-level disclosure, form preserved. Account disabled → explicit but non-revealing message. Service unavailable → retry. Rate-limited → wait message (OPEN: policy, D-14). |
| Completion | Authenticated session with resolved role; Student Home rendered |
| Pages | PUB-01 → PUB-02 → STU-01 |
| System behaviour | Authentication, role resolution, session issuance, last-intended-route restoration |
| Open questions | Public landing content (AUTH-001 verbal); sign-up existence (D-04); multi-role routing (D-03); rate-limit policy (D-14) |

F-S-02 · First student sign-in


| Field | Detail |
| --- | --- |
| Role / goal | New student — understand what Naranj is and reach a first practice |
| Entry | PUB-02 with valid first-time credentials |
| Preconditions | Account exists; no practice history; class membership unknown/absent; no diagnostic assessment by design |
| Main path | 1. Sign-in succeeds. 2. Student Home renders in first-run state: welcome line, no assignments, recommendation block primary. 3. A quiet class-code prompt appears (dismissible). 4. Student starts a recommended skill (or opens the Library). 5. Practice Session opens; the first-question hint appears. 6. First answer is submitted. 7. Feedback is shown. 8. Session continues or exits. |
| Decision points | (a) Has an assignment already (assigned before first sign-in)? → urgent block replaces the first-run welcome. (b) Enters a class code now? → F-S-04, then returns to Home. (c) No recommendation available (content gap)? → Library invitation state. |
| Alternative paths | Join class first; browse the Library instead of a recommendation; change grade/subject before choosing (STU-006). |
| Error paths | Recommendation service failure → Home still renders the Library entry (never a blank page). Practice load failure → recovery state. |
| Completion | At least one question answered, or the student has a clear, explicit next step |
| Pages | STU-01 → (STU-12) → STU-06/STU-02 → STU-04 |
| System behaviour | Zero-state rendering (STU-018), curriculum-default recommendation tier (STU-013), first-question hint (once per device/account — OPEN: D-29) |
| Open questions | Whether the first-run welcome is required by the product team; hint frequency; class-code prompt persistence |

F-S-03 · Password recovery


| Field | Detail |
| --- | --- |
| Role / goal | Any user — regain access |
| Entry | PUB-02 → "forgot password" |
| Preconditions | Account exists with a recovery email and/or registered phone |
| Main path | 1. PUB-03. 2. User enters identifier. 3. Chooses channel: email or SMS (both confirmed, AUT-005). 4. System confirms the request generically (never discloses existence). 5. User receives link/code. 6. PUB-04 — sets a new password meeting the stated policy. 7. Success → sign-in. |
| Decision points | (a) Which channel? (b) Link/code valid? → PUB-05 expired state → request again. (c) New password meets policy? → inline guidance. |
| Alternative paths | Contact school/admin (not a product flow — no in-product escalation is specified) |
| Error paths | Unknown identifier → same generic confirmation (no disclosure). SMS not delivered → offer email. Expired/invalid token → PUB-05 with one recovery action. Repeated attempts → throttled (OPEN: D-14). |
| Completion | New password accepted; sign-in succeeds |
| Pages | PUB-03 → PUB-04 → (PUB-05) → PUB-02 |
| System behaviour | Token issuance/expiry, rate limiting, audit trail |
| Open questions | Identity-verification method for each channel (D-15); password policy (technical); whether the school admin is a recovery path (AUTH-005 "other method" — unanswered) |

F-S-04 · Joining a class with a class code


| Field | Detail |
| --- | --- |
| Role / goal | Student — be connected to a class so the teacher can see their work |
| Entry | Home class-code prompt; utilities; settings |
| Preconditions | Signed in; a valid code exists (issued by a teacher or admin, TCH-010) |
| Main path | 1. Student opens the join-class surface (STU-12). 2. Enters the code. 3. Submits. 4. Server validates the code. 5. Membership is created. 6. Confirmation names the class and the teacher. 7. Student returns to the previous context. |
| Decision points | (a) Code valid and not expired? (b) Already a member of this class? → idempotent confirmation, no duplicate. (c) Code valid but class inactive? → OPEN (AUTH-006). |
| Alternative paths | Teacher adds the student manually (TCH-011) — then the student sees the class without doing anything. |
| Error paths | Invalid code → specific but non-revealing error, code preserved for correction. Expired/used code → explain and instruct to ask the teacher for a new code. Network failure → retry, no partial membership. |
| Completion | Membership exists; the student's subsequent activity is attributed to the class |
| Pages | STU-12 → STU-01 |
| System behaviour | Code validation, single-use/reuse policy (OPEN: D-14), membership record with a start date, idempotency |
| Open questions | Code rules (length, expiry, attempts, reuse) — D-14; behaviour when the student is already in another class (multiple memberships?) — OPEN (AUTH-006 partially answered: class presence has no functional effect on the student) |

Diagram 9. Source file: diagrams/09_flow_join_class.mmd

F-S-05 · Entering the Student Home


| Field | Detail |
| --- | --- |
| Role / goal | Student — orient and choose the next action |
| Entry | Post-sign-in; global nav; safe exit from practice |
| Preconditions | Authenticated |
| Main path | 1. Home renders zone by zone. 2. Urgent assignment block resolves first. 3. Resume block, recommendations, support zone follow. 4. Student selects one primary action. |
| Decision points | (a) Assignment exists? → urgent block dominant. (b) Unfinished session exists? → resume promoted. (c) Neither? → recommendation dominant. (d) Multiple urgent assignments? → top 3 by nearest deadline + "view all". |
| Alternative paths | Enter via nav without an action; open notifications first; open Progress. |
| Error paths | Assignment zone failure → explicit failure state (never "no assignments"); other zones still render. Total failure → page-level retry. |
| Completion | The student has moved into a learning action, or has deliberately chosen a non-practice destination |
| Pages | STU-01 |
| System behaviour | Per-zone data fetching, deadline ordering (STU-002), zero-state rules (STU-018) |
| Open questions | Whether recommendations can be empty vs defaulted (STU-013 implies defaulted); completed-assignment presentation (D-06b) |

F-S-06 · Finding an assigned task


| Field | Detail |
| --- | --- |
| Role / goal | Student — locate the assignment they are expected to do and know its deadline |
| Entry | Student Home |
| Preconditions | At least one assignment addressed to the student or their class |
| Main path | 1. Home shows assignments ordered by nearest deadline (STU-002). 2. Each card states skill name, teacher, deadline, status. 3. The student identifies the task. 4. The card action starts the skill directly. |
| Decision points | (a) Overdue? → distinct text state + still actionable. (b) Completed? → OPEN card state (D-06b): hidden, shown as completed, or re-enterable (re-practice is allowed per STU-010). (c) Multiple skills in the assignment? → the card must state how many skills and which one starts first (OPEN: D-31). |
| Alternative paths | Open the Assignment list if the product provides one for students (OPEN — not confirmed; the sources imply cards on Home only). |
| Error paths | Assignment data fails → explicit state + retry; do not imply an empty list. |
| Completion | The student is inside the correct Practice Session |
| Pages | STU-01 → STU-04 |
| System behaviour | Deadline computation in Iran time; ordering; per-student status |
| Open questions | D-06b (completed state), D-31 (multi-skill assignment entry), D-09 (where instructions are read) |

F-S-07 · Starting an assigned skill


| Field | Detail |
| --- | --- |
| Role / goal | Student — begin the assigned skill and answer the first question |
| Entry | Assignment card on Home |
| Preconditions | Assignment active; skill accessible; questions available |
| Main path | 1. Card action is activated (direct entry — STU-005). 2. Session loads with skill identity, question 1, elapsed time 0, score slot. 3. Assignment instruction (if any) is shown as a one-line strip (OPEN: D-09). 4. Student answers. 5. Submit → feedback → continue. |
| Decision points | (a) Session already in progress for this skill? → resume instead of restart (OPEN: D-24 for fidelity). (b) No questions available for the skill? → content-gap state with a return path. (c) Assignment is overdue? → allowed to start (OPEN: is overdue still startable? Not stated — D-31). |
| Alternative paths | Enter the same skill from the Library while the assignment is active → the session must attribute the practice to the assignment context. |
| Error paths | Session load failure → recovery state with retry and explicit "nothing was lost". Question render failure → skip/next is not allowed by default; show retry (OPEN: D-24). |
| Completion | First answer confirmed and persisted |
| Pages | STU-01 → STU-04 |
| System behaviour | Session creation with context (assigned/free), question fetch, persistence, save indicator |
| Open questions | D-09, D-24, D-31 |

Diagram 10. Source file: diagrams/10_flow_assignment_to_practice.mmd

F-S-08 · Resuming unfinished practice


| Field | Detail |
| --- | --- |
| Role / goal | Student — continue exactly where they stopped |
| Entry | "Resume" block on Home (confirmed content order, S1 §5.1) |
| Preconditions | An unfinished session exists with confirmed answers |
| Main path | 1. Home shows the resume block with skill name and last recorded state. 2. Student activates resume. 3. System restores the last confirmed state. 4. The next question is presented. |
| Decision points | (a) Was the last answer confirmed? → restore it as answered, present the next question. (b) Was it unconfirmed (offline)? → must not be shown as saved (S1 §6.3); present the last confirmed point and state what was not saved. (c) Session expired server-side? → explicit "this practice is no longer resumable" state (OPEN: D-24 retention policy). |
| Alternative paths | Enter the same skill from the Library → same restoration behaviour. |
| Error paths | Restoration failure → explain and offer "start from the beginning" with an explicit loss statement. Network offline → banner + disabled resume. |
| Completion | Student is answering the next unconfirmed question |
| Pages | STU-01 → STU-04 |
| System behaviour | Server-authoritative session state; confirmed-vs-pending separation; retention window (OPEN: STATE-002) |
| Open questions | D-24 (fidelity/retention), STATE-002 (local retention limits), STATE-003 (local vs server conflict authority) |

F-S-09 · Browsing the Skill Library


| Field | Detail |
| --- | --- |
| Role / goal | Student — find a skill to practise independently |
| Entry | Global nav; Home "browse"; empty-state invitations |
| Preconditions | Published content exists for the selected grade |
| Main path | 1. STU-02 opens with the current subject/grade context. 2. Student adjusts subject/grade if desired (STU-006). 3. Expands a topic. 4. Subtopic groups appear as labels. 5. Skill rows show title + status. 6. Student starts or continues a skill. |
| Decision points | (a) Change subject/grade? → context updates, tree reloads. (b) Topic has no skills? → empty state with next-topic suggestion. (c) Skill already in progress? → row action reads "continue". (d) Skill completed? → row action per re-practice rule (STU-010). |
| Alternative paths | Use search (F-S-10); use a status filter; jump from a recommendation. |
| Error paths | Tree load failure → retry per topic; search failure must not look like "no results"; deep link to a non-existent skill → not-found state with library return. |
| Completion | Student enters the Practice Session for the chosen skill |
| Pages | STU-02 → STU-04 |
| System behaviour | Lazy loading of topic contents, status lookup per skill, state preservation on back |
| Open questions | Whether the tree is per-grade only or cross-grade (D-25); whether a student skill preview page exists (STU-03, unconfirmed) |

F-S-10 · Searching for a skill


| Field | Detail |
| --- | --- |
| Role / goal | Student — find a known skill by name quickly |
| Entry | Search field on STU-02 (and module-title search from the main page, IA-005) |
| Preconditions | Search index over skill/subtopic/topic titles |
| Main path | 1. Student types. 2. Results group by level (Topic / Subtopic / Skill). 3. Student selects a result. 4. The hierarchy opens at that skill, preserving context. 5. Student starts it. |
| Decision points | (a) Results in scope of the current grade only, or across grades? → OPEN (D-25). (b) No results? → show query + grade + clear action. (c) Many results? → rank exact/title-prefix matches first. |
| Alternative paths | Clear search → back to the browse state; use filters instead. |
| Error paths | Search service failure → explicit error, never an empty result list. Partial index → state that results are limited. |
| Completion | Target skill reached and started |
| Pages | STU-02 → STU-04 |
| System behaviour | Debounced query, grouped results, graceful degradation |
| Open questions | D-25 (scope), ranking rules, whether Persian/Arabic character normalisation and diacritic-insensitivity are required (TECHNICAL VALIDATION — critical for Persian search quality) |

F-S-11 · Starting a system recommendation


| Field | Detail |
| --- | --- |
| Role / goal | Student — act on a suggested next step because they understand why |
| Entry | Recommendation block on Home; Recommendations wall (STU-06) |
| Preconditions | Recommendation exists with a reason (adaptive, assignment-derived, or curriculum default) |
| Main path | 1. Student sees 3–5 suggestions, each with a one-line reason (STU-012). 2. Optionally opens the full wall. 3. Reads the reason. 4. Starts the skill. 5. Practice proceeds normally. |
| Decision points | (a) Reason type available? → must match the actual data tier (P-11). (b) Student dismisses? → allowed (STU-014); persistence OPEN (D-27). (c) Recommendation points at an already-completed skill? → do not show as if new; either hide or label as review (OPEN: D-27). (d) Not enough data? → fall back to curriculum defaults, or omit the block (S2 §5.3 allows omission). |
| Alternative paths | Open the wall and filter by topic; choose a different skill from the Library. |
| Error paths | Recommendation service failure → the block is omitted, Home remains functional; do not show a broken card. |
| Completion | Student enters the Practice Session through a recommendation |
| Pages | STU-01 / STU-06 → STU-04 |
| System behaviour | Reason generation per tier; dismissal persistence; count caps (3–5 per subject/indicator — STU-012) |
| Open questions | Recommendation inputs/algorithm ownership (STU-011 verbal); dismissal persistence (D-27); whether reasons may reference the teacher's assignment |

F-S-12 · Answering a question

This is the core interaction of the product and is specified twice: here as a user flow, and in §16 as an architecture.


| Field | Detail |
| --- | --- |
| Role / goal | Student — submit a valid answer with minimal friction |
| Entry | Practice Session (STU-04) |
| Preconditions | Question loaded; answer contract known |
| Main path | 1. Question prompt and media render. 2. The type-appropriate answer control renders. 3. Student produces an answer (select / type / pair / order / draw, per type). 4. Local validation confirms completeness/format. 5. Submit is activated. 6. Submission enters an in-flight state and is locked. 7. Evaluation returns. 8. Feedback is shown. 9. Student continues. |
| Decision points | (a) Answer empty or incomplete? → submit blocked with a specific inline reason. (b) Answer format is ambiguous (e.g. equivalent fractions) → accepted per PRA-002 unless the question explicitly restricts the form. (c) Hint used? → allowed; does not affect the score (PRA-004). (d) Submission in flight → no duplicate submit. |
| Alternative paths | Exit before submitting (nothing to save); use a hint first. |
| Error paths | Validation rejects input that is actually correct → must be recoverable with a clear explanation (TECHNICAL VALIDATION: parser tolerance). Network failure during submit → preserve input, mark "not saved", offer retry. Evaluation timeout → retry without re-entering the answer. Session expired → F-S-17 recovery. |
| Completion | Answer evaluated and confirmed; the student is in a feedback state |
| Pages | STU-04 |
| System behaviour | Client-side validation, server evaluation, idempotent submission, persistence, analytics event |
| Open questions | Per-type answer contracts (QTI-02); question ordering/randomisation (PRA-001 partially: content team owns the inventory; ordering OPEN — D-32); whether the answer can be edited after submit (no — PRA-008) |

Diagram 11. Source file: diagrams/11_flow_question_cycle.mmd

F-S-13 · Receiving correct-answer feedback


| Field | Detail |
| --- | --- |
| Role / goal | Student — confirm correctness and move on with understanding |
| Entry | Evaluation returns "correct" |
| Main path | 1. Feedback region renders a positive but brief acknowledgement (S2 §9.2 tone). 2. The correct answer is shown (reinforcement). 3. An explanation/solution method is shown when available. 4. Updated score is shown only if the score model is approved and available. 5. A single continue action is presented. |
| Decision points | (a) Explanation available? → show; otherwise do not fake one. (b) Score available? → show delta; else show the slot as unavailable without explanation clutter. |
| Error paths | Feedback renders but persistence failed → the save indicator must say "not saved" while feedback remains readable. |
| Completion | Continue → next question |
| Pages | STU-04 (feedback state) |
| System behaviour | Score computation (formula pending), reward triggers, persistence |
| Open questions | Whether a score delta is displayed per question (OPEN: PRA-010 content-team decision, D-11); whether correctness triggers any immediate reward animation (recommend: no, defer to session end) |

F-S-14 · Receiving incorrect-answer feedback


| Field | Detail |
| --- | --- |
| Role / goal | Student — understand the error and learn the correct method |
| Entry | Evaluation returns "incorrect" |
| Main path | 1. Neutral, non-judgmental acknowledgement (S2 §9.2 wording pattern). 2. The correct answer is displayed. 3. The explanation and the solution method are displayed (S1 §6 requirement, benchmark pattern from IXL). 4. No retry is offered (PRA-003). 5. A single continue action leads to the next question. |
| Decision points | (a) Explanation missing in content → show the correct answer only, and log the content gap (OPEN: content policy). (b) Student wants to argue the answer is equivalent → no appeal mechanism exists; equivalent forms must be handled by the answer contract instead (TECHNICAL VALIDATION, §25.5). |
| Error paths | Feedback content fails to load → show result + correct answer and state that the explanation is unavailable; allow continue. |
| Completion | Continue → next question |
| Pages | STU-04 (feedback state) |
| System behaviour | Correct answer + explanation retrieval; error event in analytics |
| Open questions | Whether the correct answer is always shown (S1 §6 states it as a requirement; PRA-010 defers details to content) — treat as confirmed with content-team variance |

F-S-15 · Using a hint


| Field | Detail |
| --- | --- |
| Role / goal | Student — get help without losing the chance to answer independently |
| Entry | Hint control inside the question area (placement open) |
| Preconditions | A hint exists for this question (PRA-004 confirms hints exist; per-type coverage unknown) |
| Main path | 1. Student activates hint. 2. The hint is revealed (inline or expandable). 3. The answer input remains available. 4. Student answers. 5. Submission proceeds normally; the score is not affected by hint use (PRA-004). |
| Decision points | (a) Multiple hint steps? → OPEN (D-29). (b) Hint exhausted? → state that no further help is available. (c) Hint availability affects analytics? → the sources say hints are recorded in analytics (S1 §6.2 "Analytics: Hint") but not whether they change scoring. |
| Error paths | Hint fails to load → tell the student, keep the question answerable. |
| Completion | Answer submitted |
| Pages | STU-04 |
| System behaviour | Hint event logging separate from the answer (see S1 SYN-002 "separate independent answer from helped answer" — OPEN whether this is implemented) |
| Open questions | D-29: multi-step hints, hint visibility rules, whether "answer independent of hint" is stored (SYN-002) |

F-S-16 · Exiting a practice session


| Field | Detail |
| --- | --- |
| Role / goal | Student — leave without losing confirmed work |
| Entry | Exit control, always visible in the session |
| Main path | 1. Student activates exit. 2. Confirmation states what is saved ("your answers so far are saved"). 3. Student confirms. 4. Session closes; confirmed state persists. 5. Student returns to the origin (Home, Library, or assignment context). |
| Decision points | (a) Submission in flight? → exit is blocked until the submission resolves, or warns explicitly. (b) Nothing answered yet? → confirmation simply closes. (c) Unconfirmed answer typed but not submitted? → must be explicitly declared as not saved. |
| Alternative paths | Browser back / tab close → must behave like exit (async persist attempt + warning), never silently discard (P-15). |
| Error paths | Persistence failure on exit → do not claim success; show "your last answer was not saved" on return. |
| Completion | Student outside the session with confirmed progress retained |
| Pages | STU-04 → origin |
| System behaviour | Persist-then-confirm, idempotency, unload handlers |
| Open questions | Behaviour when the student has an in-flight submission and closes the tab (D-24) |

F-S-17 · Recovering a practice session


| Field | Detail |
| --- | --- |
| Role / goal | Student — return after a network failure, session expiry, or app restart and keep their work |
| Entry | Re-entry into the same skill; session-expired state; resume block |
| Preconditions | A prior session exists (confirmed or unconfirmed state) |
| Main path | 1. Student returns (sign-in again if the session expired). 2. The system detects the prior session. 3. It restores the last confirmed state. 4. It states plainly what was and was not saved. 5. Practice continues from the next question. |
| Decision points | (a) Server session still valid? → seamless resume. (b) Server session expired but local data exists? → OPEN: local vs server authority (STATE-003). (c) Offline? → banner; resume disabled until connectivity returns. |
| Error paths | Conflict between local and server state → never silently overwrite; present the server state as authoritative with an explanation (S1 §11.1 "جایگزینی بی‌صدا رخ ندهد"). |
| Completion | Student is practising again with no perceived loss, or with an explicit, honest statement of loss |
| Pages | SYS-02 session expired → STU-04 |
| System behaviour | Session retention, conflict policy, local cache limits (TECHNICAL VALIDATION: STATE-002/003) |
| Open questions | D-24; retention duration; whether a partially answered question is restored |

Diagram 12. Source file: diagrams/12_flow_session_recovery.mmd

F-S-18 · Completing a skill (session completion)


| Field | Detail |
| --- | --- |
| Role / goal | Student — know they finished, see the result, and know what is next |
| Entry | Score reaches 100, or the student exits |
| Preconditions | At least one confirmed answer |
| Main path | 1. Completion is detected. 2. Session closes. 3. Summary shows outcome, questions answered, score/level where defined, achievements/coins if earned. 4. Next step is offered (next skill in assignment / recommended next / back to Home). 5. Progress and assignment state update. |
| Decision points | (a) Reached 100 → "completed" semantics (OPEN: D-06 relation between 100 and mastery). (b) Exited early → is the skill "completed", "in progress", or neither? (OPEN: D-05/D-06). (c) Assignment has more skills → next skill offered (order not mandatory, TCH-014). (d) Medal threshold crossed (80/90/100, STU-020) → medal shown. |
| Error paths | Result computation fails → show answers submitted and state that scoring is unavailable; do not fabricate. Achievement award fails → session result still shown; achievement retried server-side. |
| Completion | Student has a clear next action and a truthful record |
| Pages | STU-04 → STU-05 → STU-07/STU-01/STU-04 |
| System behaviour | Score finalisation, achievement evaluation (atomic, no duplicates — S1 §15 Coin/Achievement), assignment status update, analytics events |
| Open questions | D-05, D-06, D-06b; whether a "completed" assignment can be re-entered from the card |

F-S-19 · Reviewing learning progress


| Field | Detail |
| --- | --- |
| Role / goal | Student — see progress and decide the next skill |
| Entry | Global nav; Home progress snapshot; session summary |
| Preconditions | Progress page exists even with no data (STU-018) |
| Main path | 1. STU-07 opens with a default window. 2. Student sees skills started/completed, progress by subject/topic, score trend where valid, questions answered, accuracy, time. 3. Student changes window/subject (S2 §4.5). 4. Student selects a skill to act on. |
| Decision points | (a) No data → zeros state with an explanation and a start action (STU-018). (b) Very little data → do not render a misleading trend (P-14, D-19). (c) Some data unavailable → state it per indicator. |
| Alternative paths | Filter by subject; drill into a topic; enter a skill from a row. |
| Error paths | Indicator failure → per-widget error; the page must not blank out. |
| Completion | Student enters a skill from the analysis |
| Pages | STU-07 → STU-04 |
| System behaviour | Aggregation with windows; per-student scoping |
| Open questions | Indicator set (STU-015, D-19); default window; whether IXL-style filters are adopted (STU-016 cites IXL as a suitable model — [BENCHMARK EVIDENCE], adoption needs approval) |

F-S-20 · Reviewing achievements


| Field | Detail |
| --- | --- |
| Role / goal | Student — see what they earned and what unlocks next |
| Entry | Achievements (STU-08) from nav or Home support zone |
| Main path | 1. Earned medals/badges/certificates with dates. 2. Locked achievements with unlock conditions. 3. Progress toward the next award. 4. Optional: open a detail, download/print a certificate (STU-021). |
| Decision points | (a) No achievements yet → encouraging empty state with the nearest achievable condition. (b) Certificate eligibility → per approval (OPEN: rule). |
| Error paths | Achievement service failure → retry; never show "no achievements" when the load failed. |
| Completion | Student views or downloads an achievement |
| Pages | STU-08 → STU-09 |
| System behaviour | Award ledger; certificate generation |
| Open questions | Full achievement catalogue and award conditions (STU-020 partially answers: medals at 80/90/100, streak medals); certificate format |

F-S-21 · Using coins and rewards


| Field | Detail |
| --- | --- |
| Role / goal | Student — spend earned coins on customisation with full clarity |
| Entry | Coin balance indicator (Home support zone) → Rewards Store (STU-10) |
| Preconditions | Balance ≥ item price |
| Main path | 1. Store lists items with price and ownership state. 2. Student opens item detail (STU-11). 3. Preview + price + balance shown. 4. Confirm purchase (explicit confirmation). 5. Server validates balance and creates the transaction atomically. 6. Item becomes owned; equipping is a separate action. |
| Decision points | (a) Insufficient coins → explain the shortfall and how coins are earned (STU-022: streaks and completed skills), offer return to practice. (b) Already owned → show owned/equipped, block re-purchase. (c) Network failure during purchase → must resolve server-side before retrying (idempotency). |
| Alternative paths | Equip/unequip an owned item; return to practice. |
| Error paths | Transaction conflict (balance changed) → re-read balance and ask again. Duplicate submission → blocked by idempotency. Failure → state that no coins were deducted. |
| Completion | Item owned (and optionally equipped) with a truthful balance |
| Pages | STU-10 → STU-11 |
| System behaviour | Atomic balance mutation, idempotency key, transaction log |
| Open questions | Coin earning rates and events (STU-022 partial); refunds are not allowed (STU-023); avatar display locations (STU-024 verbal); first-release inclusion (D-13) |


### 15.2 Teacher flows

F-T-01 · Teacher sign-in


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — reach the teacher environment |
| Entry | PUB-01 → PUB-02 |
| Preconditions | Teacher account provisioned by an admin (OPEN: provisioning method, D-04) |
| Main path | 1. Sign-in. 2. Role resolved as teacher. 3. Routed to Teacher Home. 4. Active class restored (last visited, TCH-001). |
| Decision points | (a) Multi-role account → OPEN (D-03). (b) No classes yet → guided creation state. |
| Error paths | Invalid credentials; disabled account; service unavailable — same rules as F-S-01. |
| Completion | Teacher Home rendered with a resolved class context |
| Pages | PUB-01 → PUB-02 → TCH-01 |
| System behaviour | Role resolution, default-class restoration |
| Open questions | D-03, D-04 |

F-T-02 · Entering the Teacher Home


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — see what needs attention today |
| Entry | Post-sign-in; nav |
| Main path | 1. Home renders with the active class context. 2. "Today" zone shows sessions and deadlines. 3. Alerts (max 3, content-curated — TCH-003) follow. 4. Class summary + upcoming plan. 5. Quick actions are available. |
| Decision points | (a) No classes → creation state. (b) Many alerts → capped with "view all". (c) No alerts → explicit "nothing needs attention". (d) Priority between reactive alerts and planning → OPEN (D-08). |
| Error paths | Analytics zone failure must not block the assignment zone (teaching continuity). |
| Completion | Teacher opens a destination or a quick action |
| Pages | TCH-01 |
| System behaviour | Class-scoped aggregation; alert delivery; deadline computation |
| Open questions | D-08 (ordering), alert catalogue (TCH-003 content team), quick-action order (TCH-004 verbal) |

F-T-03 · Switching between classes


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — change the active class context without losing work |
| Entry | Global class switcher in the context bar (TCH-002) |
| Main path | 1. Teacher opens the switcher. 2. Sees all classes with role (primary/secondary) and student counts. 3. Selects a class. 4. All class-scoped data re-renders for the new class. 5. The choice becomes the new last-visited default (TCH-001). |
| Decision points | (a) A builder is in progress? → switcher disabled or prompts to discard/finish (DESIGN RECOMMENDATION). (b) Only one class? → switcher may be hidden or disabled with a tooltip. (c) Class unavailable/removed? → fall back to another class with an explicit notice. |
| Error paths | Data load failure after switch → keep the new class context but show retry states per zone; do not silently revert to the old class. |
| Completion | Teacher is operating in the intended class |
| Pages | Any shell page |
| System behaviour | Context persistence (session + last-visited), authorisation re-check per request |
| Open questions | Whether class context is URL-bound or session-bound (D-26); whether "all classes" aggregate views exist (OPEN: TCH-002 implies one active class, so aggregate is not assumed) |

F-T-04 · Viewing class information


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — understand a class and reach its tools |
| Entry | Classes list → class detail (TCH-03) |
| Main path | 1. Class metadata (title, school, subject, year). 2. Roster summary. 3. Quick links: roster, class code, assignments, analytics, timetable. 4. Role indicator (primary/secondary). |
| Decision points | (a) Secondary teacher → reduced actions (D-10). (b) Empty class → class-code call to action. |
| Error paths | Load failure → retry; never show "0 students" as if it were data. |
| Completion | Teacher enters the intended tool |
| Pages | TCH-02 → TCH-03 |
| System behaviour | Class metadata, membership counts, role |
| Open questions | D-10 |

F-T-05 · Viewing the student roster


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — see who is in the class |
| Entry | Class detail; Home class summary |
| Main path | 1. Roster table renders (name, membership, activity snapshot). 2. Search/sort. 3. Row → student analytics. 4. Multi-select → assign to selected. |
| Decision points | (a) Many students → pagination and column choice. (b) Removed students → shown or filtered (DESIGN RECOMMENDATION: filter "former members" available). |
| Error paths | Load failure → retry; distinguish from empty roster. |
| Completion | Teacher has selected a student or an action |
| Pages | TCH-04 |
| System behaviour | Membership periods (C-25) |
| Open questions | Whether former members remain visible (D-31 extension) |

F-T-06 · Adding or removing students


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — manage class membership |
| Entry | Roster (TCH-04); class code (TCH-06) |
| Preconditions | Manual addition is allowed (TCH-011); the teacher is authorised |
| Main path (add) | 1. Teacher chooses "add student". 2. Looks up an existing account. 3. Confirms. 4. Student is added; activity is attributed to the class from that point. |
| Main path (remove/transfer) | 1. Row action → remove (or transfer). 2. Confirmation states the confirmed consequence (records retained; data excluded from class aggregates from removal onward — TCH-012). 3. Membership closes. |
| Decision points | (a) Student already in the class → idempotent notice. (b) Student in another class → allowed (no restriction stated). (c) Removal while an assignment is active → allowed; the assignment remains in the student's history. |
| Error paths | Lookup finds no account → explain (no free-text account creation). Removal fails → state that nothing changed. |
| Completion | Membership state updated with a truthful consequence statement |
| Pages | TCH-04 → TCH-06 |
| System behaviour | Membership start/end dates; aggregate exclusion rule |
| Open questions | Whether "transfer" is a distinct operation or remove+add (OPEN: TCH-012 mentions both); whether the admin must approve manual adds (OPEN: ADM-002) |

F-T-07 · Browsing the Skill Library (teacher)


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — find candidate skills |
| Entry | Nav; Home quick action; Analytics "assign this skill" |
| Main path | 1. Filters (subject/grade/topic/subtopic). 2. Skill rows render with titles and (where valid) class performance. 3. Teacher previews (F-T-08). 4. Selects (F-T-09). |
| Decision points | (a) Cross-grade/multi-subject selection allowed → the tray must show each skill's grade (TCH-005). (b) Performance data unavailable → row shows "no data" rather than 0% (BM-IXL-004, D-11). |
| Error paths | Load failure → retry with selection preserved. |
| Completion | Teacher has a selection or a decision |
| Pages | TCH-07 |
| System behaviour | Taxonomy query, skill metadata, performance lookup |
| Open questions | TCH-005 (confirmed yes), TCH-007 (metric definition open) |

F-T-08 · Previewing a skill


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — judge content fitness before use |
| Entry | Skill row → preview panel (TCH-08) |
| Main path | 1. Panel opens over the list. 2. Objective shown (TCH-006). 3. A few sample questions shown, read-only, with answers/explanations (recommended). 4. Teacher closes or adds to selection. |
| Decision points | (a) No sample questions → state it and show the objective. (b) Multiple skills → move between them in the panel without closing. |
| Error paths | Sample questions fail → the panel remains usable with the objective and a retry. |
| Completion | Teacher decides: select, skip, or continue previewing |
| Pages | TCH-08 (over TCH-07) |
| System behaviour | Read-only question renderer; no authoring controls |
| Open questions | Whether answers/explanations are included in the preview (recommended yes; source says only "a few sample questions") — OPEN (D-33) |

F-T-09 · Selecting multiple skills


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — assemble a set of skills for one activity |
| Entry | Skill Library; Analytics; lesson plan |
| Main path | 1. Teacher checks skills. 2. A persistent tray shows the count and list. 3. Selection survives filter changes and preview. 4. Teacher chooses the destination action (assignment / quiz / plan). |
| Decision points | (a) Selected skills span grades/subjects → allowed; tray must display grade per skill (TCH-005). (b) Teacher deselects → tray updates immediately. (c) Very large selection → cap is OPEN (no source limit). |
| Error paths | Selection must never be lost on a failed load or a filter change (P-06). |
| Completion | Selection handed to a creation flow |
| Pages | TCH-07 → TCH-10 / TCH-13 / TCH-17 |
| System behaviour | Client-side selection with URL/session persistence |
| Open questions | Selection cap; whether selections can be saved for later (not supported by any source) |

F-T-10 · Creating an assignment


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — send skills to recipients with a deadline |
| Entry | Skill Library selection; Assignments; Home quick action; Analytics follow-up; Class detail; Roster multi-select |
| Preconditions | At least one class with at least one student |
| Main path | 1. Builder opens pre-filled (skills and/or class, depending on entry). 2. Step 1 Recipients — whole class or selected students (cross-class allowed, TCH-015). 3. Step 2 Skills — add/remove from the library; ordering optional (TCH-014). 4. Step 3 Schedule & instructions — start/publish date, deadline (Iran time, TCH-020), short instructions (support level OPEN: D-09). 5. Step 4 Review (F-T-12). 6. Publish (F-T-13). |
| Decision points | (a) No recipients → Next blocked with a reason. (b) No skills → Next blocked with a link to the library. (c) Deadline in the past → blocked with an inline reason. (d) Duplicate assignment suspected → non-blocking warning (TCH-016). (e) Draft saving → OPEN (D-07). |
| Alternative paths | Cancel with confirmation; go back a step with state preserved; publish later (not supported without drafts). |
| Error paths | Publish failure → retain everything, state clearly that nothing was sent, retry. Validation errors inline. Conflict (class changed by another user) → explain and re-resolve. |
| Completion | Assignment published, or abandoned without side effects |
| Pages | TCH-10 → TCH-11 → TCH-12 |
| System behaviour | Draft state, validation, idempotent publish, notification events (D-23) |
| Open questions | D-07 (drafts), D-09 (instructions), D-23 (notifications), D-31 (student-side states) |

Diagram 13. Source file: diagrams/13_flow_assignment_builder.mmd

F-T-11 · Selecting a class or individual students


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — define the audience precisely |
| Entry | Builder step 1; roster multi-select; analytics student rows |
| Main path | 1. Teacher chooses mode (whole class / individuals). 2. In individual mode, a searchable picker lists authorised students with class labels. 3. Selections accumulate across classes (TCH-015). 4. Count and names are shown in the summary. |
| Decision points | (a) Students from multiple classes → allowed, labelled by class. (b) Unauthorised students → not selectable, reason stated (S1 §16.2). (c) Students removed from class → not selectable. |
| Error paths | Roster load failure → retry; do not fall back silently to whole class. |
| Completion | Audience confirmed and visible in every subsequent step |
| Pages | TCH-10 step 1 |
| System behaviour | Authorisation filter server-side; selection persistence |
| Open questions | Whether "all students across all my classes" is permitted (implied by TCH-015 but not stated as a bulk mode) |

F-T-12 · Reviewing an assignment before publishing


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — verify what will happen before it happens |
| Entry | Builder step 4 |
| Main path | 1. Review shows skills (with grade/topic), recipients (class + count + names), start and deadline, instructions. 2. Teacher can go back to any step with state preserved. 3. Teacher publishes or cancels. |
| Decision points | (a) Something is wrong → back to that step; nothing is lost. (b) Duplicate detected → warning with an explanation of what overlaps. |
| Error paths | Review data stale (roster changed) → re-resolve and show a notice. |
| Completion | Teacher is certain; publish is enabled |
| Pages | TCH-11 |
| System behaviour | Server re-validation at publish |
| Open questions | Whether the reviewer must see the number of questions per skill (not confirmed; the teacher selects skills, not questions) |

F-T-13 · Publishing an assignment


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — make the assignment live without duplicates |
| Main path | 1. Publish activated. 2. In-flight state; control locked. 3. Server validates and creates the assignment. 4. Status is confirmed by the server, not guessed (S1 §16.2: "پس از انتشار، وضعیت از سرور تأیید می‌شود"). 5. Confirmation shows effects and next steps. 6. Notification events fire (D-23). |
| Decision points | (a) Publish button double-tapped → idempotency prevents duplication. (b) Scheduling in the future → assignment is "Scheduled" until the start date. |
| Error paths | Timeout → the client must query the assignment state before offering retry (never blind retry). Failure → nothing published, data preserved. |
| Completion | Assignment exists with a server-confirmed status; the teacher is shown tracking |
| Pages | TCH-11 → TCH-12 / TCH-09 |
| System behaviour | Idempotency key, server-side status, notification fan-out |
| Open questions | Notification channel and event rules (D-23) |

F-T-14 · Editing, rescheduling or cancelling an assignment


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — correct or stop an assignment without harming recorded work |
| Entry | Assignment tracking (TCH-12); Assignments list row actions |
| Preconditions | Post-publish editing is permitted (TCH-017) |
| Main path | 1. Teacher opens the assignment. 2. Chooses edit / reschedule / cancel. 3. Dialog states the confirmed consequence: recorded answers are unaffected (TCH-018); cancelling removes it from students' lists. 4. Change is applied and confirmed by the server. 5. Tracking reflects the new state. |
| Decision points | (a) Students have started → editing allowed, no effect on their recorded answers (TCH-018). (b) Cancel after start → allowed; must state what students see. (c) "Duplicate" → not offered; the concept has no meaning here (TCH-017). |
| Error paths | Conflict (edited elsewhere) → explain and reload. Failure → state that nothing changed. |
| Completion | Assignment state updated with truthful consequences |
| Pages | TCH-12 |
| System behaviour | Versioned mutation, audit, notification of change (OPEN: D-23) |
| Open questions | Whether students are notified of a deadline change (OPEN); whether a reschedule can precede the original start date |

F-T-15 · Tracking assignment progress


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — know who has done what and act |
| Entry | Assignments list; Home alert; tracking page |
| Main path | 1. Summary shows aggregate completion. 2. Per-student rows show status and per-skill progress. 3. Teacher filters by status. 4. Teacher selects students → follow-up action or opens a student report. |
| Decision points | (a) Nobody started → an explicit "scheduled/active, nothing recorded yet" state. (b) Overdue → distinct text state. (c) Removed student → shown as former member with aggregate-exclusion note (TCH-012). |
| Error paths | Partial data → per-section retry; never zeros-as-data. |
| Completion | Teacher takes a follow-up action or opens a report |
| Pages | TCH-12 → TCH-19 / TCH-10 |
| System behaviour | Per-student assignment state (D-05), aggregation |
| Open questions | Status vocabulary (D-05), whether per-student detail includes per-question results (D-20) |

F-T-16 · Generating a quiz


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — produce a quiz from the existing question bank |
| Entry | Quiz Generator (TCH-13) from Home quick action, library selection, or nav (D-07) |
| Preconditions | Question bank has sufficient items for the requested scope |
| Main path | 1. Recipients. 2. Content scope (subject/grade/topic/skill) — may be pre-filled from a skill selection. 3. Parameters (count, level, time, attempts, order, result visibility — all pending approval, QUIZ-001). 4. Generate. 5. Preview (F-T-17). |
| Decision points | (a) Insufficient questions → concrete guidance (reduce count or widen scope), never a dead end (QUIZ-003). (b) Impossible parameter combination → explained inline. (c) Generation in progress → blocking state with progress. |
| Error paths | Generation failure → retry with parameters preserved. Bank timeout → retry; no partial quiz. |
| Completion | A generated candidate quiz in preview |
| Pages | TCH-13 → TCH-14 |
| System behaviour | Randomised/parameterised selection (OPEN: QUIZ-002 — random vs difficulty-based) |
| Open questions | Parameter set and limits (D-22); generation strategy (D-22); whether a quiz is separately published or attached to an assignment (D-22) |

F-T-17 · Previewing and regenerating a quiz


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — verify quiz quality before publishing |
| Entry | Quiz preview (TCH-14) |
| Main path | 1. Teacher reviews the generated questions (read-only; cannot edit — S1 §8.1, S2 §4.6). 2. Optionally regenerates (all or per parameters). 3. Optionally removes a question (OPEN: QUIZ-004). 4. Publishes or abandons. |
| Decision points | (a) Regenerate all vs change a parameter → both permitted via preview exit (S1 §8.1 states the teacher can exit preview, change parameters and regenerate). (b) Remove a single question → permitted only if QUIZ-004 approves. |
| Error paths | Regeneration failure → previous preview preserved. |
| Completion | Teacher is satisfied or abandons |
| Pages | TCH-14 |
| System behaviour | Read-only renderer; regeneration with the same parameters |
| Open questions | QUIZ-004, D-22 |

F-T-18 · Publishing a quiz


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — make the quiz available |
| Main path | 1. Publish. 2. In-flight, locked. 3. Server confirms. 4. Confirmation with result-tracking entry point. |
| Decision points | (a) Result visibility rules undefined → must not promise any visibility (OPEN: QUIZ-005/007). (b) Editable/cancellable after publishing → OPEN (QUIZ-007). |
| Error paths | Failure → nothing published; retry safe. |
| Completion | Quiz published with a server-confirmed state |
| Pages | TCH-14 → TCH-15 |
| System behaviour | Idempotency; notification events |
| Open questions | D-22 (all quiz rules), and the quiz-taking experience for students is entirely undefined (QUIZ-006) — a first-release scope risk if quizzes are in scope |

F-T-19 · Reviewing class analytics


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — find what needs attention |
| Entry | Nav; Home class summary; tracking |
| Main path | 1. Window selector (default window OPEN: ANL-001). 2. Headline indicators with definitions. 3. Breakdown by subject/topic/skill. 4. Students/skills needing support. 5. Drill-down or act. |
| Decision points | (a) Insufficient data → explanatory state, no charts (ANL-005). (b) Which indicators are visible → OPEN (ANL-001, D-11). (c) Learning-gap detection rule → OPEN (ANL-002). |
| Error paths | Widget-level retry; distinguish unavailable from zero. |
| Completion | Teacher acts (assign follow-up) or drills down |
| Pages | TCH-18 → TCH-19 / TCH-20 / TCH-10 |
| System behaviour | Aggregation; latency disclosure (ANL-006 — OPEN) |
| Open questions | D-11 (metric definitions), ANL-001/002/006 |

F-T-20 · Reviewing individual student analytics


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — understand one student and support them |
| Entry | Class analytics; roster; assignment tracking |
| Main path | 1. Student header with class and membership. 2. Window selector. 3. Skills and statuses. 4. Assignment completion history. 5. Time and accuracy where defined. 6. Follow-up action pre-filled with the student. |
| Decision points | (a) No activity → neutral statement + assign action. (b) Former member → historical scope + exclusion note. (c) Access to answer-level detail → OPEN (ANL-003, D-20). |
| Error paths | Retry; do not conflate failure with no data. |
| Completion | Teacher creates a follow-up or returns with a decision |
| Pages | TCH-19 → TCH-10 |
| System behaviour | Per-student evidence retrieval; privacy scoping |
| Open questions | D-20, ANL-003 |

F-T-21 · Identifying a learning gap


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — determine which skill or student needs intervention |
| Entry | Class or student analytics |
| Main path | 1. Teacher sorts/reads the breakdown by skill. 2. A skill shows lower performance relative to the class or to a threshold. 3. Teacher opens the skill report (F-T-19 extension) to see who and how many. 4. Teacher decides the intervention. |
| Decision points | (a) The gap rule is undefined → currently the teacher interprets data rather than the system labelling a gap (OPEN: ANL-002, D-11). (b) Data insufficient for a skill → stated explicitly. (c) A system-detected gap label exists? → only if content-curated (TCH-003) or approved. |
| Error paths | None specific beyond analytics error states. |
| Completion | Teacher has an identified need and a candidate action |
| Pages | TCH-18 → TCH-20 → TCH-10 |
| System behaviour | Threshold/rule source must be explicit and explainable |
| Open questions | ANL-002, D-11, and the prohibition on unexplainable "weak" labels (S2 §6.6) |

F-T-22 · Creating a follow-up assignment


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — convert insight into instruction |
| Entry | Analytics (class/student/skill); assignment tracking |
| Main path | 1. Teacher activates "assign" from the analysis context. 2. Builder opens with recipients and/or skills pre-filled. 3. Teacher adjusts and completes the flow (F-T-10). 4. Publish. 5. Returns to the analysis to see the change over time. |
| Decision points | (a) Pre-filled recipients from the analysis → visible and editable. (b) Whether multiple students from a list can be selected at once → yes (multi-select). |
| Error paths | Pre-fill failure → builder opens empty with a notice; never silently wrong. |
| Completion | Follow-up assignment published |
| Pages | TCH-18/TCH-19/TCH-20/TCH-12 → TCH-10 → TCH-12 |
| System behaviour | Context hand-off (class, students, skill) |
| Open questions | ANL-004 (how many students can be targeted from a report) |

Diagram 14. Source file: diagrams/14_flow_analytics_to_action.mmd

F-T-23 · Planning a teaching session


| Field | Detail |
| --- | --- |
| Role / goal | Teacher — plan topics/skills for an upcoming session |
| Entry | Timetable (TCH-16) → session → lesson plan (TCH-17) |
| Preconditions | Timetable exists for the class (OPEN: who builds it — PLAN-002) |
| Main path | 1. Teacher opens the timetable (day/week). 2. Selects a session. 3. Selects topics/skills from the library (multi-select). 4. Saves the plan. 5. Optionally creates an assignment or quiz from the plan (PLAN-005 — OPEN). |
| Decision points | (a) Conflict with another session → OPEN (PLAN-004). (b) Official school calendar/holidays → OPEN (PLAN-001). (c) Lesson granularity → OPEN (PLAN-003). |
| Error paths | Save failure → state nothing changed; retry. |
| Completion | Plan saved and visible on the timetable |
| Pages | TCH-16 → TCH-17 |
| System behaviour | Calendar events of distinct types; linkage to assignments/quizzes |
| Open questions | PLAN-001…005 (all unanswered) — planning is P1 and lower risk |


### 15.3 Authentication and shared flows

F-A-03 · Session expiry and recovery


| Field | Detail |
| --- | --- |
| Role / goal | Any — continue working after a session expires |
| Entry | Any authenticated request that returns "unauthenticated" |
| Main path | 1. The app detects expiry. 2. It preserves in-flight state (builder, session). 3. SYS-02 explains expiry and offers re-authentication. 4. After sign-in, the user returns to the same context. |
| Decision points | (a) In practice session → confirmed answers must survive; unconfirmed input must be declared unsaved. (b) In builder → the builder state must survive (or be recoverable) (DESIGN RECOMMENDATION; technical feasibility OPEN: D-24). |
| Error paths | Re-authentication fails → remain on SYS-02 with retry. Context lost → return to Home with an explanation. |
| Completion | User resumes the interrupted task |
| Pages | SYS-02 → origin |
| System behaviour | Token refresh strategy, local state persistence |
| Open questions | D-24; STATE-001 state persistence rules |

F-A-04 · Permission denied


| Field | Detail |
| --- | --- |
| Main path | 1. The user requests a resource outside their scope. 2. SYS-03 renders with no data disclosure. 3. One recovery action (back/home). |
| Decision points | (a) Wrong role → route to the correct landing. (b) Class no longer accessible → fall back to another class with notice. |
| Completion | User is outside the restricted area with a clear next step |
| System behaviour | Server-side authorisation; audit of denied access (recommended) |
| Open questions | Whether denial reasons can be stated without leaking existence (DESIGN RECOMMENDATION: generic, with a support path) |


### 15.4 Flow coverage check


| Requirement | Coverage |
| --- | --- |
| Student flows requested (21) | 21 documented: F-S-01…F-S-21 |
| Teacher flows requested (23) | 23 documented: F-T-01…F-T-23 |
| Cross-role auth flows | F-S-01/02/03, F-T-01, F-A-03, F-A-04 |
| Decision branches | Present in all core flows |
| Error and recovery paths | Present in all core flows; centralised state model in §22 |
| Unresolved branches shown explicitly | 31 OPEN branches mapped to decision IDs in §29 |
| Mermaid diagrams | 8 core diagrams (student home→practice, question cycle, recovery, join class, assignment creation, analytics→action, teacher sitemap, student sitemap, auth, shells, entity model) |


## 16. PRACTICE SESSION ARCHITECTURE


### 16.1 Architectural principle

[CONFIRMED] The Practice Session is a distinct environment from the Skill Library and is focused on one question at a time (S1 §6: "تمرین محیط باید روی یک سؤال در هر لحظه متمرکز باشد"; S2 §1.3: the two are two different pages).

[DESIGN RECOMMENDATION] The session is built as one stable shell + one question renderer + N answer components + one feedback panel. The shell, the header semantics, the submission mechanics, the persistence mechanics, and the feedback layout are identical for every question type. Only three things vary by type: the prompt rendering, the answer input, and the answer contract (validation/correctness).

This is the single most consequential architecture decision in the document: it prevents 17 different page behaviours, 17 different accessibility implementations, and 17 different analytics shapes.


### 16.2 Session anatomy


| Zone | Contents | Behaviour | Status |
| --- | --- | --- | --- |
| S-0 Save indicator | Persistence state (saving / saved / not saved / offline) | Persistent, textual, non-modal | [CONFIRMED] S1 §6.3, §11 |
| S-1 Session header | Skill name + topic; question position (e.g. 4th question, count if known); elapsed time; score slot; exit control | Low visual emphasis; never competes with the question | [CONFIRMED] contents (S1 §6, S2 §5.5); low emphasis is [DESIGN RECOMMENDATION] |
| S-2 Assignment/context strip | When the session was launched from an assignment: the skill's place in the assignment and the deadline | One line; collapsible on mobile | [DESIGN RECOMMENDATION] (fills C-10/D-09) |
| S-3 Question area | Instruction text, question prompt, media (image/audio/math), numbering if the question has parts | Renders before the answer input; media has text alternatives | [CONFIRMED] S1 §6 |
| S-4 Answer area | The type-specific answer component | One input family per question; no mixed expectations | [CONFIRMED] S1 §6 |
| S-5 Hint affordance | Hint control + revealed hint content | Optional; score-neutral (PRA-004) | [CONFIRMED] existence; behaviour partly [OPEN] (D-29) |
| S-6 Primary action | Submit / Check (label semantics in §16.4) | Single primary; locks during flight | [CONFIRMED] S1 §6 |
| S-7 Feedback panel | Result, correct answer, explanation, solution method, continue | Replaces or overlays the answer area without hiding the question | [CONFIRMED] S1 §6 |
| S-8 Session footer | Save state, question position, (no back control) | Forward-only | [CONFIRMED] PRA-008, STU-017 |


### 16.3 Session state machine

Diagram 15. Source file: diagrams/15_session_state_machine.mmd

Notes on the model:

- Presenting → Feedback is one-way per question: there is no Feedback → Presenting for the same question (no retry, PRA-003; no editing, PRA-008).
- Offline is a first-class state, not an error: the student may still be in a session that cannot submit.
- SummaryPending exists because the score formula is unconfirmed (GAP-02): the UI must be able to say "your result is not available yet" rather than invent one.

### 16.4 Timer, score, and question position


| Element | Confirmed behaviour | Consequences and open points |
| --- | --- | --- |
| Timer | Elapsed time, counting upward — the sources describe "زمان سپری شده", never a countdown (S1 §6, S2 §5.5) | No countdown, no visible time limit, no time pressure in practice. Distinguishing active time from page-open time is an explicit open question (PRA-006) — therefore the label must be honest: until PRA-006 is answered, present it as "time in session", not "time spent practising" (D-47). |
| Score / SmartScore | A per-skill progress indicator; formula and semantics not approved (BM-IXL-002, PRA-010, GAP-02) | The UI reserves a score slot with three states: (a) available → numeric; (b) not enough data → "not enough data yet"; (c) model unavailable → slot hidden entirely. Medals are confirmed at 80/90/100 (STU-020), so the display of a value is expected, but its computation is not the designer's to invent. |
| Question position | Visible (S1 §6, S2 §5.5) | If the total is unknown (variable-length practice), show position only ("question 7"), never a fake denominator. |
| Submit label | "Check/Submit" then a distinct "Continue" after feedback (S2 §8.2 implies a continue control) | Never one button that changes meaning mid-flight without a state change. |
| Skip | Mentioned only in PRA-010 ("Hint/Skip/Retry") as a factor that may affect the score | OPEN (D-34): whether skip exists at all. Until confirmed, no skip control is drawn. |
| Back / previous question | Not allowed | [CONFIRMED] PRA-008, STU-017 |
| Retry | Not allowed | [CONFIRMED] PRA-003 |


### 16.5 Entry and exit


| Aspect | Rule | Status |
| --- | --- | --- |
| Session entry | From assignment card, recommendation, library row, or resume | [CONFIRMED] |
| Context carried into the session | Skill identity; origin (which surface); assignment context if any | [DESIGN RECOMMENDATION] — needed for correct "back" behaviour and for analytics attribution (BM-IXL-004) |
| Exit control | Always visible; never inside a menu | [CONFIRMED] safe exit (S2 §5.5) |
| Exit confirmation | States what is saved | [DESIGN RECOMMENDATION] + [CONFIRMED] save semantics (S1 §6.3) |
| Exit during in-flight submission | Blocked or explicitly warned | [DESIGN RECOMMENDATION] (P-08/P-09) |
| Exit destination | The origin surface (Home / Library / assignment context) | [DESIGN RECOMMENDATION] |
| Browser back / tab close | Treated as an exit attempt: persist confirmed answers, warn about unconfirmed input | [DESIGN RECOMMENDATION] (P-15) |


### 16.6 Feedback architecture

Feedback is the product's core educational value (problem P-2 in §3.2). It has a fixed content model, independent of question type.


| Feedback element | Correct answer | Incorrect answer | Requirement source |
| --- | --- | --- | --- |
| Result statement | Brief positive acknowledgement | Neutral, non-judgmental statement that the answer is not correct | [CONFIRMED] S2 §9.2 (copy examples) |
| Correct answer | Reinforced (shown or acknowledged) | Always shown | [CONFIRMED] S1 §6, S2 §8.2 |
| Explanation | Shown when content provides it | Shown when content provides it | [CONFIRMED] S1 §6 |
| Solution method | Shown when content provides it | Shown when content provides it — this is the explicit remedy for problem P-2 | [CONFIRMED] S1 §1.2, §6 |
| Score change | Shown only if the model is approved; never estimated | Same | [OPEN] GAP-02 |
| Hint recap | Optional: what the hint suggested vs what was answered | Same | [DESIGN RECOMMENDATION], tied to D-29 |
| Next action | One continue control | One continue control | [CONFIRMED] |
| Reward feedback | Deferred to completion, not shown per question | Same | [DESIGN RECOMMENDATION] (P-12) |
| Non-colour signalling | Icon + text, always | Icon + text, always | [CONFIRMED] S1 §12 ("رنگ منتقل نشود") |

Feedback layout rules

1.  The question prompt and the student's submitted answer remain visible in the feedback state. Rationale: the explanation refers to them; hiding them forces recall (P-02).

2.  The feedback region appears below the answer area on laptop/tablet and as an inline expansion on mobile — never as a modal that covers the question.

3.  Only one continue control; no "try again" control exists (PRA-003).

4.  If the explanation is missing from the content, show the correct answer and state plainly that no explanation is available for this question — never generate substitute instructional text.


### 16.7 Persistence, safe exit, and recovery

[CONFIRMED] An answer must survive exit, refresh, network interruption, and re-entry; "Pending" and "Saved" are different states; only server-confirmed state may be presented as saved (S1 §6.3, §11).


| Concern | Architecture rule |
| --- | --- |
| When is an answer "confirmed"? | Only after the server acknowledges the evaluation/persistence. Until then it is pending. |
| What is restored on resume? | The last confirmed state. Unconfirmed input is not presented as answered. |
| What happens with a local draft? | Permitted as a recovery aid, but the server is the authority (OPEN: STATE-003, D-24). |
| Silent overwrite | Forbidden (S1 §11.1). |
| Offline behaviour | Banner + degraded action set: reading is allowed, submitting is blocked, confirmed progress is unaffected. |
| Retention window | OPEN (STATE-002): how long a session stays resumable. |
| Duplicate submission | Prevented client-side (lock) and server-side (idempotency key). |
| Session completion record | Written server-side; the client never marks a skill complete on its own. |


### 16.8 Session completion and end conditions

[CONFIRMED] A practice session ends when either the student reaches a score of 100 or the student exits (PRA-007).


| End condition | What the student sees | Open questions |
| --- | --- | --- |
| Score reaches 100 | Completion summary; medals at 80/90/100 per STU-020; next step offered | Whether "completed" also requires mastery status (D-06); whether the skill row changes to "completed" (D-05) |
| Student exits | Safe exit; confirmed progress retained; resume available | Whether a partial session counts toward assignment completion (D-31) |
| No questions remain | Session ends like a completion; explain why | Whether the skill is then considered complete (D-06) |
| Network loss that cannot resolve | Exit with an explicit unsaved declaration | Retention (D-24) |
| Session invalidated server-side | Explicit "no longer resumable" state | Retention policy (D-24) |


### 16.9 Interaction constraints (binding for every question type)


| # | Constraint | Source |
| --- | --- | --- |
| 1 | One question visible at a time | [CONFIRMED] |
| 2 | Forward-only; no return to a previous question; no editing a submitted answer | [CONFIRMED] |
| 3 | No retry after an incorrect answer | [CONFIRMED] |
| 4 | Hint use does not change the score | [CONFIRMED] |
| 5 | Equivalent answer forms are accepted unless the question explicitly constrains the form | [CONFIRMED] PRA-002 |
| 6 | Correctness is never conveyed by colour alone | [CONFIRMED] |
| 7 | Every primary action is keyboard-operable with a visible focus state | [CONFIRMED] |
| 8 | Drag-and-drop always has a non-drag alternative | [CONFIRMED] |
| 9 | Score and time never dominate the question | [CONFIRMED] |
| 10 | No countdown, no time pressure, no failure penalties | Derived from confirmed constraints; design rule |
| 11 | Rating/emoji/"how do you feel" widgets, sound effects, and confetti are not introduced without a decision | [DESIGN RECOMMENDATION] |


### 16.10 Session acceptance criteria (design-level)

1.  A student can answer a question without choosing a role, without leaving the flow, and without an intermediate page. (Source: S1 §16.1)

2.  Submission is validated against the question contract and cannot be duplicated. (S1 §16.1)

3.  Correct/incorrect feedback always includes a valid explanation when the content provides one; the correct answer is always shown. (S1 §16.1)

4.  pending and saved are visually and textually distinguishable at all times. (S1 §16.1)

5.  Exiting and returning restores the last confirmed answer. (S1 §16.1)

6.  An unsaved answer is never presented as saved, including in offline conditions. (S1 §16.1)

7.  In RTL layout, mathematical expressions and numeric inputs retain the correct order. (S1 §16.1, §12)

8.  Primary actions are operable by keyboard and by touch. (S1 §16.1)

9.  Every question type renders inside the same shell with no layout jump between consecutive questions of different types. [DESIGN RECOMMENDATION] — the strongest defence against a fragmented experience.

10.  Feedback never auto-advances. [DESIGN RECOMMENDATION]


## 17. QUESTION TYPE AND ANSWER COMPONENT ARCHITECTURE


### 17.1 Evidence position (read this before specifying any question type)


| Fact | Status |
| --- | --- |
| A 17-type question inventory exists in the staging environment | [CONFIRMED] S3 SCP-006 |
| The 17 types are documented in an attached file that models the question types present in IXL | [CONFIRMED] S2 §3.8 |
| The Naranj brief warns that this competitor-derived list is incomplete and must not be used as Naranj's inventory by substitution | [CONFIRMED] S1 §6.2 |
| The workbook itself | [SUPPLIED AND REVIEWED] — Question types (2).xlsx; transcribed in §17.9 and Appendix A |
| Ownership of the official MVP question-type list | [OPEN] — PRA-001 answered "myself / the product side", i.e. the Product Owner owns it |

Consequence: this section defines the architecture, the component contract, the specification template, and the interaction families that will hold the 17 types. It does not list the 17 names, their answer formats, or their validation rules, because doing so would fabricate requirements. §17.5 is a fill-ready specification table.


### 17.2 What is confirmed about question interaction


| Confirmed rule | Source |
| --- | --- |
| Each question has: a type, content, optional media, an answer, a solution, an explanation, and validation rules | S1 §4 (Question entity) |
| Answer interaction must match the question type (keyboard and touch) | S1 §6 |
| Input contract must define type, limit, keyboard, touch, paste | S1 §6.2 |
| Validation must distinguish incomplete/invalid answers and produce a correctable error | S1 §6.2 |
| Correctness must handle exactness, equivalence, order, units, fractions, decimals, tolerance | S1 §6.2 |
| Feedback includes correct answer, explanation, solution method, and hints | S1 §6.2 |
| Accessibility per type: labels, focus, keyboard, drag alternative, contrast | S1 §6.2 |
| Analytics per question: attempts, errors, time, hint usage, final answer | S1 §6.2 |
| Equivalent answer forms accepted unless the question constrains the form | PRA-002 |
| Hints exist and do not affect the score | PRA-004 |
| No retry | PRA-003 |
| No backward navigation / editing | PRA-008, STU-017 |
| Three illustrative types named in the brief: multiple choice, short answer/numeric, matching | S2 §3.8 (explicitly "examples for design to consider", not the definitive list) |
| Mathematical content requires correct operator/parenthesis ordering in RTL, and numeric input must define Persian-digit and decimal-separator behaviour | S1 §12 |


### 17.3 Component architecture

Diagram 16. Source file: diagrams/16_question_components.mmd


| Component | Responsibility | Shared or specialised | Notes |
| --- | --- | --- | --- |
| PracticeSessionShell | Layout, header, timer, score slot, exit, save indicator, responsive behaviour | Shared, single implementation | The only component allowed to own session-level state |
| QuestionRenderer | Reads question.type and mounts the right input family; owns prompt+input composition | Shared | Unknown type must render a safe fallback: display the prompt, disable submission, log an error (DESIGN RECOMMENDATION) |
| QuestionPrompt | Renders instruction, prompt, media, math | Shared, with media variants | Math rendering must be directionally isolated (§25) |
| AnswerInput | One per interaction family (see §17.4) | Specialised per family | Must expose a uniform interface: value, isComplete, isValid, focusFirstControl, readDescription |
| AnswerValidator | Local completeness/format checks, producing specific messages | Shared logic + per-family rules | Never performs correctness; only validity |
| AnswerSubmission | Locking, in-flight state, idempotency, retry handling | Shared | Guarantees no duplicate submissions |
| AnswerContract (server) | Correctness evaluation: exactness, equivalence, order, units, tolerance | Server-side, per-type rules | The client must never decide correctness |
| FeedbackPanel | Uniform feedback layout across all types | Shared | Content-dependent, not type-dependent |
| HintComponent | Reveals hint content progressively per content rules | Shared shell, content-specific | Score-neutral (PRA-004) |
| SessionProgress | Question position, elapsed time, score slot | Shared | Score slot has explicit unavailable states |
| PersistenceStatus | Pending/saved/failed/offline | Shared | Textual, always visible in the shell |

Rule: a designer may not create a new page layout for a question type. If a type genuinely needs a different spatial arrangement (e.g. a large manipulable canvas), the answer area may expand into a full-width region inside the same shell — but the header, submission, feedback, persistence, and exit behaviour stay identical.


### 17.4 Interaction families (proposed grouping)

[DESIGN RECOMMENDATION] The 17 source-defined types can be expected to collapse into a small number of interaction families. This grouping is an implementation and design-efficiency proposal; it does not rename or replace any source type. Each workbook-listed interaction is mapped to a proposed family in §17.9; this mapping is a design recommendation, not a change to source terminology.


| Family ID | Family | Interaction shape | Typical source types it may contain | Input modalities | Key risks |
| --- | --- | --- | --- | --- | --- |
| F-1 | Single selection | Choose exactly one option | Multiple choice (single answer), true/false, image choice | Pointer, touch, keyboard (radio semantics) | Distinguishing selection from submission |
| F-2 | Multi selection | Choose one or more options, possibly with constraints (choose 2 of 5) | Multi-select, checkbox grids, matrix/grid selection | Pointer, touch, keyboard (checkbox semantics) | Communicating the required count; validation messages |
| F-3 | Free text / numeric entry | Type an answer into one or more fields | Short answer, numeric answer, fill-in-the-blank, expression entry | Physical keyboard, on-screen keyboard, paste, IME | Equivalence (fractions/decimals/units), RTL numeric entry, Persian digit handling |
| F-4 | Structured pairing | Build relationships between two sets | Matching, pairing, connecting lines, drag-to-match | Drag and non-drag alternative | Drag-only accessibility failure; partial pairing state |
| F-5 | Ordering / sequencing | Arrange items into a correct order | Ordering, ranking, sequence building, drag-to-sort | Drag and move-up/down controls | Precise drag on touch; announcing position to a screen reader |
| F-6 | Spatial / graphical response | Act on a visual: select a region, place a point, plot, manipulate a figure | Hotspot selection, plotting on a coordinate plane, shape construction | Pointer, touch, keyboard alternative | Small targets; precision; alternative modality |
| F-7 | Media-driven response | Answer after consuming audio/video | Listen-and-answer, audio-to-numeric | Media player + a family-appropriate input | Media accessibility, replay policy, autoplay prohibition |
| F-8 | Multi-part / nested response | A single question with several sub-answers or a table of inputs | Multi-blank, table completion, stepped parts | Composite of F-1…F-3 | Partial completion semantics, focus management, submission granularity |

Deliberately not created as separate families: "hint", "explanation", "calculator", "scratchpad" — these are cross-cutting affordances whose existence is unconfirmed. A scratchpad/work area is not described anywhere in the sources and must not be invented (OPEN: D-34).


### 17.5 Per-type specification template (fill-ready)

[DESIGN RECOMMENDATION] The supplied workbook has been transcribed in §17.9 and Appendix A. The template remains the standard for implementation-level details not defined by the workbook.


| # | Field | What must be recorded | Why it matters to UX |
| --- | --- | --- | --- |
| 1 | Exact source name | The workbook's name, verbatim, plus a Persian label if the interface language requires one | Terminology fidelity; the names are product terms |
| 2 | Source identifier | Workbook row/ID | Traceability |
| 3 | Interaction family | One of F-1…F-8 | Determines the component and the accessibility profile |
| 4 | Question structure | What the prompt contains (text, math, media, sub-parts) | Layout and reading order |
| 5 | Input method | Pointer / touch / keyboard / drag / media playback / composite | Input design and device parity |
| 6 | Answer format | The expected answer representation(s) | Validator and correctness rules |
| 7 | Validation rules | Completeness and format rules, error messages | Error prevention (P-09) |
| 8 | Correctness rules | Exactness, equivalence, order sensitivity, units, tolerance | Prevents false negatives (the most damaging defect in an ed-tech product) |
| 9 | Required UI components | Reused components + any specialised ones | Component reuse and cost |
| 10 | Interaction behaviour | Selection model, focus movement, submit enablement, partial states | Behaviour spec inputs |
| 11 | Feedback behaviour | What is shown on correct/incorrect; whether the answer is re-shown annotated | Feedback panel variants |
| 12 | Error states | Empty, incomplete, invalid, unsupported input | State model (§22) |
| 13 | Accessibility | Roles, labels, keyboard map, announcer text, non-drag alternative, media alternatives | A11Y requirement (S1 §12) |
| 14 | Responsive behaviour | Laptop / tablet / mobile layouts; touch target sizes; scroll policy | Responsive architecture (§23) |
| 15 | Analytics events | Attempts, errors, time, hint use, final answer | S1 §6.2 requirement |
| 16 | Content requirements | What the content team must author per question (answer forms, explanation, hint) | Content readiness gate |
| 17 | Open questions | Anything the workbook does not define | Decision register |


### 17.6 The answer contract

[CONFIRMED requirements — S1 §6.2, PRA-002] The answer contract is the boundary between UX and engineering. It must be specified per type and must cover:


| Contract element | Question it answers | UX consequence |
| --- | --- | --- |
| Input constraints | Which characters/values are allowed? Max length? Are Persian and Latin digits both accepted? | The input must constrain and guide rather than reject after the fact |
| Completeness | When is an answer "complete"? | Submit enablement and inline reasons |
| Format validation | What is a malformed answer (vs. merely wrong)? | Distinct error message: "this answer is not in a valid format" vs "this answer is not correct" |
| Equivalence policy | Are 1/2, 0.5, ۲/۱-style inputs, 50%, and ½ all accepted? | [CONFIRMED] Yes, equivalent forms are accepted unless the question explicitly restricts the form (PRA-002) |
| Order sensitivity | Do ordering/pairing answers care about order? | Validator and feedback explanation |
| Units | Are units required, optional, or pre-filled? | Input affordance and error copy |
| Tolerance | Is a numeric tolerance allowed (decimals, rounding)? | Correctness fairness |
| Restricted-form clauses | Where the question does require a specific form (e.g. "answer as a simplified fraction") | The prompt must state the restriction explicitly, otherwise the restriction is unfair |
| Normalisation | Whitespace, Arabic/Persian character variants (ي/ی, ك/ک), digit forms, decimal separators | [TECHNICAL VALIDATION] — Persian text normalisation is a real correctness risk and must be specified before the validator is built |


### 17.7 Question lifecycle

Diagram 17. Source file: diagrams/17_question_lifecycle.mmd

Edge cases and failure recovery:


| Edge case | Required behaviour |
| --- | --- |
| Double submit (fast tap / Enter held) | Locked client-side; idempotent server-side; the same evaluation returned |
| Submit with empty answer | Blocked with a specific message; no server call |
| Submit with malformed answer | Blocked locally when detectable; otherwise server returns a validation error distinct from incorrect |
| Evaluation timeout | Input preserved; retry offered; the answer is not re-typed |
| Network loss after submit, before response | State pending → retried with the same idempotency key when connectivity returns; the student is told the answer is not yet saved |
| Duplicate answer arrives at the server | Idempotency prevents double scoring |
| Question deleted/changed mid-session (OPEN: D-12) | Session shows a content-changed state and moves on without scoring inconsistency |
| Unknown question type at render time | Safe fallback: prompt shown, submission disabled, support path offered |
| Media fails to load | Show a retry; if audio is essential to answering, the question must be replaced (not silently skipped) — OPEN: D-34 |
| Hint used | Logged separately; score unaffected; the student may still answer |
| Student closes the tab mid-question | Confirmed answers persist; the unsubmitted input is declared unsaved on return |


### 17.8 Media and mathematical content inside questions


| Requirement | Rule | Status |
| --- | --- | --- |
| Images | Must have an accessible description where they carry meaning; decorative images marked as such | [DESIGN RECOMMENDATION]; contrast/size validation required |
| Audio | Explicit play control; no autoplay; replay policy must be defined; text alternative where pedagogically permissible | [CONFIRMED] accessibility requirement (S1 §12) |
| Video | Not described in the sources; do not design a player | [OPEN] |
| Math expressions | Rendered with correct operator ordering in RTL; expressions isolated as LTR runs; parentheses must not reorder | [CONFIRMED] S1 §12 |
| Numeric input | Persian/Latin digit behaviour, decimal separator, and grouping must be specified | [CONFIRMED] requirement, rules [OPEN] (D-35) |
| Units | Unit entry must be specified per question (pre-filled vs typed) | [OPEN] (D-35) |
| Diagrams | Diagram-based questions require keyboard-reachable alternatives | [CONFIRMED] general accessibility rule |


### 17.9 Accessibility requirements per family


| Family | Roles / semantics | Keyboard model | Non-pointer alternative | Announcer requirements |
| --- | --- | --- | --- | --- |
| F-1 Single selection | Radio group with a group label | Arrow keys move, Space selects, Enter submits | Native | Announce group name, option count, selection |
| F-2 Multi selection | Checkbox group with a group label | Tab/arrow within group, Space toggles | Native | Announce required count and current count |
| F-3 Text/numeric | Text input(s) with labels and input hints | Standard typing; Enter submits only when valid | Native | Announce format requirements and errors |
| F-4 Pairing | Two lists with explicit pairing controls | Select on one list, then on the other; or per-item combobox | Required (drag must not be the only method) | Announce current pairings as a list |
| F-5 Ordering | List with position controls | Move up/down buttons, or "grab mode" with keys | Required | Announce item name and position ("item 2 of 5") |
| F-6 Spatial | Interactive region with explicit focusable targets | Each target focusable and activatable | Required | Announce target identity and state |
| F-7 Media-driven | Media element + input | Play/pause, replay, then answer | Text alternative where permissible | Announce playback state and remaining replays |
| F-8 Multi-part | Grouped inputs with sub-labels | Sequential tab order; no focus traps | Native | Announce part number and total parts |

Common accessibility acceptance criteria for every type (from S1 §12 and the engagement's requirements):

1.  Fully operable without a pointer.

2.  Visible focus on every interactive element, in logical order.

3.  No colour-only meaning: selected/correct/incorrect/disabled all carry text or icon.

4.  Touch targets ≥ recommended minimum in §23.7, with spacing.

5.  Errors announced and associated with the specific input.

6.  Motion respects the user's reduced-motion preference.

7.  Zoom to 200% without loss of function.


### 17.10 Responsive behaviour per family


| Family | Laptop (primary) | Tablet (primary) | Mobile (secondary) |
| --- | --- | --- | --- |
| F-1 / F-2 | Options in one column beneath the prompt | Same, larger targets | Same; full-width options; sticky submit |
| F-3 | Inline fields sized to expected answer | Same with larger numeric keypad support | Numeric/expression keyboard hints; single field per row; avoid horizontal scroll |
| F-4 | Two columns side by side | Two columns or stacked with connectors | Stacked with explicit "pairing" controls (drag between two columns is unreliable on small screens) |
| F-5 | Vertical list with handles | Same | Move-up/down buttons become primary; drag secondary |
| F-6 | Full-width canvas with targets | Same | Reduced canvas with zoom/pan; alternative list-based input strongly recommended |
| F-7 | Media + input side by side | Stacked | Stacked; media sticky if the answer refers to it |
| F-8 | Grid/table layout | Stacked parts with labels | One part per screen segment, with explicit part navigation |


### 17.11 Governance: how the inventory gap is closed

[DESIGN RECOMMENDATION] A short, sequenced closure plan (owner: Product Owner per PRA-001):

1.  Review the workbook transcription in §17.9 / Appendix A and confirm MVP inclusion and implementation priority for each interaction.

2.  Transcribe each type into the §17.5 template — 17 rows, one dedicated workshop.

3.  Map each type to an interaction family; flag any type that fits none (that flag is a component-architecture decision).

4.  For each type, confirm the answer contract with the content team (§17.6), especially equivalence and Persian normalisation.

5.  Produce the accessibility profile per family and run a keyboard-only pass on the three highest-frequency types first.

6.  Only then produce high-fidelity specifications for the answer components.

Blocking rule: no high-fidelity design of answer components should start before steps 1–4 are complete. Wireframes of the shell can proceed immediately.


## 18. ASSIGNMENT AND CLASS MANAGEMENT


### 18.1 Class management

18.1.1 Confirmed rules


| Rule | Detail | Source |
| --- | --- | --- |
| Who can create a class | A system admin or a teacher | [CONFIRMED] TCH-009 |
| Required fields | Class title, school, subject, academic year | [CONFIRMED] TCH-009 |
| Who issues/maintains the class code | The teacher and the school admin (generate, renew, invalidate) | [CONFIRMED] TCH-010 |
| Manual student addition | Allowed | [CONFIRMED] TCH-011 |
| Student removal | Does not affect previous records; from the moment of removal the student's data is no longer counted in class data | [CONFIRMED] TCH-012 |
| Teacher composition | Exactly one primary teacher; several secondary teachers are allowed; the difference is in access level | [CONFIRMED] TCH-013 (delta undefined → D-10) |
| Default class | The class the teacher was last in; the teacher can set a default in settings | [CONFIRMED] TCH-001 |
| Active classes at a time | One | [CONFIRMED] TCH-002 |
| Class membership relevance to students | No meaningful functional difference; matters for structured data and the teacher's roster view | [CONFIRMED] AUT-006 |
| Class code entry timing | After first sign-in, and possible at any time | [CONFIRMED] AUT-003 |
| Code technical rules (length, expiry, attempts, reuse, invalidation) | Technical team | [OPEN] D-14 |

18.1.2 Class model implied by the rules

Diagram 18. Source file: diagrams/18_class_model_er.mmd

[DESIGN RECOMMENDATION] Model membership as a period (start/end), not a boolean. Rationale: TCH-012 requires that historical records be retained while class aggregates exclude the student from the removal date forward — impossible to implement or to explain in the UI without a membership period. Risk if rejected: aggregate numbers become historically unstable and unexplainable to teachers.

[OPEN DECISION] D-35 — whether a student can belong to multiple classes simultaneously. Nothing in the sources forbids it, and TCH-015 allows an assignment to target students across classes, which implies multi-membership is possible. The UI must therefore not assume "one class per student".

18.1.3 Class-level UX rules


| Rule | Rationale |
| --- | --- |
| Class creation asks only for the four confirmed fields | Adding fields would invent requirements (and the four are explicitly listed) |
| Class code must be presented as a copyable, classroom-projectable block with join instructions | The code exists to be distributed verbally; the UI must support that moment |
| Removing a student must state the confirmed consequence verbatim in plain language | TCH-012 is a nuanced rule; users must not be surprised |
| Former members remain visible in a filtered view | Teachers need history; hiding them would make records appear to vanish |
| Role per class (primary/secondary) must be visible in the class list | Prevents a secondary teacher assuming full rights (D-10) |


### 18.2 Assignment domain model


| Attribute | Confirmed definition | Status |
| --- | --- | --- |
| Skills | One or more; ordering is not mandatory | [CONFIRMED] S2 §4.4, TCH-014 |
| Recipients | A class, or selected students; students from multiple classes allowed with no restriction | [CONFIRMED] S2 §4.4, TCH-015 |
| Review | Mandatory before publishing; must reveal skills, recipients, deadline and instructions | [CONFIRMED] S1 §16.2, S2 §4.4 |
| Schedule | Start/publish date and deadline; MVP deadline timezone is Iran time | [CONFIRMED] S1 §7.4, TCH-020 |
| Instructions | A short instruction field "if supported" | [CONFIRMED as a candidate field, support level OPEN] D-09 |
| Duplicate detection | System should warn; not blocking | [CONFIRMED] TCH-016 |
| Post-publish edit | Allowed | [CONFIRMED] TCH-017 |
| Reschedule | Allowed | [CONFIRMED] TCH-017 |
| Cancel | Allowed | [CONFIRMED] TCH-017 |
| "Duplicate assignment" action | Not a meaningful concept in this product | [CONFIRMED] TCH-017 |
| Effect of changes after students start | No effect on already recorded answers | [CONFIRMED] TCH-018 |
| Teacher reminders to students | Not provided; the system issues its own alerts | [CONFIRMED] TCH-021 |
| Status set | Undefined; the clarification answer lists mastery-like stages | [OPEN] C-05, D-05 |
| Notification of publication/change | Undefined | [OPEN] D-23 |


### 18.3 Assignment builder architecture

[DESIGN RECOMMENDATION] Four steps (T-D template), with a persistent summary:


| Step | Purpose | Validation gate | Can be skipped? |
| --- | --- | --- | --- |
| 1 · Recipients | Whole class or specific students | ≥1 recipient, authorised only | No |
| 2 · Skills | Add/remove from the library; optional ordering | ≥1 skill | No |
| 3 · Schedule & instructions | Start date, deadline, short instructions | Deadline valid, in the future, Iran time | No (deadline required) |
| 4 · Review | Full summary of consequences | Re-validated server-side | No |

Design rules:

- The summary rail (class, recipients count, skills count, deadline) is visible on steps 1–4 and on tablet becomes a sticky banner.
- Step order is fixed; each step is re-enterable without data loss.
- "Publish" is the only primary action on step 4; "Back" is secondary; "Cancel" requires confirmation only if data exists.
- Draft support is not assumed (D-07). If drafts are not approved, the builder must warn on exit: "this assignment has not been published and will be lost".
- The builder must never auto-publish on a timer or gesture.

### 18.4 Status and progress vocabulary (the highest-risk consistency area)

[CONFLICT C-04/C-05] The sources contain two overlapping vocabularies:

- S1 §4.1 skill statuses: Not Started · In Progress · Practicing · Mastered · Needs Review · Locked
- S3 TCH-019 "assignment statuses": Not started · Attempt · Familiar · Proficient · Mastered
[DESIGN RECOMMENDATION] Do not merge them into one list. They answer different questions and mixing them is precisely how products end up with three names for one condition (see anti-pattern in §13.7). Propose two explicit axes for confirmation (D-05):


| Axis | Purpose | Proposed values | Where shown |
| --- | --- | --- | --- |
| A. Scheduling / availability status (the assignment itself) | What state is this assignment in? | Scheduled · Active · Closed/Expired · Cancelled | Teacher assignment list and tracking header; student card (as deadline urgency, not as jargon) |
| B. Per-student progress in a skill (the student's position) | How far is this student? | Not started · In progress · Completed (+ mastery level native to axis C) | Teacher tracking table; roster; student library row |
| C. Mastery level (learning attainment) | How well is the skill held? | The clarification's five-stage scale (Not started → Attempt → Familiar → Proficient → Mastered) if the content team confirms it | Skill rows, analytics, medals mapping |

Rules if this proposal is accepted:

- Axis A is never applied to a student; axis B/C are never applied to an assignment.
- Every status must have: a label (text), a non-colour indicator, a definition available on demand, and a permitted transition list.
- The same status must use the same word on the teacher side and the student side (S2 §8.2 requires unified labels across pages).
- [OPEN] The relationship between "Completed" (axis B) and "Mastered" (axis C) is undefined — D-06.

### 18.5 Assignment tracking requirements


| Requirement | Rule |
| --- | --- |
| Aggregate | Counts per status, with a denominator and a window |
| Per-student | Status + per-skill progress; no per-question dump unless approved (D-20) |
| Overdue | Textual distinction, still inspectable |
| Removed students | Shown as former members; excluded from aggregates from the removal date (TCH-012) |
| Actions | Follow-up assignment (primary), reschedule, cancel, open student report |
| Edit disclosure | Editing states clearly that recorded answers are unaffected (TCH-018) |
| Empty state | "Nothing recorded yet" with the deadline and the reason, never zeros-as-data |


## 19. QUIZ GENERATOR


### 19.1 What is confirmed


| Rule | Source |
| --- | --- |
| The teacher configures parameters; the system selects questions from the existing bank | S1 §8.1, S2 §4.6 |
| The teacher does not create or edit questions | S1 §2, S2 §4.6 |
| The generated output is previewable before publishing; the teacher may exit preview, change parameters and regenerate | S1 §8.1 |
| Parameters mentioned in the brief as examples: number of questions, level, time | S1 §8.1 (list explicitly described as non-final) |
| Content scope covers subject/grade/topic/skill | S1 §8.1 |
| Insufficient bank must be explained in understandable language with a clear resolution | S2 §5.5 |
| Recipients: class or students | S1 §8.1, S2 §4.6 |


### 19.2 What is not confirmed (and therefore not designed)


| Unknown | ID | UX impact |
| --- | --- | --- |
| The final parameter list and the allowed range of each | QUIZ-001 | Determines the entire configuration screen; no parameter may be drawn before approval |
| Whether questions are randomly selected or chosen by difficulty | QUIZ-002 | Determines whether "difficulty" is a teacher-facing concept |
| Behaviour when the bank is insufficient beyond "explain it" | QUIZ-003 | Determines the recovery paths |
| Whether individual questions may be removed in preview | QUIZ-004 | Determines whether preview is read-only |
| Time, attempts, order, result visibility, grading | QUIZ-005 | Determines the student-facing quiz experience and the results page |
| Whether the quiz flow is separate from the Practice Session or shares it | QUIZ-006 | Blocking for the student experience |
| Whether a published quiz can be edited, cancelled or extended | QUIZ-007 | Determines tracking actions |
| Whether quizzes are a distinct object or a type of assignment | — | Determines list, navigation, and tracking design |

[DESIGN RECOMMENDATION] Treat the quiz as a parameterised generator that produces a publishable assessment object which reuses the Assignment tracking shell, unless QUIZ-006/QUIZ-007 indicate otherwise. Rationale: teachers already understand "assign → track"; a second, parallel tracking model would double the analytics surface for no confirmed benefit. Risk if rejected: rework of the tracking and analytics pages.


### 19.3 Quiz Generator flow architecture

Diagram 19. Source file: diagrams/19_quiz_generator_flow.mmd


### 19.4 Design rules for the generator

1.  No unapproved parameter is rendered. If the product team has not confirmed a parameter, it does not appear in the wireframe — not even disabled, because a disabled control is a promise.

2.  Preview is read-only. The teacher's only levers are regenerate and (if approved) remove.

3.  Insufficiency is explained with numbers: "This scope contains 6 questions; you asked for 10. Reduce to 6, or widen the scope to the whole topic."

4.  Generation is a blocking, cancellable state with a progress indication, because the bank query may be slow.

5.  Publishing is idempotent and confirms from the server.

6.  Results are not promised until QUIZ-005/007 are answered.


### 19.5 Quiz-taking experience (deliberately undefined)

[OPEN DECISION] D-22 (blocking). No source defines how a student takes a quiz: whether it uses the Practice Session shell, whether answers can be revised, whether the timer counts down, whether feedback is shown immediately or at the end, whether attempts are limited, whether results are visible to the student.

UX consequence: quizzes can be created and published in the first release only if the student-side experience is also in scope. If it is not, the Quiz Generator must be treated as an authoring tool with no student-facing commitment — and the product team must decide whether that is acceptable for the Dey release. This is one of the three highest-risk scope questions in the register.


## 20. ANALYTICS, RECOMMENDATIONS, AND GAMIFICATION


### 20.1 Analytics architecture principle

[CONFIRMED] Every indicator must have a definition, a denominator and a time window, and must be interpretable (S1 §14); reports must not be judgmental and must be paired with an action (S2 §4.5, §6.6); each analytics surface must lead to the next instructional action (S1 §8.3).

[DESIGN RECOMMENDATION] Therefore every metric in the product is modelled as an indicator object with mandatory metadata, and no chart may be built from an indicator that lacks it:


| Indicator field | Required? | Example |
| --- | --- | --- |
| Name | Yes | "Skills completed" |
| Plain-language definition | Yes | "Number of distinct skills the student reached a completed state in" |
| Numerator | Yes | Skills reaching completion |
| Denominator | Yes (may be "none — count") | Skills started |
| Time window | Yes | Last 7 / 30 days, term-to-date |
| Minimum sample size | Yes | Below 3 data points → show as "not enough data" |
| Source of evidence | Yes | Assigned practice / free practice / both (BM-IXL-004 open) |
| Update latency | Yes | Real-time / hourly / nightly (ANL-006 open) |
| Access level | Yes | Student own / teacher class / parent authorised / admin aggregate |
| Action attached | Yes | Link to the action this indicator suggests |


### 20.2 Indicator registry (structure, not final values)

[CONFIRMED] The final indicator sets are undecided for both student (STU-015) and teacher (ANL-001). The registry below is the structure that must be filled, with the categories that the sources do name.


| Surface | Category | Indicators named or implied by sources | Status |
| --- | --- | --- | --- |
| Student Progress | Skills | Skills started / completed | [CONFIRMED] S2 §4.5 |
| Student Progress | Progress by subject/topic | Progress per subject and topic | [CONFIRMED] S2 §4.5 |
| Student Progress | Score | SmartScore trend only if valid data exists | [CONFIRMED] S2 §4.5, formula open |
| Student Progress | Activity | Question count, answer accuracy, practice time | [CONFIRMED] S2 §4.5 |
| Student Progress | Recent | Recent activity, goal progress | [CONFIRMED] S2 §4.5 |
| Student Progress | Filters | Time range and subject filters (IXL cited as a model) | [CONFIRMED intent, benchmark reference] STU-016 |
| Teacher Analytics | Assignment/quiz | Completion summary of assignments and quizzes | [CONFIRMED] S1 §8.3 |
| Teacher Analytics | Student | Individual performance within authorised scope | [CONFIRMED] S1 §8.3 |
| Teacher Analytics | Content levels | Performance at subject/topic/skill level | [CONFIRMED] S1 §8.3 |
| Teacher Analytics | Metrics | SmartScore, accuracy, time — only with valid definitions | [CONFIRMED] S1 §8.3 |
| Teacher Analytics | Gaps | Students/skills needing support | [CONFIRMED intent, rule open] ANL-002 |
| Teacher Analytics | Action | Create a corrective assignment from the report | [CONFIRMED] S1 §8.3 |
| School/Parent | — | Different indicator sets on the same page archetype | [CONFIRMED intent] S2 §6.6 note |

Rule for design: until the registry is filled, charts cannot be specified. The layout can be: window selector → 3 headline indicators → breakdown → action.


### 20.3 SmartScore presentation model


| Aspect | Rule |
| --- | --- |
| Presence | Shown where the sources require it: Practice Session header, Skill rows, Progress, Teacher analytics (S1 §6, S2 §5.2, §6.6) |
| Value availability | Three states: numeric · "not enough data" · "not available" |
| Definition | Always available on demand: what it measures and what it does not |
| Comparison | Never compared across students by the system (no ranking, STU-019) |
| Precision | Do not render decimals or false precision; the formula is unapproved |
| Medals | 80 → bronze, 90 → silver, 100 → gold (STU-020). These are the only confirmed score thresholds in the product |


### 20.4 Recommendations architecture

[CONFIRMED] Recommendations are produced from practice history, assignments, and skill relations; they are not based on a diagnostic assessment (S2 §8.6, S1 §5.3); each carries a short understandable reason; if data is insufficient, a recommendation is not mandatory; 3–5 recommendations appear per subject on landing/dashboard; the recommender page shows more; the student may reject/hide (STU-012, STU-013, STU-014); default recommendations exist based on the time window and the curriculum plan.

[DESIGN RECOMMENDATION] Three-tier reason model — required so that reasons are always honest:


| Tier | Trigger | Example reason (student-facing, ≤1 sentence) | Notes |
| --- | --- | --- | --- |
| T-1 Assignment-linked | A skill appears in an active assignment | "Your teacher assigned this skill for Thursday." | Must not distort deadline facts |
| T-2 History-linked | Evidence from the student's own practice (e.g. not started, in progress, needs review) | "You started this skill but haven't finished it." | Never implies diagnosis beyond the recorded data |
| T-3 Prerequisite-linked | Prerequisite relation between skills (IA-003) | "This comes before dividing with remainder, which you will need next." | Prerequisites influence ordering, not gating |
| T-4 Curriculum default | No usable history; based on the time window and the curriculum plan (STU-013) | "This is the next skill in your grade's plan for this month." | The honest cold-start reason; must not pretend personalisation |

Rules:

- Every card shows exactly one reason, from exactly one tier, with a truthful statement.
- Forbidden reason language: "recommended by AI", "based on your level" (unless a diagnostic exists — it does not), "we think you'll like".
- Dismissal is allowed; persistence of dismissal is open (D-27).
- Never recommend a skill the student cannot access.
- Never present a completed skill as a new opportunity without labelling it as review (D-27).

### 20.5 Learning-gap logic

[OPEN] The system's gap-detection rule is undecided (ANL-002). Two constraints are confirmed and constrain any future rule:

1.  No unexplained labels. "Weak" or "at risk" must not appear without a stated basis (S2 §6.6).

2.  Content-curated alerts at MVP. The learning alerts on the teacher landing are prepared by the content team (TCH-003) — i.e. rule-based curation, not machine learning.

[DESIGN RECOMMENDATION] Until ANL-002 is answered, the teacher's analytics surface presents evidence (counts, denominators, windows) and lets the teacher form the judgement; any system-surfaced "needs attention" item must display its rule in one sentence ("fewer than half of students completed this skill before the deadline").


### 20.6 Analytics → action contract

Every analytics surface must satisfy:


| Requirement | Implementation |
| --- | --- |
| Insight is actionable | A primary "assign follow-up" action that opens the builder pre-filled |
| Context is carried | Class, selected students, and the skill under analysis are pre-filled |
| Return is possible | After publishing, the teacher can return to the same filtered report |
| No dead ends | A report with no data offers "assign practice" rather than nothing |
| Honest scope | The header states class + window + (where relevant) "assigned practice only" |


### 20.7 Gamification model


| Mechanic | Confirmed rules | Open points | Design constraints |
| --- | --- | --- | --- |
| Coins | Earned from streaks and from completed skills (STU-022); re-practising a completed skill adds no coins but time is still counted (STU-010); in-product currency only, no real money (S1 §2) | Earning rates, per-event amounts, caps (D-30) | Coins never gate learning; balances never imply money |
| Badges | Part of MVP (STU-004) | Catalogue, conditions (STU-020 partial) | Shown after the learning event |
| Goals | Part of MVP (STU-004); daily/weekly goal present on Home | How goals are set (auto vs student-chosen) — OPEN | A missed goal must not be punitive; no streak-loss threats |
| Medals | Bronze at SmartScore 80, silver at 90, gold at 100; separate medals/messages for streaks (STU-020) | Relationship to the "Mastered" status (D-06) | Personal only; no ranking (STU-019) |
| Streaks | Mentioned; coins derive from streaks (STU-022) | Policy for absence/rest days (BM-DU-002); broken-streak messaging | Informational only; no anxiety mechanics, no "don't lose it" pressure |
| Certificates | Downloadable/printable (STU-021) | Format, approval rule | Must reflect real achievement only |
| Avatars / customisation | Items purchasable with coins (S2 §5.7); display locations open (STU-024) | Where the avatar appears | Never a distraction inside a practice session |
| Honor Roll | Personal achievements, not a public ranking (STU-019) | Content of each entry | Explicitly non-competitive |
| Public ranking / leaderboard | Out of MVP (S1 §2) | — | No ranking component may be built |

[CONFIRMED] Motivation must complement learning, never replace it; public ranking and commercial pressure are explicitly excluded (S1 §14).


### 20.8 Anti-patterns for analytics, recommendations and rewards


| Anti-pattern | Why it is wrong for Naranj |
| --- | --- |
| Percentage without a denominator or window | Violates the confirmed interpretability requirement |
| "At risk" labels with no rule shown | Violates the non-judgmental requirement |
| A trend line from 2 data points | Violates data honesty |
| Recommendation without a reason, or an AI-flavoured reason | Explicitly forbidden |
| Coin animation interrupting feedback | Rewards must not displace learning |
| Streak loss warnings | Introduces pressure the sources warn against |
| Peer comparison anywhere in the student experience | Explicitly excluded |
| Rewards for incorrect answers or for time spent | Not supported and pedagogically harmful |


## 21. UX BEHAVIOUR SPECIFICATION

Each behaviour is specified with trigger → system response → user feedback → possible failure → recovery. This section is the contract for interaction design and front-end implementation.


### 21.1 Navigation


| Field | Specification |
| --- | --- |
| Trigger | User activates a navigation item, a row, a card, or a breadcrumb |
| System response | Route change; the shell persists; the page-level skeleton renders; scroll resets to top for new pages and is restored for back navigation |
| User feedback | Active nav state; page title; loading skeleton; URL reflects the state |
| Failure | Route not permitted → SYS-03; route missing → SYS-04; data failure → page-level error with retry |
| Recovery | Back always available except in focus modes (where exit replaces it); deep links resolve to a valid state or to a clear error |


### 21.2 Page transitions and focus


| Field | Specification |
| --- | --- |
| Trigger | Any route change; any drawer/modal open |
| System response | Focus moves to the page heading (or the drawer's heading); a skip-to-content link is available; background is inert when a modal is open |
| User feedback | Visible focus indication; announced page title for screen readers |
| Failure | Focus lost to body after a dynamic update → must be corrected by explicit focus management |
| Recovery | Escape closes overlays and returns focus to the invoking element |


### 21.3 Search


| Field | Specification |
| --- | --- |
| Trigger | Typing in a search field |
| System response | Debounced query (≥2 characters); results grouped by level; the current grade/subject scope respected; the query is reflected in the URL |
| User feedback | Result count; "searching" state; "no results" with the query and scope restated |
| Failure | Service error → explicit error (never an empty list); partial index → notice |
| Recovery | Clear query returns to the unsearched state with filters intact |


### 21.4 Filtering


| Field | Specification |
| --- | --- |
| Trigger | Applying/removing a filter |
| System response | Results update; the filter set is shown as removable chips; the URL reflects the state; selections in progress are preserved |
| User feedback | Result count; empty-state message naming the active filters |
| Failure | Filter yields zero results → "no results for these filters" + "clear filters" (distinct from "no content exists") |
| Recovery | One action clears all filters; individual chips are removable |


### 21.5 Sorting


| Field | Specification |
| --- | --- |
| Trigger | Selecting a sort option |
| System response | Re-order without a full page reload; sort state persists in the URL |
| User feedback | Sort indicator on the column/control; the default sort is named |
| Failure | Sorting an incomplete dataset must not imply completeness |
| Recovery | Reset to default sort is available |


### 21.6 Forms


| Field | Specification |
| --- | --- |
| Trigger | Field focus/blur; submit |
| System response | Validation on blur and on submit; inline, specific messages; submit blocked only with a stated reason |
| User feedback | Field-level error text; summary of errors at submit time; preserved values |
| Failure | Server validation differs from client → server message shown at the field |
| Recovery | Values never cleared on failure; the user can correct and resubmit |


### 21.7 Tables


| Field | Specification |
| --- | --- |
| Trigger | Load; sort; filter; row action; bulk select |
| System response | Sticky header; ≤6 columns; row expansion for detail; bulk action bar appears on selection |
| User feedback | Selection count; sort/filter state; pagination or incremental loading |
| Failure | Partial load → per-section retry; never render zeros as data |
| Recovery | Selection survives sorting/filtering; a failed bulk action reports exactly which rows failed |


### 21.8 Selection and multi-selection


| Field | Specification |
| --- | --- |
| Trigger | Checkbox/toggle; shift-select; select-all |
| System response | Immediate visual state; persistent counter; a summary tray for cross-screen selections |
| User feedback | Count + expandable list + clear action |
| Failure | Selecting beyond an (unconfirmed) cap → must not silently drop items |
| Recovery | Every selected item is individually removable; "clear all" with confirmation if the selection is large |


### 21.9 Confirmation dialogs


| Field | Specification |
| --- | --- |
| Trigger | Destructive or irreversible action (cancel assignment, remove student, publish, purchase) |
| System response | Modal naming the object and the consequence; cancel is the safe default |
| User feedback | Explicit consequence text (e.g. "recorded answers will be kept") |
| Failure | The action fails after confirmation → state that nothing changed |
| Recovery | Cancel returns to the exact prior state |
| Rule | No confirmation for reversible actions; no "are you sure" without a stated consequence |


### 21.10 Modals and drawers


| Field | Specification |
| --- | --- |
| Trigger | Preview, item detail, definition, picker |
| System response | One overlay at a time; the underlying context is preserved; ESC closes |
| User feedback | Focus trapped inside; clear close control; the overlay's purpose in its heading |
| Failure | Overlay content fails → the overlay remains with a retry, the underlying page is unaffected |
| Recovery | Closing returns focus to the trigger; on mobile, a drawer becomes a full-screen sheet with a back control |


### 21.11 Notifications


| Field | Specification |
| --- | --- |
| Trigger | System events (deadline, assignment published, results ready — event catalogue OPEN, D-23) |
| System response | Unread indicator in utilities; notification list with categories; deep link to the object |
| User feedback | Badge count; read/unread state; archive |
| Failure | Notification service failure must never block the primary flow |
| Recovery | Notifications are never the only place a deadline is visible (landing pages must carry it) |


### 21.12 Loading


| Field | Specification |
| --- | --- |
| Trigger | Any data fetch |
| System response | Skeletons matching the final layout; zone-level independence; repeat actions disabled |
| User feedback | Skeleton shapes (not spinners) for structured content; explicit progress for long operations (quiz generation, publish) |
| Failure | Timeout → error state with retry |
| Recovery | Retry re-fetches only the failed zone |


### 21.13 Empty states


| Field | Specification |
| --- | --- |
| Trigger | Zero results, zero data, or not-yet-created conditions |
| System response | Explain why it is empty + the next action. Distinguish: no data exists / no data for these filters / no permission / load failed |
| User feedback | One sentence of cause, one primary action |
| Failure | An empty state that appears because of an error is a defect |
| Recovery | The offered action must actually resolve the emptiness |


### 21.14 Errors


| Field | Specification |
| --- | --- |
| Trigger | Failed request, validation failure, permission failure, conflict |
| System response | Message stating what happened, what was saved, and what to do next |
| User feedback | Inline for local failures; page-level for blocking failures; never a bare error code |
| Failure | Cascading failure → the most relevant, actionable message wins |
| Recovery | A single recovery action (retry, go back, sign in again); support path where needed |


### 21.15 Offline behaviour


| Field | Specification |
| --- | --- |
| Trigger | Network loss detected |
| System response | Persistent banner; read-only browsing of already-loaded data; submissions blocked; confirmed progress retained |
| User feedback | Explicit distinction between saved and unsaved; a visible reconnection state |
| Failure | Reconnection partial → retry queued submissions with the same idempotency key |
| Recovery | On reconnect, reconcile; never silently overwrite server state |
| Scope | [TECHNICAL VALIDATION] Offline capability level (banner only vs cached reading) is an engineering decision (STATE-002) |


### 21.16 Autosave


| Field | Specification |
| --- | --- |
| Trigger | Field changes in builders/forms; answer submissions |
| System response | Debounced persistence; status surfaced |
| User feedback | "Saving…" → "Saved" only after server confirmation |
| Failure | Save failure → "Not saved" + retry; the user is never told it is saved when it is not |
| Recovery | Local draft retained where approved (D-07) |


### 21.17 Session recovery


| Field | Specification |
| --- | --- |
| Trigger | Return to an interrupted session; expired authentication |
| System response | Restore last confirmed state; state plainly what was and was not saved |
| User feedback | A one-line summary of restoration |
| Failure | Restoration unavailable → explain and offer to start over with an explicit loss statement |
| Recovery | SYS-02 provides re-authentication and returns the user to the same context |


### 21.18 Feedback (product feedback, not answer feedback)


| Field | Specification |
| --- | --- |
| Trigger | Completed action (published, saved, joined, purchased) |
| System response | Short confirmation + the relevant next action |
| User feedback | Inline or toast, never modal, never blocking |
| Failure | If confirmation cannot be obtained from the server, do not claim success |
| Recovery | The object's page shows the authoritative state |


### 21.19 Progress indicators


| Field | Specification |
| --- | --- |
| Trigger | Long-running or multi-step operations |
| System response | Step indicator for flows; determinate progress where measurable; otherwise an honest indeterminate state |
| User feedback | Current step + what remains |
| Failure | A stalled operation must time out into an error state |
| Recovery | Retry from the current step, not from the beginning |


### 21.20 Recommendations interaction


| Field | Specification |
| --- | --- |
| Trigger | Viewing a recommendation (on Home or the wall) |
| System response | Card with skill, reason, action; dismissal control |
| User feedback | Dismissal acknowledged; the list reflows |
| Failure | Reason unavailable → the card must not render (a reasonless recommendation is a defect) |
| Recovery | Dismissed items can be recovered from the full wall (OPEN: D-27) |


### 21.21 Rewards interaction


| Field | Specification |
| --- | --- |
| Trigger | Earning or spending (completion, purchase, equip) |
| System response | Server-side award/transaction; UI reflects the authoritative balance |
| User feedback | Post-event, non-blocking, secondary to the learning result |
| Failure | Transaction failure → explicit "no coins were deducted" |
| Recovery | Re-read balance; retry with idempotency |


### 21.22 Responsive interactions


| Field | Specification |
| --- | --- |
| Trigger | Viewport change; orientation change; touch vs pointer |
| System response | Layout re-composes; navigation adapts; tables become lists; drawers become sheets |
| User feedback | No state loss on resize; scroll position maintained where meaningful |
| Failure | Layout break at a supported width is a defect; horizontal scrolling of primary content is not allowed |
| Recovery | State is preserved across breakpoint changes |


## 22. SYSTEM STATES AND ERROR HANDLING


### 22.1 The product-wide state model

[CONFIRMED] The source defines the required states and their intent (S1 §11; S2 §9.1). This section converts them into a single model applied to every surface.


| State | Meaning | Required presentation | Never |
| --- | --- | --- | --- |
| Initial | Nothing requested yet | Idle, complete layout, no skeleton | A skeleton for a request that has not been made |
| Loading | Data/operation in progress | Skeletons matched to final layout; repeat actions disabled | Spinner-only screens for structured content |
| Empty | Request succeeded, no data | Cause + next action | Zeros presented as data |
| Success | Operation completed | Short confirmation + next action | A modal that must be dismissed |
| Error | Operation failed | What happened + what was saved + recovery | Raw error codes |
| Offline | Network unavailable | Persistent banner; unsaved declaration | Claiming saved state |
| Submitting | Mutation in flight | Control locked; in-flight indication | Double submission |
| Saved | Server confirmed | Textual confirmation | Optimistic checkmarks |
| Pending | Sent, not confirmed | "Not yet saved" | Presenting as saved |
| Permission denied | Not authorised | Generic message; no data disclosure; one way out | Leaking existence of data |
| Conflict | Concurrent change | Explain divergence; server authoritative | Silent overwrite |
| Expired session | Auth no longer valid | Re-authenticate and return to context | Losing confirmed work |
| Recovery | Restoring a prior state | What was restored / what was lost | Pretending nothing was lost |
| Completed | Flow finished | Result + next step | Dead end |


### 22.2 State matrix by surface


| Surface | Loading | Empty | Error | Special states |
| --- | --- | --- | --- | --- |
| Public landing | n/a (static) | n/a | n/a | — |
| Sign in | Submit in flight | n/a | Invalid credentials / disabled / rate-limited | Redirect-preserved |
| Student Home | Per-zone skeletons | 4 distinct empties (see STU-01) | Zone-level retry | Partial success (some zones) |
| Skill Library | Row skeletons | No content / no filter results / no access | Topic-level retry | Search error ≠ no results |
| Practice Session | Question skeleton | Content gap | Load / submit / evaluation failures | Offline, Pending, Saved, Recovery, Completed |
| Session summary | Result computing | Zero answers | Result unavailable | SummaryPending |
| Recommendations | Card skeletons | No data → defaults or omission | Omit block | Dismissed |
| Progress | Widget skeletons | Zero-state dashboard (valid) | Widget retry | Insufficient data per indicator |
| Rewards Store | Grid skeletons | Empty catalogue | Transaction failure | Insufficient coins, already owned, conflict |
| Teacher Home | Zone skeletons | No class / no assignment / no alerts | Zone retry | Partial success |
| Roster | Row skeletons | No students | Retry | Former members |
| Skill Library (teacher) | Row skeletons | No matches / no samples | Retry | Selection preserved |
| Assignment builder | Per-step save state | Blocked Next with reason | Publish failure, conflict | Draft (if approved) |
| Assignment tracking | Summary then rows | Nothing recorded yet | Retry | Former members, overdue |
| Quiz Generator | Generate in progress | Insufficient bank | Generation failure | Parameter impossibility |
| Analytics | Widget skeletons | Insufficient data (no charts) | Widget retry | Latency disclosure |
| Notifications | List skeleton | No notifications | Retry | Unread count |
| Focus modes (exit) | n/a | n/a | Persist failure on exit | Save declaration |


### 22.3 Error taxonomy for the practice session (the highest-risk surface)


| Error | Cause | User sees | Recovery |
| --- | --- | --- | --- |
| Question unfetchable | Network/service | "We couldn't load the next question." | Retry; if persistent, exit with confirmed state |
| Invalid input | Local validation | Specific reason next to the input | Correct and resubmit |
| Malformed answer (server) | Contract mismatch | "This answer isn't in a valid format." + format hint | Correct and resubmit (not counted as an incorrect answer) |
| Submission failed | Network | "Your answer wasn't saved." Input preserved | Retry with the same answer |
| Evaluation timeout | Server | "Still checking…" then failure | Retry evaluation without re-answering |
| Offline | Network loss | Banner + "not saved" | Reconnect and retry |
| Session expired | Auth | SYS-02 | Re-authenticate, return to the session |
| Session not resumable | Retention expired | "This practice can't be resumed." | Start the skill again; state the loss |
| Content changed mid-session | Content edit | "This skill's content was updated." | Continue with the current question set; explain |
| Unknown question type | Rendering | "This question can't be displayed." | Skip is not allowed silently; offer exit/support (OPEN D-34) |


### 22.4 Messaging rules (product-wide)


| Rule | Example |
| --- | --- |
| State what happened | "We couldn't publish the assignment." |
| State what is saved | "Your answers up to question 4 are saved." |
| State what to do next | "Try again, or come back from your home page." |
| Never blame the user | "That answer isn't complete yet" (not "invalid input") |
| Never expose internals | No HTTP codes, no stack traces, no internal IDs |
| Respect the age range | Short sentences, no jargon, no sarcasm |
| Respect the role | Student copy is encouraging; teacher copy is precise and consequential |


### 22.5 Session-expiry behaviour

[CONFIRMED] Session expiry must be handled clearly and securely, and confirmed practice answers must not be lost (S1 §11, §11.1).


| Situation | Behaviour |
| --- | --- |
| Expiry during browsing | SYS-02 with "return to where you were" |
| Expiry during a practice session | Re-authenticate; restore the last confirmed state; declare unsaved input |
| Expiry during the assignment builder | Re-authenticate; restore the builder if technically feasible, otherwise state clearly that the builder was lost and offer restart (TECHNICAL VALIDATION D-24) |
| Expiry during publish | The server state is authoritative; on return, the assignment list shows the true state — never offer a blind retry |
| Expiry during purchase | Query the transaction state before retrying (S1 §5.6 Transaction Error rule) |


### 22.6 Hardware, browser and environment failures


| Condition | Behaviour |
| --- | --- |
| Small viewport / orientation change | Layout adapts; no state loss |
| Slow network | Skeletons; submissions allowed but clearly marked in-flight |
| No network at session start | Read-only unlocked content; practice blocked with an explanation |
| Interrupted audio playback (media question) | Replay control; the question remains answerable where the design permits |
| Browser back during practice | Treated as an exit attempt with confirmation (DESIGN RECOMMENDATION) |
| Multiple tabs open | Last-write wins must not corrupt confirmed answers; conflict state where detected |
| Device sleep / resume | Session state revalidated on focus |


## 23. RESPONSIVE UX ARCHITECTURE


### 23.1 Priority statement

[CONFIRMED] The product is a responsive web app; laptop and tablet are the primary targets; mobile is supported but secondary. Not a native app (S1 §2, S2 §1.3).

[DESIGN RECOMMENDATION] Design order: laptop (1440/1280) → tablet (1024 landscape, 834 portrait) → mobile (390). The practice session and the assignment builder must be designed at tablet width before mobile, because tablet is a realistic classroom device and mobile is not.


### 23.2 Breakpoint proposal

[DESIGN RECOMMENDATION — not a technical specification] QA-002 asks for the minimum supported width and breakpoints; this is a proposal for validation, not a confirmed spec.


| Token | Range | Primary intent | Navigation | Content |
| --- | --- | --- | --- | --- |
| xs | 320–599 | Mobile (secondary) | Bottom bar (≤5) / single menu | Single column, 16 px gutters |
| sm | 600–767 | Large phone / small tablet portrait | Bottom bar or top bar | Single column, 24 px gutters |
| md | 768–1023 | Tablet portrait | Top bar + collapsible sections | Single column, optional 2-col for cards, 32 px gutters |
| lg | 1024–1279 | Tablet landscape / small laptop | Side nav (collapsed) or top bar | 2-column where useful; tables ≥4 columns |
| xl | 1280–1599 | Primary laptop | Side nav expanded | 2–3 columns; full tables; summary rails |
| 2xl | ≥1600 | Large laptop / projector | Side nav expanded | Max content width cap (avoid over-stretch) |


### 23.3 Layout behaviour by role


| Area | Laptop xl | Tablet md/lg | Mobile xs/sm |
| --- | --- | --- | --- |
| Global shell | Persistent side navigation + context bar | Top bar with menu, context bar below | Top bar (title + context) + bottom bar |
| Student Home | 2 columns (actions / support) | Single column, urgent card first | Single column, compact cards |
| Skill Library | Filter rail + list | Collapsible filters above list | Sticky search + list; filters in a sheet |
| Practice Session | Centred column, max ~720 px question width | Same, larger controls | Full-width, sticky submit, keyboard-aware |
| Progress / Analytics | Widgets in 2 columns | Stacked widgets | Single column list-first; charts become lists |
| Assignment builder | Content + persistent summary rail | Summary becomes sticky banner | Stepper with collapsed summary |
| Tables | Up to 6 columns | 4 columns + row expansion | Cards/list items |
| Modals | Centred modal / side drawer | Drawer | Full-screen sheet |


### 23.4 Navigation adaptation


| Width | Student | Teacher |
| --- | --- | --- |
| xl | Side navigation, ≤5 items, labels visible | Side navigation, ≤5 items + class switcher in the top context bar |
| lg | Side navigation collapsed to icons + tooltips, or top bar | Top bar + class switcher always visible |
| md | Top bar with a menu button + bottom bar for ≤4 most-used items | Top bar + class switcher; menu for the rest |
| xs/sm | Bottom bar with 4 items (Home, Library, Progress, Achievements) + menu for the rest | Top bar with menu; class switcher pinned; bottom bar optional |

Rule: the class switcher must never be hidden behind a menu on tablet — it is the teacher's primary context control (P-02).


### 23.5 Content density rules per width


| Element | xl | md/lg | xs/sm |
| --- | --- | --- | --- |
| Cards per row | 2–3 | 1–2 | 1 |
| Data points per card | 3 | 3 | 2 |
| Body text size | 16 px base | 16 px | 16 px (never below) |
| Question text | 20–24 px | same | 18–20 px |
| Table rows | 44–48 px | 48–56 px | list items 56–64 px |
| Gutter | 32 px | 24–32 px | 16 px |


### 23.6 Table adaptation

1.  Columns are prioritised, not deleted: the first 4 columns persist; the rest move to row expansion.

2.  The identity column (student or assignment) is sticky.

3.  Horizontal scroll is allowed only inside a table container, never for the page.

4.  On mobile, a table becomes a list of cards with label/value pairs — never a horizontally scrolling table of primary data.

5.  Bulk selection on mobile uses a selection mode with a persistent action bar.


### 23.7 Touch and pointer requirements


| Requirement | Value (recommendation pending A11Y confirmation) |
| --- | --- |
| Minimum touch target | 44×44 CSS px |
| Minimum spacing between targets | 8 px |
| Drag handles | ≥44 px with a visible affordance and a non-drag alternative |
| Hover-only affordances | Forbidden — every hover action must have a tap equivalent |
| Precision interactions (plotting, hotspot) | Provide a zoom/inspection mode and an alternative input |


### 23.8 Responsive practice-session specifics


| Element | xl | md/lg | xs/sm |
| --- | --- | --- | --- |
| Header | One row: skill · position · time · score · exit | One row, condensed | Two rows; exit always visible |
| Question media | Inline, scales to column | Inline | Full-width; pinch-zoom allowed; math zoom control |
| Answer area | Fits in the viewport with the prompt | May scroll; submit sticky at the bottom | Submit always reachable (sticky), prompt may scroll |
| Feedback | Below the answer area | Below | Inline expansion; scroll to the result |
| Keyboard | Physical keyboard expected | On-screen keyboard supported | Numeric/expression keyboard hints per type |

Rule: the submit control must never require scrolling to find on any width.


### 23.9 Responsive test viewport list

[DESIGN RECOMMENDATION] Minimum test matrix: 1440×900, 1280×800, 1024×768 (landscape), 834×1112 (portrait), 768×1024, 390×844, 360×640. Portrait and landscape tablet must both be tested for the practice session and the builder.


## 24. ACCESSIBILITY AND LOCALIZATION


### 24.1 Accessibility position

[CONFIRMED requirements] Keyboard operation of primary functions with a visible focus state; a non-drag alternative for drag interactions; correct and accessible labelling; contrast; touch target size validated on mobile; status not conveyed by colour alone (S1 §12).

[OPEN] The conformance target itself is unspecified — A11Y-003 asks whether WCAG 2.2 AA is the acceptance criterion.

[DESIGN RECOMMENDATION] Adopt WCAG 2.2 AA as the working target for design and QA, explicitly flagged as pending confirmation (D-36). Rationale: it is the only level named anywhere in the sources, and designing below it would guarantee rework. Risk if rejected: unknown; the alternative level is unstated.


### 24.2 Accessibility requirements by area


| Area | Requirement | Verification |
| --- | --- | --- |
| Structure | Semantic landmarks; one H1 per page; logical heading order | Manual + automated audit |
| Keyboard | All primary functions operable; visible focus; no traps (except intentional modal traps); Escape closes overlays | Keyboard-only pass per page |
| Question interactions | Per-family keyboard models (§17.9); drag alternatives mandatory | Keyboard-only pass per question family |
| Focus management | Focus moves to page/drawer heading on navigation; returns to trigger on close | Manual pass |
| Screen reader | Labels programmatically associated; state announcements (saved/not saved, correct/incorrect, selection counts) | SR pass with at least one desktop and one mobile SR |
| Contrast | Text and non-text contrasts per target level; feedback colours must also meet contrast on tinted backgrounds | Colour contrast audit |
| Non-colour status | Correct/incorrect/selected/disabled carry icon + text | Design review checklist |
| Touch | ≥44 px targets; adequate spacing | Device testing |
| Motion | No essential information conveyed by motion; respect prefers-reduced-motion | Manual pass |
| Time | No time limits in practice; if a quiz has a time limit, extension must be possible (A11Y-005 open) | Design review |
| Errors | Announced, associated with the field, with a text remedy | Manual pass |
| Zoom / reflow | 200% zoom usable; no loss of function; no two-dimensional scrolling of primary content | Browser testing |
| Media | Audio has visible controls and a replay policy; meaning-bearing images have descriptions | Manual pass |


### 24.3 Localization position


| Question | Status | Consequence |
| --- | --- | --- |
| Is the product bilingual? | [CONFIRMED] the product is decided to be bilingual (S2 §1.3) | Copy must be externalised from day one |
| Which languages? | [OPEN] A11Y-001 unanswered | No translation scope, no date format set can be finalised |
| Coverage of translation | [OPEN] | Cannot promise full coverage |
| Default direction | RTL is operative (S1 §12) | Layout, components, and icons must be built RTL-first |
| Second direction | LTR support required if the second language is Latin-script | Components must not hard-code direction |


### 24.4 RTL/LTR architecture rules

[CONFIRMED] RTL is not just text alignment: navigation, meaning, and component order must be reviewed (S1 §12).


| Rule | Detail |
| --- | --- |
| Directional properties only | Use logical properties (start/end, inline/block) — never left/right |
| Mirroring by meaning | Icons with directional meaning (back/forward, progress arrows) mirror; icons with inherent direction (play, clock, checkmark) do not |
| Numbers, dates, units, formulas | May keep their own independent direction; they must not be mirrored |
| Mixed-direction strings | Isolate embedded LTR runs (math, Latin technical terms, codes) so punctuation and parentheses do not reorder |
| Progress and steppers | Order follows reading direction; step numbers remain in the correct order |
| Tables | Column order mirrors; the identity column remains at the visual start |
| Charts | Axis direction must be decided deliberately per chart type; time axes follow reading direction |
| Forms | Label alignment and input direction follow the document direction; numeric inputs are direction-isolated |
| Navigation state must survive | A language/direction change must not lose form input, route, or practice state (S1 §12) |


### 24.5 Content localisation rules


| Element | Rule | Status |
| --- | --- | --- |
| Dates | Locale format; the deadline timezone in MVP is Iran time | [CONFIRMED] TCH-020 |
| Numbers/digits | Persian vs Latin digit display is a product decision that must be made per surface; input must accept both | [OPEN] D-35 |
| Decimal separator | Must be specified for input and display | [OPEN] D-35 |
| Time | 12/24-hour convention unconfirmed | [OPEN] D-37 |
| Week start | Unconfirmed (relevant to Timetable) | [OPEN] D-37 |
| Skill/topic titles | Content localisation ownership is undefined (content team implied) | [OPEN] D-38 |
| Copy tone | Student copy short, polite, hopeful; teacher copy operational and data-based | [CONFIRMED] S2 §9.2 |
| Status labels | Must be identical across all pages and both languages | [CONFIRMED] S2 §9.2 |


### 24.6 Accessibility acceptance criteria (design-level)

1.  Every P0 flow can be completed using only the keyboard.

2.  Every question family passes a keyboard-only and screen-reader pass before its component is accepted.

3.  No status is communicated by colour alone anywhere in the product.

4.  The practice session has no time limit and no motion-dependent information.

5.  Touch targets meet the minimum on mobile for every primary action.

6.  Direction changes (RTL↔LTR) do not alter, reorder, or break mathematical content.


## 25. MATHEMATICS UX


### 25.1 Why this section exists

[CONFIRMED] MVP content is mathematics (S1 §2); the brief requires that in the mathematical area, expressions render so that operator order and parentheses do not break down, that numeric input defines Persian-digit and decimal behaviour, and that keyboard focus and primary functions are clear (S1 §12). This is the most defect-prone area of an RTL maths product.


### 25.2 Display of mathematical expressions


| Requirement | Rule |
| --- | --- |
| Direction isolation | Each expression is rendered as an isolated LTR run inside RTL text; surrounding punctuation stays in the document direction |
| Operator order | Addition/subtraction/multiplication/division and comparison operators must not visually reorder |
| Parentheses | Bracket direction never mirrors; pairing must always read correctly |
| Fractions | Rendered as a stacked fraction with correct numerator/denominator placement, not mirrored |
| Mixed text + math | "حل کن: 3/4 + 1/2" must keep the math intact inside the sentence |
| Superscripts/subscripts | Exponents render in LTR order within the expression |
| Units | Units follow the value with the correct locale separator |
| Line breaks | Expressions must not break at an operator in a way that changes meaning |
| Scaling | Math must remain legible at 200% zoom and on mobile (allow horizontal scroll inside the expression container, never the page) |

[TECHNICAL VALIDATION] The rendering approach (server-rendered math, MathML, or a JS renderer) affects copy/paste behaviour, screen-reader output, and load performance — all three must be evaluated before component design.


### 25.3 Numeric and expression input


| Requirement | Rule | Status |
| --- | --- | --- |
| Digit input | Accept both Persian and Latin digits where the answer is numeric | [CONFIRMED requirement] S1 §12; specific acceptance rule [OPEN] D-35 |
| Decimal separator | Accept both ٫/, and . unless the question constrains it | [CONFIRMED principle: equivalent forms accepted (PRA-002)] |
| Keyboard | On tablet/mobile, offer the numeric keyboard for numeric answers; expression input must not require special characters to be discoverable by trial | [DESIGN RECOMMENDATION] |
| Paste | Paste must be permitted unless a question type forbids it (S1 §6.2 lists paste as an input contract field) | [CONFIRMED as a contract field] |
| Character normalisation | Arabic/Persian letter and digit variants must normalise before comparison | [TECHNICAL VALIDATION] |
| Units | If a unit is required, either pre-fill it or state the requirement in the prompt | [DESIGN RECOMMENDATION] |
| Equivalent answers | 1/2, 0,5, 0.5, 50% are equivalent unless the question states otherwise | [CONFIRMED] PRA-002 |
| Simplification | If a simplified fraction is required, the prompt must say so explicitly | [CONFIRMED inference from PRA-002's conditional clause] |
| Negative numbers, signs | The minus sign must be typeable and must not be confused with a dash | [DESIGN RECOMMENDATION] |


### 25.4 Diagrams and visual maths


| Requirement | Rule |
| --- | --- |
| Diagrams | Must have an accessible description; the question must be answerable without relying on colour discrimination |
| Coordinate/grid interactions | Must have a keyboard alternative and a precision aid |
| Measurement/geometry | Target sizes must meet touch minimums; labels must not overlap at mobile widths |
| Models/manipulatives (e.g. place-value blocks) | [BENCHMARK EVIDENCE] IXL uses place-value models in incorrect-answer explanations; adopting visual models is a design decision, not a requirement (see BM-IXL evidence in S1 §13.4) |


### 25.5 Answer validation requirements for mathematics


| Requirement | Rule |
| --- | --- |
| Correctness is server-side | Client validation never decides correctness |
| Equivalence first | The contract accepts mathematically equivalent forms by default |
| Explicit constraints | When a form is required, the prompt states it, and the validator enforces only what the prompt states |
| Tolerance | Where decimals are involved, tolerance must be specified per question type |
| Order sensitivity | Must be explicit for multi-part answers |
| Partial correctness | [OPEN] whether partially correct answers can exist for multi-part questions (needed for feedback design) — D-34 |
| False negative prevention | Every type requires a test set of valid alternative answers before acceptance; a false "incorrect" on a correct answer is the most damaging defect in the product |


### 25.6 Maths UX acceptance criteria

1.  In an RTL interface, a rendered expression preserves operator order and parentheses, verified on three representative expressions per grade.

2.  A numeric answer submitted with Persian digits is evaluated identically to the same answer with Latin digits (pending D-35 confirming this rule).

3.  An equivalent fraction/decimal/percent answer is accepted unless the prompt restricts the form.

4.  Math content is legible at 200% zoom and at 360 px width without page-level horizontal scrolling.

5.  No mathematical content is conveyed by colour alone.

6.  A screen reader announces the expression in a comprehensible order.


## 26. PRIVACY AND DATA BOUNDARIES


### 26.1 Confirmed boundaries


| Boundary | Rule | Source |
| --- | --- | --- |
| Student data visibility | A student sees only their own reports and assets | [CONFIRMED] S2 §8.1 |
| Teacher data visibility | A teacher sees only authorised class/student reports | [CONFIRMED] S2 §8.1 |
| Recipient authorisation | A teacher may only select authorised recipients | [CONFIRMED] S1 §16.2 |
| Permission denied | Show a suitable message without disclosing data | [CONFIRMED] S1 §11 |
| Parent access level | Data level authorised by the parent–child link | [OPEN] PAR-003 |
| Admin individual data access | Requires permission and audit | [OPEN] ADM-004 |
| Answer-level logs | Whether teachers/parents see per-question answers is undecided | [OPEN] ANL-003 / BM-IXL-003 |
| AI tutor | Not in scope; any future assistant requires data minimisation, conversation retention policy, monitoring, teacher oversight | [OUT OF CURRENT PRIORITY] S1 §13.1 |
| Profile data ownership | Which fields the school locks vs the user edits | [OPEN] SYS-005/006 |
| Account deletion/suspension effect on learning data | Undecided | [OPEN] SYS-007 |
| Audit trail | Required for changes to class/account/assignment/permission (open question STATE-005) | [OPEN] |


### 26.2 UX-level privacy requirements

1.  Scope is always stated. Every analytics surface names whose data is shown and in what window.

2.  No cross-student comparison in any student-facing surface (no ranking, no peer bars).

3.  No data disclosure on denial. SYS-03 must not confirm whether a resource exists.

4.  Minimum necessary display. Student names on teacher surfaces are shown to the extent needed for the task; no additional identifiers without a confirmed need.

5.  Children's data. The audience is 9–15; no social features, no public profiles, no free-text sharing surfaces exist, which minimises risk by design.

6.  Parent surfaces are read-only until confirmed otherwise (PAR-004).

7.  Consent and relationship verification for parent–child links is a product + legal decision (PAR-002), not a UX one — but the UI must not create a link without an approval step.


### 26.3 Data-boundary questions that block design


| Question | Blocks |
| --- | --- |
| What may a parent see? | The entire parent surface |
| Can a teacher see per-question answers? | Student analytics detail level (TCH-19) |
| Is individual-data access by an admin audited, and is the audit visible? | ADM-04 design |
| Which profile fields are school-locked? | Profile/settings design (STU-13, TCH-21) |
| What happens to learning records when a student leaves a class or the school? | Aggregate semantics (TCH-12) and possible "former member" surfaces |


## 27. DESIGN ROADMAP


### 27.1 Sequencing logic

[DESIGN RECOMMENDATION] The source sets the design order by P0/P1/P2 (SCP-002 confirms priority governs design order). This roadmap respects that order and adds the two dependencies the sources make unavoidable: the workbook-derived interaction inventory and per-type component mapping and the metric definitions (D-11). Two workstreams therefore run in parallel with the page design: question interaction specification and indicator definition.


### 27.2 Phase 1 — Product UX Architecture (this document)


| Aspect | Detail |
| --- | --- |
| Objectives | Establish product definition, roles, permissions, IA, sitemap, page inventory, principles, flows, session and question architecture, states, responsive and accessibility architecture, decision register |
| Deliverables | This document; sitemaps; page inventory; 44 flows; decision register; Mermaid diagram set |
| Dependencies | Source documents (obtained); question workbook (received; transcription completed in v2.1) |
| Completion criteria | Product team has reviewed the conflict register and closed or accepted every P0-blocking decision (D-01…D-10, D-16, D-22) |


### 27.3 Phase 2 — Low-fidelity UX


| Aspect | Detail |
| --- | --- |
| Objectives | Turn the architecture into wireframes for P0 pages and states |
| Deliverables | Wireframes: PUB-02, STU-01, STU-02, STU-04 (shell + 3 highest-frequency question families in low fidelity), STU-05, TCH-01, TCH-04, TCH-07, TCH-08, TCH-09, TCH-10/11, TCH-12, TCH-18, TCH-19; shared state kit (loading/empty/error/permission/offline/pending-saved); navigation models for both roles |
| Dependencies | Phase 1 sign-off; question families mapped (at least the three highest-frequency types) |
| Completion criteria | (a) A complete walkthrough of the student loop and the teacher loop is possible using only wireframes; (b) every P0 page has all its states drawn; (c) no page exceeds the density budget in §8.7 |


### 27.4 Phase 3 — Interaction design


| Aspect | Detail |
| --- | --- |
| Objectives | Specify behaviour, not just layout |
| Deliverables | Interaction specs per flow (F-S-01…F-S-21, F-T-01…F-T-23); question-family interaction specs (§17.5 template filled for the supplied types); validation and error copy; responsive behaviour per breakpoint; keyboard maps; recovery behaviours |
| Dependencies | Per-type answer contracts with the content team; D-05 status vocabulary |
| Completion criteria | A front-end engineer can implement a page without asking a behavioural question; every flow has documented failure and recovery paths |


### 27.5 Phase 4 — Design system foundation


| Aspect | Detail |
| --- | --- |
| Objectives | Define tokens and component contracts after behaviour is settled |
| Deliverables | Design tokens (colour semantics incl. non-colour-dependent status, typography scale supporting RTL + math, spacing, radii, elevation, motion with reduced-motion variants); component inventory derived from this document (shell, cards, tables, drawers, status chips, selection tray, feedback panel, score slot, save indicator, empty/error states); RTL/LTR token rules; density tokens per breakpoint |
| Dependencies | Phase 3; D-36 (accessibility target) |
| Completion criteria | Every component used in Phase 5 exists with defined states; contrast verified; RTL verified |
| Note | [CONFIRMED constraint] A design system is explicitly out of scope for the current phase (§22 of the engagement brief); this phase is planned, not started |


### 27.6 Phase 5 — High-fidelity prototype


| Aspect | Detail |
| --- | --- |
| Objectives | Produce a validated, testable high-fidelity experience for the two primary loops |
| Deliverables | Student: Home → practice (3 question families) → feedback → summary → progress. Teacher: Home → library → preview → builder → review → publish → tracking → analytics → follow-up. Prototype includes realistic Persian copy and RTL behaviour |
| Dependencies | Phase 4; content samples; defined indicators |
| Completion criteria | Prototype covers the complete P0 loop for both roles, on laptop and tablet |


### 27.7 Phase 6 — Validation


| Aspect | Detail |
| --- | --- |
| Objectives | Prove the architecture works for real students and teachers |
| Deliverables | Usability test plan and report; task success, time on task, error rate; accessibility audit (keyboard + screen reader + contrast); responsive test across the §23.9 viewport list; decision log update |
| Dependencies | Phase 5 prototype; recruited participants in the 9–15 band (with consent) and teachers |
| Completion criteria | Task success targets defined and met or exceeded for the core tasks (§27.8); no severity-1 accessibility defects; no breaks at the tested viewports |


### 27.8 Core validation tasks


| # | Task | Role | Success criterion (to confirm with the product team) |
| --- | --- | --- | --- |
| T1 | From sign-in, start the assignment that is due soonest | Student | Reaches the first question in ≤3 interactions; no wrong assignment started |
| T2 | Find a specific skill by name in the library | Student | Finds and starts within 60 s without help |
| T3 | Answer, read the feedback, and explain what the correct method was | Student | Completes the cycle; can articulate the explanation |
| T4 | Leave mid-skill and resume without losing answers | Student | Resumes with no lost confirmed answer; correctly states what was saved |
| T5 | Identify progress for one topic | Student | Correctly reads the indicator and its window |
| T6 | Find a skill, preview it, and assign it to a whole class with a deadline | Teacher | Publishes with correct class, skills, and deadline; no wrong-scope publication |
| T7 | Find the students who have not completed an assignment and assign a follow-up | Teacher | Reaches tracking, identifies, and publishes a follow-up without leaving the context |
| T8 | Generate a quiz and preview it before publishing | Teacher | Completes without encountering an unapproved parameter; understands an insufficiency message |
| T9 | Keyboard-only completion of one question from each tested family | Student | Completes without a pointer |
| T10 | Locate the active class and switch it, then act | Teacher | Names the active class correctly after switching |


### 27.9 Out-of-sequence work that can start immediately


| Work | Why it can start now |
| --- | --- |
| Question interaction inventory and component mapping (§17.9 / Appendix A) | Independent of page design; unblocks Phase 3 |
| Indicator definition workshops (§20.1) | Independent of layout; required before any chart |
| Status vocabulary decision (D-05) | Blocks consistency across three surfaces; cheap to decide |
| Copy inventory (Persian) for states and feedback | Required for Phase 2 fidelity and for the tone rules |
| Accessibility target confirmation (D-36) | Changes token and component decisions |


## 28. ACCEPTANCE CRITERIA


### 28.1 Page-level acceptance (applies to every page)

A page is accepted when:

1.  It states one primary action, and that action is the visually dominant element.

2.  It fits one of the composition templates in §8.4.

3.  It declares its entry and exit points, and both exist.

4.  All applicable states from §22 are designed: loading, empty, error, permission, plus its special states.

5.  The empty state states a cause and offers an action that resolves it.

6.  Errors state what happened, what was saved, and what to do next.

7.  It respects the density budget in §8.7.

8.  It is operable by keyboard and has a defined focus order.

9.  It has no colour-only meaning.

10.  It has a defined layout at each proposed breakpoint, with no page-level horizontal scroll.

11.  All numbers displayed have a definition, a window and a denominator (or are counts).

12.  Its copy follows the role tone rules (S2 §9.2) and matches the status vocabulary.


### 28.2 Flow-level acceptance

A flow is accepted when it has: an ID; a named actor and permission; an entry point; preconditions; a step-by-step main path; at least one decision point with all branches; at least one failure path with recovery; a defined completion state; and a traceable list of pages. (These are the source's own QA specification fields — S1 §16.)


### 28.3 Practice Session acceptance

Reproducing and extending the source's criteria (S1 §16.1):

1.  The student can answer without selecting a role or leaving the flow.

2.  Submission is validated against the question contract; duplicate submission is impossible.

3.  Correct/incorrect feedback includes a valid explanation when the content provides one, and the correct answer is always shown.

4.  pending and saved are always distinguishable.

5.  Exiting and returning restores the last confirmed answer.

6.  An unsaved answer is never presented as saved, including offline.

7.  In RTL, mathematical expressions and numeric input keep correct order.

8.  Primary actions are operable by keyboard and touch.

9.  [Added] No question type causes a layout jump in the session shell.

10.  [Added] Feedback never auto-advances.

11.  [Added] Every drag interaction has a keyboard alternative.

12.  [Added] The elapsed timer never becomes a countdown.


### 28.4 Assignment acceptance

Reproducing and extending the source's criteria (S1 §16.2):

1.  The teacher can only select authorised recipients.

2.  Skills come from existing content; there is no authoring control anywhere in the flow.

3.  Deadline and instructions follow the confirmed rules (Iran time; instructions pending D-09).

4.  The review step shows recipients, skills and deadline before publishing.

5.  Publishing is confirmed by the server, and a duplicate assignment is not created by a repeated request.

6.  [Added] The duplicate warning is non-blocking and explains what overlaps.

7.  [Added] Editing after students start states that recorded answers are unaffected.

8.  [Added] Removing a student leaves past records intact and excludes them from class aggregates from the removal date.


### 28.5 Analytics acceptance

1.  Every indicator displays name, definition, window and (where applicable) denominator.

2.  No indicator is displayed when the sample is below its defined minimum; instead an explicit "not enough data" state appears.

3.  No student-level judgement label appears without a stated rule.

4.  Each analytics page offers an action that carries the analysis context.

5.  Charts are never rendered empty; the insufficient-data state replaces them.

6.  Assigned practice and free practice are distinguishable wherever the metric depends on them.


### 28.6 Accessibility acceptance

Per §24.6, plus: a documented keyboard map per page; a screen-reader pass per P0 flow; contrast verification; and a documented statement of the accessibility target once D-36 is decided.


### 28.7 Definition of ready for wireframing

A page may enter wireframing only when: its entry point exists in the sitemap; its primary action is identified; its data dependencies are either available or stubbed with a named decision; and it has no unresolved structural decision (content decisions may remain open).


### 28.8 Definition of ready for high-fidelity design

A page may enter high fidelity only when: its interaction spec exists (Phase 3); its components exist in the design system (Phase 4); its copy is written; and its states are all specified.


## 29. OPEN QUESTIONS AND DECISION REGISTER


### 29.1 How to use this register

Every entry is traceable to a source question ID where one exists. Priority meaning: P0-blocking = design cannot proceed correctly without it; P1 = required before high fidelity; P2 = can be resolved during or after first-release design. Owner is a role, per the source's implied responsibilities.


### 29.2 Product decisions


| ID | Question and known information | UX impact (pages · flows) | Owner · Priority | Suggested resolution |
| --- | --- | --- | --- | --- |
| D-01 | Product identity: Is "روشنا / Rowshana" (S2) the same product as "نارنج / Naranj" (S1/S3) under an earlier name, a sister product, or an obsolete artefact? Known: identical taxonomy, page sets, flows, and benchmark framing. | All surfaces (branding, copy) · all flows | Product Owner · P2 | One-line confirmation; if sister product, separate the source sets |
| D-02 | Parent and School Admin in the first release? PRD-003 says they may be excluded from the Dey release for time; SCP-003 says they have independent dashboards in MVP. | Parent/admin skeletons · none of P0 | Product Owner · P0-blocking | Direct decision; if included, commission a scoped discovery (PAR-002/003/004, ADM-002/003/004) |
| D-04 | Account provisioning and sign-up: who creates accounts, and is there any self-service sign-up? Brief says school-issued credentials; AUTH-002 was deferred to a verbal answer. | PUB-01, PUB-02 · F-S-01, F-T-01 | Product Owner · P0-blocking (for auth design) | Written confirmation; if no sign-up, state it in the public copy |
| D-06 | Completion and mastery semantics: medals at 80/90/100 (STU-020); session ends at 100 or on exit (PRA-007); "Mastered" status exists in two vocabularies. What defines a completed skill, and what defines mastered? | STU-01, STU-04, STU-05, STU-07, TCH-12, TCH-19 · F-S-18, F-T-15 | Product + content · P0-blocking | Workshop with the content team; produce one definition table |
| D-06b | Completed-assignment presentation: after completion, does the card remain, change state, or disappear? Re-practice is allowed (STU-010) but the card state is undefined. | STU-01 · F-S-06 | Product · P1 | Decide one of three states; specify the copy |
| D-07 | Teacher navigation and creation placement: are quizzes and the timetable top-level destinations (as in S2's seven-item model) or contextual actions (proposed five-item model)? Also: are assignment drafts supported? | TCH-01, TCH-09, TCH-10, TCH-13 · F-T-10, F-T-16 | Product + UX · P1 | Navigation review with 5 users; draft decision by scope |
| D-08 | Teacher Home priority: which wins above the fold — reactive items (deadlines, alerts) or planning items (upcoming sessions)? S1 §7.1 orders content but not the priority between these intents. | TCH-01 · F-T-02 | Product · P1 | Decide with 2–3 pilot teachers |
| D-09 | Assignment instructions: is the short instruction field supported in the first release, and where does the student read it, given direct entry into practice (STU-005)? | TCH-10, TCH-11, STU-04 · F-T-10, F-S-07 | Product · P1 | Decide support + placement (recommendation: in-session one-line strip) |
| D-13 | Rewards Store in the first release: P2 design priority, yet STU-025 says including it is appropriate if designs are ready. | STU-10, STU-11 · F-S-21 | Product Owner · P1 | Decide release inclusion; either way, no real-money wording |
| D-22 | Quiz scope (highest-risk product gap): parameter set and limits (QUIZ-001), selection strategy (QUIZ-002), insufficiency handling (QUIZ-003), preview removal (QUIZ-004), attempts/time/order/results (QUIZ-005), the student quiz-taking experience (QUIZ-006), and post-publish editing (QUIZ-007). | TCH-13, TCH-14, TCH-15, plus an undefined student surface · F-T-16…F-T-18 | Product Owner + content · P0-blocking if quizzes ship in the first release | Written specification of the quiz object and its student experience, or explicit deferral of student-facing quizzes |
| D-23 | Notifications: event catalogue, channels (in-app/email/SMS/push), who may create notifications, and whether a deadline or a change notifies students (SYS-001…SYS-006 unanswered). | SYS-01, STU-01, TCH-01, TCH-12 · assignment and deadline flows | Product + engineering · P1 | Decide a minimal in-app catalogue first; defer push/SMS |
| D-31 | Student-side assignment semantics: is an overdue assignment still startable? How is a multi-skill assignment entered (which skill first)? Does a partial session count toward completion? | STU-01, STU-04 · F-S-06, F-S-07 | Product · P0-blocking (for Home design) | Decide the three rules; they determine the card and session entry |
| D-34 | Question-behaviour gaps: does skip exist (mentioned only in PRA-010)? Can a multi-part question be partially correct? Is a scratchpad/work area intended? What happens on an unknown question type? | STU-04 · F-S-12 | Product + content · P1 | Confirm with the content team alongside the question inventory |


### 29.3 UX decisions


| ID | Question and known information | UX impact | Owner · Priority | Suggested resolution |
| --- | --- | --- | --- | --- |
| D-03 | Multi-role routing: accounts can hold multiple roles (SCP-004), but sign-in has no role picker and S2 says dual-role is "not yet defined". What is the deterministic rule? | PUB-02, all landings · F-S-01, F-T-01 | Product + tech · P0-blocking | Decide: last-used context, or a single "home" with a context switch in utilities |
| D-25 | Search scope: does Library search span all grades or respect the selected grade context? (IA-005 confirms searching titles of skill/subtopic/topic in each grade.) | STU-02, TCH-07 · F-S-10 | Product + UX · P1 | Decide; recommend grade-scoped search with an explicit "search all grades" escape |
| D-27 | Recommendation lifecycle: does a dismissed recommendation stay dismissed, for how long, and how is a completed skill presented if it is recommended again? (STU-014 confirms dismissal is allowed; persistence is unstated.) | STU-01, STU-06 · F-S-11 | Product + UX · P1 | Decide persistence window + completed-skill presentation |
| D-05 | Status vocabulary: two overlapping scales exist (S1 skill statuses vs TCH-019 stages). Adopt the three-axis proposal in §18.4? | STU-01, STU-02, STU-07, TCH-09, TCH-12, TCH-18, TCH-19, STU-08 · F-S-06/09/19, F-T-10/15/19 | Product + content · P0-blocking | Decide the axes and publish a status glossary as a design artefact |
| D-19 | Student analytics indicator set (STU-015 "not yet decided"): which indicators are authoritative on the student dashboard, with what windows? Dashboard must exist with zeros (STU-018). | STU-07, STU-01 · F-S-19 | Product + data · P1 | Indicator workshop using the §20.1 metadata schema |
| D-29 | Hint behaviour: is the hint single-step or progressive? Is there a hint limit? Is the first-run hint once per account or per device? Is "answered with help" stored separately (SYN-002)? | STU-04 · F-S-15 | Product + content · P1 | Content-team ruling; store hint events separately regardless |
| D-33 | Preview content: does the teacher preview include answers and explanations, or only question stems (TCH-006 says "a few sample questions")? | TCH-08 · F-T-08 | Product + content · P1 | Recommendation: include at least one full answer + explanation |
| D-40 | Student skill preview: is there a student-facing skill preview/pre-description, or only a row with a short description? | STU-03, STU-02 · F-S-09 | Product · P2 | Decide existence; if not, specify the library row's description |
| D-39 | Avatar display: where does the student's avatar appear (STU-024 deferred to verbal)? | STU-01, STU-08, STU-10 | Product + UX · P2 | Decide 1–2 surfaces maximum; never inside a practice session |


### 29.4 Educational and content decisions


| ID | Question and known information | UX impact | Owner · Priority | Suggested resolution |
| --- | --- | --- | --- | --- |
| D-16 | Question-type inventory and per-type answer contracts: the workbook has been received and transcribed; the product side retains ownership of MVP inclusion and official answer contracts (PRA-001). | STU-04 and every answer component · F-S-12 · §17 | Product Owner · P0-blocking for Phase 3 | Supply the workbook; fill the §17.5 template |
| D-12 | Skill content changes: skills are not versioned (IA-004), but what happens to historical assignment data if a skill's questions change? | TCH-12, TCH-19, STU-07 | Product + content + tech · P1 | Define an immutability rule for recorded results |
| D-30 | Coin earning rules: rates and events (STU-022 names streaks and completed skills; STU-010 says re-practice earns none). | STU-01, STU-08, STU-10 · F-S-21 | Product + content · P2 | Define an earning table; display it in the store |
| D-38 | Content ownership and publishing workflow: who owns the question bank and its release cycle (SCP-005)? Who curates learning alerts (TCH-003)? Who owns content localisation? | Content readiness for all practice surfaces; alert wording on TCH-01 | Product Owner · P1 | Define the content team's responsibilities and the publication process |
| D-45 | Mastery/gap rule: the rule that turns evidence into a "needs support" signal (ANL-002), and whether any automated gap detection exists at MVP (TCH-003 suggests curated alerts). | TCH-18, TCH-20 · F-T-19, F-T-21 | Product + content · P1 | Start with curated rules; publish each rule's wording in the UI |


### 29.5 Technical decisions


| ID | Question and known information | UX impact | Owner · Priority | Suggested resolution |
| --- | --- | --- | --- | --- |
| D-14 | Class code rules and abuse limits: length, character set, expiry, attempt limits, reuse, invalidation; plus rate limiting on auth and recovery. | STU-12, TCH-06, PUB-02, PUB-03 · F-S-04, F-A-04 | Engineering (AUT-004) · P1 | Written policy; then error copy |
| D-15 | Recovery identity verification: how identity is verified for email vs SMS reset (AUT-005 specifies channels only). | PUB-03, PUB-04 · F-S-03 | Engineering + security · P1 | Define; then design the step |
| D-21 | Device and session policy: remember-me, shared classroom devices, sign-out behaviour, concurrent sessions (AUTH-008 deferred to engineering). | PUB-02, all shells | Engineering + product · P1 | Decide; affects the sign-in screen and session duration |
| D-24 | Session recovery fidelity and retention: how long a session stays resumable (STATE-002), what is stored locally, and whether the server or local copy wins in a conflict (STATE-003), and whether in-flight builder state survives expiry. | STU-04, TCH-10, SYS-02 · F-S-08, F-S-17, F-T-10 | Engineering · P0-blocking (it defines what "saved" means) | Technical spec; then align copy with it exactly |
| D-26 | Routing and authorisation: is class context in the URL or the session? How do deep links behave after expiry? What is audited? | All teacher pages · F-T-03 | Engineering · P1 | Technical decision + a deep-link behaviour table |
| D-32 | Question ordering: are practice questions ordered, randomised, or adaptive? (PRA-001 assigns inventory ownership to the product side; ordering is not stated.) | STU-04 · F-S-12 | Product + content + engineering · P1 | Decide; affects retry consistency and analytics |
| D-35 | Numeric and text conventions: Persian vs Latin digits on screen, decimal separators, unit entry, and input normalisation for Arabic/Persian character variants. | All numeric answers, deadlines, scores · F-S-12, §25 | Product + engineering + content · P0-blocking for correctness | Written convention + a test corpus of equivalent answers |
| D-36 | Accessibility target: is WCAG 2.2 AA the acceptance criterion (A11Y-003)? | Tokens, components, QA | Product + design · P1 | Confirm AA; publish it in the design system |
| D-37 | Locale conventions: 12/24-hour time, week start (affects Timetable), date formats. | TCH-16, deadlines everywhere | Product + engineering · P2 | Follow the default locale convention; document it |
| D-47 | Active-time definition: does the session timer measure active time or page-open time (PRA-006)? This determines the timer label and any time-based indicator. | STU-04, STU-07, TCH-19 · F-S-12, F-S-19 | Engineering + data · P1 | Decide; then fix the label copy ("time in session" vs "practice time") |
| D-41 | Offline capability level: banner-only, or cached read-only content? What may be stored locally for a minor's account (STATE-002)? | STU-04, all shells | Engineering + security · P1 | Decide with privacy review |
| D-42 | Analytics latency and refresh: real-time vs delayed, and how latency is disclosed (ANL-006). | TCH-18, TCH-19, STU-07 | Data · P1 | Define and display the "last updated" rule |


### 29.6 Data, analytics and permission decisions


| ID | Question and known information | UX impact | Owner · Priority | Suggested resolution |
| --- | --- | --- | --- | --- |
| D-11 | Metric definitions: every indicator's numerator, denominator, window and minimum sample (ANL-001, S1 §14). SmartScore's formula and behaviour (BM-IXL-002, PRA-010). | STU-04, STU-07, TCH-18, TCH-19, TCH-20 · all analytics flows | Product + data + content · P0-blocking for analytics | Definition workshop; produce the indicator registry |
| D-20 | Answer-level visibility: may a teacher see per-question answers and logs (ANL-003, BM-IXL-003)? | TCH-19 · F-T-20 | Product + privacy · P1 | Decide; if yes, define the aggregation and audit rules |
| D-17 | Parent data visibility: which data a parent may see and what is confidential (PAR-003); read-only vs change rights (PAR-004); how the link is created and approved (PAR-002). | All parent surfaces | Product + privacy · P1 (P0 if D-02 includes parents) | Scoped discovery; privacy review |
| D-18 | School Admin operational scope: permitted operations on users/classes/teachers (ADM-002), school-level indicators (ADM-003), individual-data access and audit (ADM-004). | All admin surfaces | Product + privacy · P1 (P0 if D-02 includes admins) | Scoped discovery |
| D-10 | Primary vs secondary teacher access delta: the difference is confirmed to exist but its content is undefined (TCH-013). | TCH-03, TCH-04, TCH-12, TCH-18 · F-T-04, F-T-15 | Product · P0-blocking (drives permission states everywhere) | Decision matrix by capability |
| D-28 | Profile editability: which fields users may edit (SYS-005) and which are school-locked (SYS-006). | STU-13, TCH-21 | Product + privacy · P1 | Field-by-field table |
| D-43 | Student multi-class membership: can a student belong to more than one class? (Implied possible by TCH-015; not stated.) | STU-12, TCH-04, analytics scoping | Product · P1 | Decide; affects membership model and aggregates |
| D-44 | Audit and its visibility: which changes require an audit log (STATE-005), and whether an admin sees audit entries (ADM-004). | Admin surfaces; teacher edit flows | Product + security · P1 | Define the audited event list |
| D-46 | Primary product metric definitions: the confirmed indicators (PRD-001) lack operational definitions (the PRD was not supplied). | Measurement plan, not UI | Product · P2 | Obtain the PRD definitions; align the analytics registry |


### 29.7 Verbatim-deferred questions (need interviews)

The following clarification answers were "I will explain verbally" and are therefore treated as unanswered: PRD-004 (are all 17 question types attached, and does MVP require all of them), AUT-001 (final public/auth page structure), AUT-002 (who creates accounts), AUT-009 (necessity of class-code joining), STU-009 (difference between assigned and free skills), STU-011 (recommendation inputs and owner), STU-024 (avatar display), TCH-007 (class performance per skill definition), TCH-008 (how a skill selection transfers to assignment/quiz/plan), IA-006 (skill statuses and their change rules), PRA-001 (official question-type list owner/product side), A11Y-006-equivalent items (S1 A11Y-00x block unanswered).

Action: schedule one 90-minute structured interview and convert each answer into either a [CONFIRMED] statement in this document or a D-xx entry with an owner.


### 29.8 Register statistics

[DERIVED] 48 decision entries: 11 P0-blocking (D-02, D-03, D-04, D-05, D-06, D-10, D-11, D-16, D-24, D-31, D-35), 1 conditionally P0-blocking (D-22 — only if student-facing quizzes ship in the first release), 2 P1 entries that escalate to P0 if D-02 brings parents/admins into the release (D-17, D-18), 6 P2 (D-01, D-30, D-37, D-39, D-40, D-46), and 28 P1. Twelve source question blocks (QUIZ, PLAN, ANL, PAR, ADM, SYS, STATE, A11Y, BM-\*, SYN, QA, plus parts of PRD/AUTH) remain entirely unanswered by S3.


## 30. SOURCE REFERENCES AND EVIDENCE TRACEABILITY


### 30.1 Section-to-source map


| Section | Primary evidence |
| --- | --- |
| 1 Executive summary | S1 §1–2, S3 PRD-001, S2 §1 |
| 2 Document control | All sources + document metadata + MD5 identity check |
| 3 Product definition | S1 §1, S2 §1, S3 PRD-002/SCP-001/SCP-007 |
| 4 Goals and value | S3 PRD-001, S2 §1.3, S1 §2 |
| 5 Users and roles | S1 §2.2, §9; S2 §2, §8.1; S3 SCP-003/004/005, TCH-009…013 |
| 6 MVP scope | S1 §2, §2.1; S2 §3; S3 PRD-003, SCP-001/002, STU-025 |
| 7 UX principles | S1 §14, §12; S2 §5, §9.2; engagement brief §9 (client direction) |
| 8 Experience architecture | Engagement brief §9 (client direction) + S1 §1.3/§6/§7.1 + S2 §1.3/§5/§6 |
| 9 Information architecture | S1 §4, §3.1; S2 §1.4, §4.2/4.3; S3 IA-001…005, STU-001, AUT-003/006 |
| 10 Sitemap | Derived from §9, §11, and the confirmed page sets in S1 §2.1 / S2 §3.3 |
| 11 Page inventory | S1 §5, §7, §8; S2 §5, §6; S3 answers per page |
| 12 Student experience | S2 §2.1, §5; S1 §5; S3 STU-001…025 |
| 13 Teacher experience | S2 §2.2, §6; S1 §7; S3 TCH-001…021 |
| 14 Secondary roles | S1 §9; S2 §6.6 note; S3 SCP-003/005, PRD-003 |
| 15 Flows | S2 §7 (20 flows as the base) + this document's additions (recovery, permission, multi-role, session expiry) |
| 16 Practice session | S1 §6, §6.1, §6.3, §11.1, §16.1; S2 §5.5, §8.2; S3 PRA-001…010, STU-017 |
| 17 Question architecture | S1 §6.2, §4; S2 §3.8; S3 PRD-004, SCP-006, PRA-002/003/004/008; Question types (2).xlsx (transcribed in v2.1) |
| 18 Assignment and class | S1 §7.3, §7.4, §16.2; S2 §3.6, §4.4; S3 TCH-009…021 |
| 19 Quiz generator | S1 §8.1; S2 §4.6, §5.5; S3 (QUIZ block unanswered) |
| 20 Analytics/recommendations/gamification | S1 §5.3, §8.3, §13, §14; S2 §4.5, §5.3, §6.6, §8.6; S3 STU-012…025, TCH-003, ANL-002 |
| 21 Behaviour spec | S1 §11, §11.1; S2 §9.1 |
| 22 States and errors | S1 §11, §11.1, §6.3; S2 §9.1 |
| 23 Responsive | S1 §2, §12; S2 §1.3; S3 QA-002 (open) |
| 24 Accessibility and localisation | S1 §12; S2 §1.3, §9.2; S3 A11Y-001/003/004/005 (open) |
| 25 Mathematics UX | S1 §12; S3 PRA-002; S2 §3.8 (numeric example) |
| 26 Privacy | S2 §8.1; S1 §11, §16.2; S1 §13.1 (AI policy) |
| 27 Roadmap | S1 §2.1 note, SCP-002; engagement brief phases |
| 28 Acceptance criteria | S1 §16, §16.1, §16.2; S2 §9 |
| 29 Decision register | All source open-question blocks + conflicts C-01…C-26 |
| 30 Traceability | This table |

Citation note. S1's section numbers are stable and are cited as printed (S1 §6.1, S1 §16.2). S2's page-requirement and flow sections are cited by section-and-item position, and every S2 citation in this document names the subject it refers to so that a number affected by the extraction's digit-order ambiguity cannot cause a misreading. Source question IDs (e.g. STU-005, TCH-019) are the most reliable citation mechanism in the evidence set and are used preferentially throughout.


### 30.2 Open-question coverage audit


| Source question block | Total raised (S1) | Answered in S3 | Remaining open | Where captured |
| --- | --- | --- | --- | --- |
| PRD | 5 | 4 (+1 verbal) | PRD-004 (verbal) | D-04, D-16 |
| SCP | 7 | 7 | SCP-005 content ownership | D-38 |
| AUTH | 9 | 6 (+3 verbal: AUT-001/002/009) | AUTH-001/002/008 | D-04, D-14, D-21, D-26 |
| IA | 6 | 5 (+1 verbal: IA-006) | IA-006 (status rules) | D-05 |
| STU | 25 | 19 (+2 verbal), 4 blank | STU-003, 007, 008, 011 (blank); STU-009, 024 (verbal) | D-19, D-27, D-39 |
| PRA | 10 | 7 answered, 3 blank | PRA-005, 006, 009 | D-24, D-34 |
| TCH | 21 | 18 (+2 verbal), 1 blank | TCH-007 (blank); TCH-004, 008 (verbal) | D-08, D-11 |
| QUIZ | 7 | 0 | All | D-22 |
| PLAN | 5 | 0 | All | D-45 (planning P1) |
| ANL | 6 | 0 | All | D-11, D-42, D-45 |
| PAR | 4 | 0 | All | D-17 |
| ADM | 4 | 0 | All | D-18 |
| SYS | 8 | 0 | All | D-28, D-44 |
| STATE | 5 | 0 | All | D-24 |
| A11Y | 5 | 0 | All | D-35, D-36 |
| BM-\* | 12 | 0 | All | Benchmark evidence only; not requirements |
| SYN | 3 | 0 | All | D-29, D-31 |
| QA | 5 | 0 | All | §23.2, §27.7 |


### 30.3 Benchmark evidence discipline

[CONFIRMED] The four benchmarks (Khan Academy/Khanmigo, Duolingo, Brilliant.org, IXL) are the source's own comparisons and are explicitly framed as evidence, not requirements (S1 §13 intro: nothing in the benchmark report is a design requirement).


| Benchmark | What was recorded as transferable | What was recorded as risk | Where this document uses it |
| --- | --- | --- | --- |
| Khan Academy / Khanmigo | Independent start; content↔practice linkage; guided step-by-step help separated from mastery | Uncontrolled AI answering; verbosity | §16.6 (guided explanation), §20.4 (no AI-flavoured reasons), AI tutor explicitly out of scope |
| Duolingo | Simple start, short sessions, immediate feedback, next-step clarity, visually distinctive progress | Streak/league/heart pressure; coercion | §7 P-12, §20.7 (no pressure mechanics) |
| Brilliant.org | Problem-based interaction, visual + step-by-step maths presentation | Complexity without educational purpose | §25.4 (visual models as a decision, not a requirement) |
| IXL | Fine-grained skill taxonomy, direct skill→practice link, per-skill progress (SmartScore), multi-level reporting | Score algorithm and terminology must not be copied | §9.5, §20.3, §17 (no algorithm copying) |

[CONFIRMED] The source's own conclusion list (§14) is the origin of several design decisions adopted here: one primary action per screen; Skill Library separate from Practice Session; feedback containing result, correct answer and solution method, not just colour; hint-based answers recorded separately; reports preserved with class/filters and ending in an action; motivation as a complement to learning without public ranking or commercial pressure; every indicator with a definition, denominator, window and interpretation limit.


### 30.4 Change record versus the prior draft (v1.0)


| Change | Reason |
| --- | --- |
| Removed the claim that "the supplied workbook defines the interaction inventory" | The workbook was supplied in the project source set and is transcribed in v2.1 |
| Added the full classification system, source inventory, provenance analysis, and a 26-entry conflict register | Required by the evidence discipline; v1.0 resolved conflicts silently |
| Added a 44-entry decision register with owners, priorities and resolution methods | v1.0 had a short open-questions list without ownership |
| Added the page inventory with per-page specifications (18 attributes for P0) | v1.0 specified six pages in depth only |
| Extended flows from ~6 narrative flows to 44 documented flows with branches, failures and recovery, plus 11 Mermaid diagrams | The flows are the foundation for interaction design |
| Added the two-axis-plus-mastery status proposal, class membership periods, indicator metadata schema, and recommendation reason tiers | These resolve real architectural gaps found in the sources |
| Added error taxonomy, state matrix by surface, and responsive/accessibility acceptance criteria | Required for implementation handover |
| Corrected the timer statement (elapsed, never countdown) to carry the PRA-006 caveat about active vs page-open time | Fidelity to the sources |


### 30.5 Limitations statement (final)

1.  v2.0 incorrectly recorded the Question Type workbook as unavailable. Version 2.1 corrects the evidence record and includes the workbook-derived inventory in §17.9 / Appendix A. The remaining blocker is approval of MVP inclusion and implementation-level answer contracts.

2.  SmartScore has no approved definition. All score presentation is specified as a slot with explicit unavailable states; no formula, trend, or threshold beyond the confirmed 80/90/100 medals is asserted.

3.  Indicator sets for both roles are undecided. Analytics pages are specified structurally, with the metadata schema that must be filled before charts are drawn.

4.  Nine clarification answers were deferred to verbal explanation and are treated as unanswered (§29.7).

5.  Twelve source question blocks are entirely unanswered, including the whole quiz, notification, and audit domains.

6.  Parent, School Admin, and System Admin experiences are not designed — deliberately, because the sources do not support them.

7.  Some numerals in the extracted Persian PDF text were subject to digit-order ambiguity. Every number used here is cross-checked where possible; the ~300 skills-per-grade figure is explicitly an estimate in the source, and the "13/31 pages" figure in S2 is treated as unverifiable and replaced by this document's own enumeration (§11.7).

This document is complete with respect to the evidence available, and explicit about what the evidence cannot support. It should not be treated as complete where a decision in §29 remains open.

End of document — Naranj Product UX Architecture v2.1


# REVISION NOTE — VERSION 2.1

This revision preserves the complete v2.0 architecture and its 30-section structure. It corrects the source inventory, removes the false statement that the Question Type workbook was unavailable, and adds a source-faithful transcription of the workbook's interaction models. Blank workbook fields have not been filled by inference.


## Changes from v2.0

- Corrected the evidence register: Question types (2).xlsx is present in the project source set and was inspected for this revision.
- Added the workbook-derived interaction inventory with original Persian labels, UX descriptions, validation notes, and examples.
- Replaced the missing-workbook blocker with the remaining decision: confirm which workbook interactions belong in the MVP and approve detailed answer contracts.
- Kept source-defined interaction names intact; proposed family mappings are explicitly labelled as design recommendations.
- Preserved the complete v2.0 architecture, including its page inventory, user journeys, role architecture, system states, roadmap, acceptance criteria, and decision register.
- Kept absent source details marked as open; no answer rules were invented where workbook cells were blank.

# 17.9 Workbook-derived question interaction inventory

Source: Question types (2).xlsx, Sheet1. The inventory below transcribes the workbook's interaction model, UX description, validation notes, and elementary-mathematics example. Blank source fields are shown as “Not specified in workbook”. The examples are source examples, not confirmation that each interaction is included in the first release.

The workbook does not by itself settle MVP inclusion, backend correctness contracts, tolerances, scoring, retry policy, or accessibility alternatives where these are not stated.


| Source category | Exact workbook interaction name | Proposed family | Workbook row |
| --- | --- | --- | --- |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | تک ‌گزینه‌ای تصویری/متنی (Standard MCQ) | Selection | 2 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | پاسخ کوتاه عددی/تایپی (Short Answer Input) | Text / numeric input | 5 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | املای عددی / شنیداری (Audio-to-Numeric Input) | Text / numeric input | 9 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | انتخاب دوتایی / بله و خیر (Binary Choice) | Selection | 12 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | ماتریس انتخاب یا جدول متقاطع (Matrix/Grid Choice) | Selection / grid | 15 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | انتخاب چندگانه (Multiple Response) | Selection | 20 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | فیلدهای متوالی خالی (Inline) | Text / numeric input | 21 |
| مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models) | کیبورد مجازی ریاضی (Math Keypad) | Text / numeric input | 22 |
| مدل‌های دستکاری بصری (Visual Manipulatives) | شمارنده‌های پویا (Counters) | Visual manipulative | 24 |
| مدل‌های دستکاری بصری (Visual Manipulatives) | کادرهای چندتایی (n-Frames) | Visual manipulative | 25 |
| مدل‌های دستکاری بصری (Visual Manipulatives) | رنگ‌آمیزی کسر (Shape Shading) | Visual manipulative | 26 |
| مدل‌های دستکاری بصری (Visual Manipulatives) | ابزارهای اندازه‌گیری متحرک | Visual manipulative | 27 |
| مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort) | مرتب‌سازی خطی (Ordering) | Drag / sort / match | 30 |
| مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort) | نمودارهای طبقه‌بندی (T-Charts) | Drag / sort / match | 31 |
| مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort) | جفت‌سازی متناظر (Matching) | Drag / sort / match | 32 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | پین‌گذاری روی محور اعداد | Graphing / drawing | 34 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | نمودارساز پویا (Chart Builder) | Graphing / drawing | 35 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | مختصات‌دهی تعاملی | Graphing / drawing | 36 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | ابزار ترسیم خطوط و افراز اشکال (Geometric Line Drawing & Partitioning) | Graphing / drawing | 37 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | ابزار ترسیم خط تقارن تعاملی (Interactive Symmetry Line) | Graphing / drawing | 38 |
| مدل‌های ترسیمی و نموداری (Interactive Graphing) | شکل‌سازی روی صفحه نقطه‌ای (Dot-Grid Polygon Builder) | Graphing / drawing | 39 |


## Detailed source transcription


### A01. تک ‌گزینه‌ای تصویری/متنی (Standard MCQ)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 2

UX / interaction description: گزینه‌ها به صورت دکمه‌های بزرگ و خوانا طراحی می‌شوند. کاربر با کلیک روی یک گزینه آن را متمایز (Highlight) می‌کند. برای پایه‌های اول و دوم گزینه‌ها حداکثر ۲ یا ۳ تا هستند و بیشتر از تصویر استفاده می‌شود.

Validation logic stated in workbook: مقایسه شناسه (ID) گزینه انتخابی کاربر با ID پاسخ صحیح در دیتابیس (ساده‌ترین نوع ارزیابی).

Elementary mathematics example: "کدام شکل یک لوزی است؟ [تصویر دایره] [تصویر مربع] [تصویر لوزی]"

Proposed interaction family: Selection [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A02. پاسخ کوتاه عددی/تایپی (Short Answer Input)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 5

UX / interaction description: یک کادر متنی (Input Field) ساده در انتهای عبارت یا مسئله یا تصویر. به محض کلیک کودک روی کادر، کیبورد عددی (در موبایل) فعال می‌شود. سیستم نباید اجازه تایپ حروف الفبا را در این کادر بدهد( برای درس ریاضی و سوال های عددی).

Validation logic stated in workbook: سیستم فاصله‌های خالی (Spaces) احتمالی را حذف کرده و مقدار عددی ورودی را با کلید جواب مطابقت می‌دهد.

Elementary mathematics example: "حاصل عبارت مقابل چقدر است؟ ۱۳ = ۵ + ۸"

Proposed interaction family: Text / numeric input [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A03. املای عددی / شنیداری (Audio-to-Numeric Input)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 9

UX / interaction description: یک دکمه پخش صوتی (Play Button) با گرافیک بزرگ و کودکانه (مانند نماد گوش در تصویر) قرار دارد. کودک با کلیک روی آن، صدای خوانده شدن یک عدد را می‌شنود. سپس یک کادر متنی کوچک (Input) فعال می‌شود تا کودک عدد مربوطه را تایپ کند.

Validation logic stated in workbook: Not specified in workbook.

Elementary mathematics example: Not specified in workbook.

Proposed interaction family: Text / numeric input [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A04. انتخاب دوتایی / بله و خیر (Binary Choice)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 12

UX / interaction description: دو دکمه بزرگ و رنگی کنار هم یا زیر هم (مثل "بله / خیر" یا "درست / نادرست"). این مدل بار شناختی فوق‌العاده پایینی دارد و برای سنجش سریع درک مفاهیم عالی است.

Validation logic stated in workbook: مقایسه بولی (True/False) انتخاب کاربر با پاسخ کلید سوال.

Elementary mathematics example: "آیا عدد ۹ یک عدد زوج است؟ [ بله ] [ خیر ]"

Proposed interaction family: Selection [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A05. ماتریس انتخاب یا جدول متقاطع (Matrix/Grid Choice)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 15

UX / interaction description: یک جدول که سطرها حاوی اعداد/اشکال و ستون‌ها حاوی ویژگی‌ها هستند. کاربر باید در تقاطع هر سطر و ستون، چک‌باکس یا دکمه رادیویی مربوطه را علامت بزند.

Validation logic stated in workbook: سیستم به صورت سطر به سطر تیک‌ها را بررسی می‌کند. تمام سطرها باید درست علامت زده شده باشند تا کل سوال درست لحاظ شود.

Elementary mathematics example: "ویژگی هر عدد را در جدول مشخص کن: سطرها: ۱۲، ۱۵ ستون‌ها: زوج، فرد، مضرب ۵"

Proposed interaction family: Selection / grid [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A06. انتخاب چندگانه (Multiple Response)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 20

UX / interaction description: به جای یک پاسخ، چند چک‌باکس وجود دارد و کاربر باید «تمام جواب‌های درست» را تیک بزند.

Validation logic stated in workbook: آرایه انتخاب‌های کاربر باید دقیقاً برابر با آرایه پاسخ‌های صحیح باشد (نه کمتر، نه بیشتر).

Elementary mathematics example: "کدام یک از عبارات زیر حاصلشان برابر با عدد ۱۲ است؟ (تیک زدن ۳×۴ و ۶+۶)"

Proposed interaction family: Selection [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A07. فیلدهای متوالی خالی (Inline)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 21

UX / interaction description: چندین کادر متنی کوچک در مراحل یک ضرب طولانی یا تقسیم تکنیکی که کاربر باید پر کند.

Validation logic stated in workbook: چک کردن مقدار هر فیلد به صورت مجزا؛ برای رفتن به فیلد بعدی می‌توان دکمه Tab را فعال کرد.

Elementary mathematics example: کامل کردن کادرهای خالی در الگوی عددی: ۳ ، ۶ ، [۹] ، ۱۲ ، [۱۵].

Proposed interaction family: Text / numeric input [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A08. کیبورد مجازی ریاضی (Math Keypad)

Source category: مدل‌های گزینشی کلاسیک و فیلدهای متنی ساده (Standard Input & Selection Models)

Workbook row: 22

UX / interaction description: به محض کلیک روی فیلد پاسخ، یک کیبورد کوچک شامل خط کسری، علامت اعشار، یا جفت پرانتز باز می‌شود.

Validation logic stated in workbook: متن ورودی به صورت استاندارد ریاضی (مثل فرمت LaTeX یا MathJSON) ذخیره و هم‌ارزی آن سنجیده می‌شود.

Elementary mathematics example: "حاصل جمع دو کسر را وارد کن: ۲/۵"

Proposed interaction family: Text / numeric input [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A09. شمارنده‌های پویا (Counters)

Source category: مدل‌های دستکاری بصری (Visual Manipulatives)

Workbook row: 24

UX / interaction description: کودک اشیاء (ستاره، سیب) را از یک مخزن می‌کشد (Drag) و داخل کادر رها می‌کند.

Validation logic stated in workbook: سیستم تعداد المان‌های موجود در مختصات کادر هدف را می‌شمارد.

Elementary mathematics example: "۵ موز داخل سبد قرار بده."

Proposed interaction family: Visual manipulative [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A10. کادرهای چندتایی (n-Frames)

Source category: مدل‌های دستکاری بصری (Visual Manipulatives)

Workbook row: 25

UX / interaction description: یک جدول ۲×۵ روی صفحه است. با کلیک روی خانه‌ها، ژتون رنگی ظاهر یا غیب می‌شود.

Validation logic stated in workbook: مقایسه تعداد کلیک‌های فعال با عدد کلید جواب.

Elementary mathematics example: "عدد ۷ را روی کادر ده‌تایی نشان بده."

Proposed interaction family: Visual manipulative [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A11. رنگ‌آمیزی کسر (Shape Shading)

Source category: مدل‌های دستکاری بصری (Visual Manipulatives)

Workbook row: 26

UX / interaction description: اشکال هندسی به بخش‌های مساوی تقسیم شده‌اند؛ کاربر با کلیک، بخش‌ها را رنگ می‌کند.

Validation logic stated in workbook: شمارش تعداد بخش‌های رنگ‌شده و مقایسه با صورت کسر.

Elementary mathematics example: "۳ کلوچه از ۴ بخش کلوچه را رنگ کن تا کسر ۳/۴ ساخته شود."

Proposed interaction family: Visual manipulative [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A12. ابزارهای اندازه‌گیری متحرک

Source category: مدل‌های دستکاری بصری (Visual Manipulatives)

Workbook row: 27

UX / interaction description: خط‌کش یا نقاله روی صفحه ظاهر می‌شود؛ کاربر باید آن را بچرخاند یا جابجا کند تا شیء را اندازه بگیرد.

Validation logic stated in workbook: فرانت‌آند مختصات پیکسل یا زاویه ابزار را به عدد تبدیل کرده و با تلورانس مشخص بررسی می‌کند.

Elementary mathematics example: "طول مداد را با خط‌کش اندازه بگیر (مثلاً ۵.۲ سانتی‌متر)."

Proposed interaction family: Visual manipulative [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A13. مرتب‌سازی خطی (Ordering)

Source category: مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort)

Workbook row: 30

UX / interaction description: چند کارت حاوی اعداد یا کسرها وجود دارد که باید به ترتیب روی یک خط چیده شوند.

Validation logic stated in workbook: بررسی آرایه نهایی چیدمان؛ ایندکس کارت‌ها باید صعودی یا نزولی باشد.

Elementary mathematics example: "کارت‌ها را از کوچک به بزرگ مرتب کن: ۱/۴، ۱/۲، ۳/۴"

Proposed interaction family: Drag / sort / match [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A14. نمودارهای طبقه‌بندی (T-Charts)

Source category: مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort)

Workbook row: 31

UX / interaction description: دو یا چند جعبه هدف (مانند نمودار ون) وجود دارد که باید کارت‌ها درون آن‌ها انداخته شوند.

Validation logic stated in workbook: هر کارت یک تگ یا ID دارد؛ سیستم بررسی می‌کند آیا هر ID در جعبه درست قرار گرفته یا خیر.

Elementary mathematics example: "اعداد زیر را در دو جعبه زوج و فرد دسته‌بندی کن."

Proposed interaction family: Drag / sort / match [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A15. جفت‌سازی متناظر (Matching)

Source category: مدل‌های جابجایی و طبقه‌بندی (Drag, Drop & Sort)

Workbook row: 32

UX / interaction description: کاربر روی یک کارت در ستون الف و سپس کارت متناظر در ستون ب کلیک می‌کند تا خطی بین آن‌ها رسم شود.

Validation logic stated in workbook: بررسی جفت شدن متغیرهای هم‌ارز (مثلا ID_A1 == ID_B1).

Elementary mathematics example: "هر کسر را به شکل هندسی متناظرش وصل کن."

Proposed interaction family: Drag / sort / match [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A16. پین‌گذاری روی محور اعداد

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 34

UX / interaction description: یک پین (سوزن) روی محور اعداد قرار دارد که کاربر با حرکت موس آن را روی درجات مختلف تنظیم می‌کند.

Validation logic stated in workbook: فرانت‌آند موقعیت پین را به مقدار عددی تبدیل کرده و به بک‌اند می‌فرستد.

Elementary mathematics example: "پین را روی عدد کسر مخلوط ۱ و نیم قرار بده."

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A17. نمودارساز پویا (Chart Builder)

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 35

UX / interaction description: کاربر با کشیدن بالای ستون‌های یک نمودار، ارتفاع آن‌ها را بر اساس داده‌های یک جدول تغییر می‌دهد.

Validation logic stated in workbook: ارتفاع ستون‌ها (بر حسب واحد نمودار) با مقادیر جدول مقایسه می‌شود.

Elementary mathematics example: "با توجه به جدول، نمودار ستونی تعداد سیب‌ها (۵) و پرتقال‌ها (۳) را رسم کن."

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A18. مختصات‌دهی تعاملی

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 36

UX / interaction description: یک صفحه شطرنجی مختصات (ربع اول) که کاربر با کلیک روی تقاطع خطوط، نقطه می‌گذارد.

Validation logic stated in workbook: سیستم مختصات $(x, y)$ نقطه‌ی کلیک‌شده را با کلید جواب تطبیق می‌دهد.

Elementary mathematics example: "نقطه مربوط به مختصات (۳ , ۴) را روی صفحه مشخص کن."

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A19. ابزار ترسیم خطوط و افراز اشکال (Geometric Line Drawing & Partitioning)

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 37

UX / interaction description: یک شکل هندسی با نقاط گره‌ای (Dots/Hotspots) بر رویperimeter یا داخل آن نمایش داده می‌شود. دانش‌آموز با کلیک روی یک نقطه و سپس نقطه دیگر، یک پاره‌خط را ترسیم می‌کند. خطوط ترسیم‌شده باقی می‌مانند. دانش‌آموز می‌تواند چندین خط بکشد تا یک افراز ایجاد کند.

Validation logic stated in workbook: سیستم، خطوط ترسیم‌شده را بررسی می‌کند تا ببیند آیا آن‌ها یک راه حل معتبر را تشکیل می‌دهند یا خیر (مانند افراز شکل به n بخش مساوی با مساحت برابر). ممکن است چندین راه حل معتبر وجود داشته باشد.

Elementary mathematics example: یک مربع با نقاط گره‌ای نشان داده شده و هدف "تغییر نحوه‌ی افراز مربع به چهار بخش مساوی" است. کاربر باید نقاطی را به هم وصل کند تا یک افراز جدید (مثلاً افقی، یا با خطوط مورب دیگر) ایجاد کند.

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A20. ابزار ترسیم خط تقارن تعاملی (Interactive Symmetry Line)

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 38

UX / interaction description: با نقاط گره‌ای برای ترسیم. دانش‌آموز باید خط یا خطوط تقارن را رسم کند.

Validation logic stated in workbook: سیستم بررسی می‌کند که آیا خط ترسیم‌شده، واقعاً یک خط تقارن معتبر برای شکل است یا خیر.

Elementary mathematics example: "با استفاده از نقاط، تمام خطوط تقارن این ستاره را رسم کن."

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


### A21. شکل‌سازی روی صفحه نقطه‌ای (Dot-Grid Polygon Builder)

Source category: مدل‌های ترسیمی و نموداری (Interactive Graphing)

Workbook row: 39

UX / interaction description: کاربر با کلیک روی هر نقطه، یک رأس (Vertex) ایجاد می‌کند. با کلیک روی نقطه بعدی، فرانت‌آند به صورت خودکار خطی بین این دو نقطه رسم می‌کند. زمانی که کاربر دوباره روی نقطه شروع (رأس اول) کلیک کند، شکل بسته شده و یک چندضلعی (Polygon) تشکیل می‌شود.

Validation logic stated in workbook: بک‌آند نمی‌تواند این سوال را با یک «مختصات ثابت» ارزیابی کند، چون کاربر می‌تواند متوازی‌الاضلاع را در ابعاد مختلف و در هر کجای این صفحه بکشد.

Elementary mathematics example: Not specified in workbook.

Proposed interaction family: Graphing / drawing [DESIGN RECOMMENDATION]

Implementation note: confirm exact input schema, completion rules, correctness evaluation, partial-credit policy (if any), keyboard/touch alternatives, RTL behaviour, error messages, and persistence with Product, Content, and Engineering before high-fidelity UI or development.


## Workbook-derived design implications

- The Practice Session should retain one shared shell; the answer area changes according to the selected interaction component.
- Selection interactions need a clear distinction between selecting an option and submitting the response.
- Numeric/text inputs need an explicit accepted-character policy, including Persian/Arabic/Latin digits and decimal separators; the workbook does not fully define these normalisation rules.
- Visual manipulatives and drag interactions need keyboard and touch alternatives. The workbook describes drag and coordinate interactions but does not specify accessibility fallbacks.
- Graphing and drawing interactions require a coordinate model and correctness contract that can accept valid alternative solutions where the task permits them.
- The workbook validation column is not a complete backend contract. It must be reviewed for edge cases, equivalence, tolerances, partial completion, and multiple valid answers.
- No type-specific page layout should be created by default. Specialised answer components should be composed inside the shared Practice Session shell.

## Remaining decisions after workbook transcription


| ID | Decision | Required resolution | Owner |
| --- | --- | --- | --- |
| QTI-01 | MVP inclusion | Confirm which workbook interactions are enabled in the first release and which are deferred. | Product Owner |
| QTI-02 | Answer contracts | Approve canonical answer schema and correctness rules for each interaction. | Product + Content + Engineering |
| QTI-03 | Partial correctness | Decide whether multi-part, matrix, and graphing responses can receive partial credit. | Product + Assessment |
| QTI-04 | Multiple valid solutions | Define evaluation strategy for drawing, partitioning, symmetry, and polygon tasks. | Content + Engineering |
| QTI-05 | Input normalisation | Define Persian/Arabic/Latin digits, decimal separators, whitespace, and mathematical equivalence. | Engineering + Content |
| QTI-06 | Accessibility alternatives | Approve keyboard/touch alternatives for drag, drawing, and measurement interactions. | UX + Accessibility + Engineering |
| QTI-07 | Media failure | Define recovery/replacement behaviour when required audio or visual media fails. | Product + Engineering |
| QTI-08 | Device support | Confirm which interaction types are fully supported on laptop, tablet, and mobile. | Product + Engineering |
