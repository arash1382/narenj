# NARANJ — Illustration Asset Taxonomy

**Purpose:** Define how the interface selects illustration families for the MVP and how the asset model can accommodate a future parent role.
**Status:** Updated from the product owner's latest clarification.
**Authority:** This document governs illustration selection only. It does not define account permissions or role authorization.

## 1. MVP scope

The MVP focuses on two account roles:
- **Student**
- **Teacher**

The parent role is not part of the current MVP scope. Keep the illustration system extensible for a future parent experience, but do not build parent-specific onboarding, settings, navigation, or role-selection UI now.

## 2. Role resolution

Users enter through the school-code flow. The system determines whether the account is a student or teacher from the school/account context.

Therefore:
- Do not ask the user to choose Student or Teacher in a separate role-selection step if the school-code flow already determines it.
- Do not infer role from the selected illustration.
- Role-based permissions and page access must come from the authenticated account data, not the illustration category.
- The illustration resolver consumes the role/profile context after authentication; it does not determine that context.

## 3. MVP illustration mapping

| Detected account context | Illustration family | MVP priority |
|---|---|---|
| Student, boy profile | `student.boy` | In scope |
| Student, girl profile | `student.girl` | In scope |
| Teacher | `teacher` | In scope |
| Neutral state with no specific context | `default` | In scope as needed |
| Parent / mother | `parent.mother` | Future-ready only; not an MVP flow |
| Parent / father | `parent.father` | Future-ready only; not an MVP flow |

The number of images in each family is not fixed by this document. Preserve the actual asset inventory and allow categories to contain different numbers of images.

## 4. Future parent support

If a parent account is introduced in a later release, the illustration system should be able to resolve:
- `parent.mother`
- `parent.father`

For the MVP, this is only a reserved semantic category. Do not spend implementation time building parent-specific flows or a parent selection menu. If an unexpected parent account reaches the MVP, handle it according to the product's actual authorization and release policy; do not invent a parent experience or grant access based on the illustration.

## 5. Asset registry

Components should request semantic illustration keys rather than hard-code image paths.

Illustrative keys:

```ts
type IllustrationKey =
  | "default"
  | "student.boy"
  | "student.girl"
  | "teacher"
  | "parent.mother" // reserved for a future release
  | "parent.father"; // reserved for a future release
```

This is an illustrative data contract, not a requirement to create unused parent assets in the MVP.

## 6. Multiple images per category

Different categories may contain different numbers of images. Do not enforce equal counts.

- Keep each supplied image in its correct category.
- Do not create artificial duplicate images to make category counts equal.
- If a category contains one image, use that image.
- If a category contains multiple images, select according to a documented deterministic rule or the relevant UI context.
- Do not randomly change an illustration on every render.
- Preserve supplied filenames where possible; do not rename assets without a technical need.

## 7. Visual consistency and cultural constraints

- Keep crop, scale, focal point, lighting and background treatment consistent within each intended illustration family.
- Girl student illustrations must retain appropriate hair coverage.
- Do not repurpose a parent illustration as a student or teacher illustration merely by changing its label.
- The illustration is contextual decoration; it must not obscure the popup title, explanation or primary action.

## 8. Not specified yet

The source image and current clarification do not define:
- the exact number of images per category;
- the final file names and formats;
- the precise rule for choosing among multiple student/teacher images;
- whether student gender/profile information is supplied by the school system or another account field.

Do not invent these values. Inspect the actual asset inventory and account data before implementation.
