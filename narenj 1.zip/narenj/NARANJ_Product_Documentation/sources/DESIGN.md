# NARANJ — Visual Experience & UI Implementation Specification

**Document ID:** NRNJ-DES-002  
**Version:** 2.0  
**Status:** Design direction approved for the next redesign iteration; unresolved product details remain explicitly marked  
**Product:** نارنج (Naranj)  
**Primary language:** Persian  
**Default direction:** RTL  
**Design priority:** Mobile-first  
**Audience:** AI design agents, product designers, UX designers, front-end engineers and QA

---

## 0. How to interpret this document

This document is the primary implementation brief for the next Naranj UI/UX redesign iteration. It expands the previous `DESIGN.md v1.1` with explicit guidance on information density, visual hierarchy, 3D visual language, age-appropriate engagement, responsive behavior, onboarding and page-level composition.

It is not permission to redesign the product logic.

### 0.1 Evidence labels

Use these labels throughout implementation:

- **[LOCKED PRODUCT RULE]** — confirmed by Product UX Architecture v2.1 or approved source workbooks. Do not change.
- **[APPROVED DESIGN DIRECTION]** — explicitly selected by the product owner for this redesign.
- **[DESIGN REQUIREMENT]** — binding visual or interaction requirement in this document.
- **[DESIGN RECOMMENDATION]** — recommended treatment; may be adjusted if usability testing shows a better solution.
- **[OPEN DECISION]** — source material does not settle the question. Do not invent an answer.
- **[TECHNICAL VALIDATION]** — requires engineering, data, security or performance confirmation.

### 0.2 Source precedence

When sources conflict, follow this order:

1. Product-owner decisions explicitly made for the current redesign.
2. Naranj Product UX Architecture v2.1 for roles, product behavior, flows and business rules, except where a current explicit decision deliberately supersedes it.
3. Approved question-type workbook for question types and answer interactions.
4. Approved demo scope for what is implemented in the current demo.
5. Existing Naranj brand tokens, palette and typography files.
6. This document for visual composition, density, 3D treatment and implementation quality.
7. Reference products and external design research as inspiration only.

If two authoritative sources conflict, record the conflict and ask for resolution. Never silently choose.

### 0.3 Required project inputs

Before implementation, inspect and use the actual project files:

- `Naranj_Product_UX_Architecture_v2.1`
- Approved Question Types workbook
- Approved Demo Scope
- Existing Naranj color tokens and semantic color definitions
- Existing typography files and typography tokens
- Existing component and layout token files
- Existing assets, mascot/avatar artwork and approved illustrations

Do not recreate, approximate or replace existing assets when the source asset is available.

---

## 1. Product definition and design objective

Naranj is a Persian-first educational practice platform for students approximately 9–15 years old, with teachers as the second primary role.

The student loop is:

**Identify the next useful learning action → practise one question at a time → receive instructional feedback → understand progress → choose the next learning action.**

The teacher loop is:

**Understand class context → find a skill or learning need → assign practice or generate a quiz → review results → take a follow-up teaching action.**

### 1.1 The redesign problem

The current interface has a recurring usability problem: too much information is visible at once. Content blocks, cards, numbers, labels, controls and visual elements compete for attention. This makes it harder to understand what matters now, what can wait and what action should be taken.

The redesign must materially improve:

- Information overload and excessive simultaneous content.
- Weak or inconsistent hierarchy.
- Too many equally prominent cards and panels.
- Insufficient visual warmth, color variation and age-appropriate delight.
- Limited use of visual storytelling and meaningful 3D elements.
- Mobile layouts that feel compressed rather than intentionally designed.
- Unclear separation between the primary task and supporting information.

Do not solve these problems by simply shrinking typography, hiding important functions, adding more decorative elements or increasing the number of colors. The solution is deliberate prioritization, progressive disclosure, stronger composition and purposeful visual engagement.

### 1.2 Core design outcome

The interface should feel:

- Clear at first glance.
- Friendly, energetic and age-appropriate without feeling childish.
- Visually distinctive and recognizable as Naranj.
- Calm enough to support concentration.
- Rewarding without pressure or public competition.
- Fast and direct for teachers.
- Comfortable and fully usable on a mobile phone.

**The product should feel visually rich, but cognitively light.**

---

## 2. Approved redesign decisions

The following decisions are approved for this iteration.

| Area | Decision | Implementation meaning |
|---|---|---|
| Competition model | Personal growth only | Progress is measured against the student's own previous performance. No public leaderboard or ranking. |
| Visual direction | Prominent 3D visual language | 3D is a recognizable part of the product identity, not an occasional decorative asset. |
| Responsive priority | Mobile-first | Design and validate the smallest supported layout first, then scale up. |
| Deliverables | Journey Maps + precise Task Specifications | Every page must have a defined user goal, hierarchy, content budget, actions, states and acceptance criteria. |
| Onboarding | Guided onboarding | First-run flow begins with avatar selection, followed by an interactive guided tour. |

### 2.1 Existing constraints that remain unchanged

Unless separately approved, preserve:

- Existing Naranj brand palette and semantic color tokens.
- Existing typography decisions, font files, weights and language assignments.
- Persian-first experience and RTL default.
- Existing product roles and permissions.
- Existing approved sitemap and page inventory, except where a change is explicitly recorded.
- Existing question types and answer interaction contracts.
- Existing practice-session business rules.
- Existing teacher assignment, class, quiz and analytics rules.
- Personal-achievement-only gamification.

### 2.2 Explicit change to responsive priority

The earlier UX Architecture v2.1 treated laptop/tablet as the primary design targets and mobile as secondary. This is superseded for the current redesign by the product owner's explicit **mobile-first** decision.

This changes design and validation priority, not the supported device range. Desktop and tablet remain fully supported.

### 2.3 Explicit change to onboarding

UX Architecture v2.1 §12.3 originally rejected an avatar-selection gate and mandatory multi-step onboarding. The current product-owner decision deliberately changes that direction:

1. First successful student sign-in.
2. Avatar selection.
3. Interactive guided tour.
4. Student Home.

The exact avatar catalogue, whether avatar selection can be skipped, and whether the tour is skippable remain **[OPEN DECISION]** unless separately specified. Recommended default: allow the tour to be skipped and replayed later; do not make completion of the tour a condition for accessing learning.

---

## 3. Audience, cognitive load and attention design

Naranj serves students aged approximately 9–15. This is a broad developmental range. The interface must not assume that all users read, interpret symbols or navigate complex interfaces at the same level.

### 3.1 Attention hierarchy

Every page must establish a clear order of attention:

1. **Primary task:** What should the user do here?
2. **Essential context:** What does the user need to know to do it correctly?
3. **Supporting information:** What helps but is not required immediately?
4. **Decorative / motivational layer:** What adds personality without competing with the task?

A user should be able to identify the page purpose and its primary action within approximately 3–5 seconds. This is a design target to validate, not a guaranteed behavioral fact.

### 3.2 Information density budget

Use the following as default design limits. A documented exception is allowed only when the task genuinely requires more information.

#### Student surfaces

- One dominant task or message per screen.
- No more than 3 major content zones in the initial mobile viewport.
- No more than 1 primary CTA per visual section.
- No more than 2 secondary numeric indicators in a standard card.
- Keep supporting descriptions to 1–2 short sentences.
- Avoid showing multiple full progress systems at the same time.
- Do not show all available skills, rewards, achievements and recommendations simultaneously.
- Show 3–5 recommendations only where the product architecture calls for them; use compact presentation and progressive disclosure.
- In practice, the question and answer interaction dominate. Decorative 3D, reward counters and navigation must not compete with them.

#### Teacher surfaces

- Teacher pages may be denser than student pages because they support operational work.
- Still establish one primary task and a clear scan path.
- Prefer a compact summary followed by a table/list or a drill-down.
- Avoid placing every class metric, student metric, action and chart in the first viewport.
- Tables should follow UXA v2.1 limits (maximum 6 columns before using row expansion or another detail pattern).
- Use filters only when they materially help the task.
- Put definitions, secondary metrics and audit-level detail one level deeper.

#### Global rules

- Do not wrap every content group in a separate card.
- Avoid card-inside-card patterns.
- Do not use multiple large headings with equal visual weight in one viewport.
- Do not repeat the same information in a card, badge, progress bar and chart.
- Do not show a metric unless its meaning and source are defined.
- Never show zero as a substitute for missing or unavailable data.
- Do not add content merely to fill empty space.

### 3.3 Progressive disclosure

Use three levels:

- **Level 1 — glanceable:** only the information needed to understand the current page and take its primary action.
- **Level 2 — contextual:** details opened by an explicit action, such as “View details”, an accordion or a detail route.
- **Level 3 — advanced / historical:** secondary settings, extended history, definitions and less frequent controls.

Progressive disclosure must not hide essential task instructions, critical status, primary actions or recovery paths.

### 3.4 First-viewport test

For every page, inspect the first mobile viewport and answer:

- Is the page purpose obvious?
- Is there one clear primary action?
- Can the user identify where to look first?
- Are secondary details visually quieter?
- Is any visible element redundant?
- Can one entire content block be removed or moved deeper without harming the task?

If the first viewport feels crowded, simplify it before adding more visual styling.

---

## 4. Visual experience system

### 4.1 Visual personality

The desired direction combines:

- A polished, friendly educational product.
- Strong and clear information hierarchy.
- A recognizable 3D visual identity.
- Controlled use of vivid brand colors.
- Soft, tactile depth and layered surfaces.
- Simple, highly legible functional UI.

Avoid generic dashboard aesthetics, excessive glassmorphism, random gradients, childish clip-art, overused blobs, or a collection of unrelated 3D stock illustrations.

### 4.2 3D visual language

3D must be a coherent visual system. It should appear consistently in selected high-value moments rather than being scattered randomly across every component.

#### Recommended 3D use cases

- Student avatar and avatar selection.
- Naranj mascot and key brand moments.
- Empty states where a character can help explain the next action.
- Achievement and reward moments.
- Selected learning milestones.
- Onboarding illustrations.
- A small number of student-home highlights.

#### 3D restraint rules

- Do not put a 3D object in every card.
- Do not use 3D behind dense text or math questions.
- Do not let 3D overlap labels, buttons, formulas or answer controls.
- Keep silhouettes and facial expressions readable at mobile sizes.
- Use consistent lighting, camera perspective, material quality and shadow softness.
- Avoid mixing photorealistic 3D with flat cartoon illustrations without a deliberate art-direction rule.
- Use 3D as a visual anchor, not as a substitute for information architecture.
- Do not use continuous 3D animation in the practice question area.
- Provide static or reduced-motion alternatives.

#### 3D quality direction

Preferred qualities:

- Soft, rounded forms.
- Tactile but restrained materials.
- Friendly, expressive characters.
- Controlled highlights and soft shadows.
- Clear silhouettes.
- Consistent scale and camera angle.
- Warm, approachable lighting.
- High-quality rendering without excessive realism.

The exact rendering style should be established through a small approved visual exploration before producing a large asset library.

### 4.3 Color usage and visual energy

The existing Naranj palette is authoritative. Do not invent a replacement palette or alter approved brand values.

Improve perceived color richness through **better composition and semantic application**:

- Use existing primary and secondary colors for meaningful emphasis.
- Use approved tints and shades only if they already exist in the token system or are explicitly approved.
- Use neutral surfaces to create breathing room around stronger colors.
- Give each major student-facing area a clear color role; do not make every card a different bright color.
- Use color to distinguish action, progress, category or feedback only when that meaning is consistent.
- Keep body text and question content highly legible.
- Verify contrast for every foreground/background pairing.
- Never communicate correctness, status or selection through color alone.

The visual result should feel more colorful and alive than the current interface, but not noisy.

### 4.4 Shape, depth and surfaces

- Use a consistent radius scale.
- Use surface contrast and spacing before adding shadows.
- Reserve stronger elevation for floating or interactive elements.
- Avoid excessive borders around every block.
- Use layered surfaces sparingly to create depth.
- Keep input fields and answer components visually stable and highly legible.
- Do not use decorative outlines that make the page look fragmented.

### 4.5 Illustration and iconography

- Use one coherent illustration language.
- Prefer custom Naranj assets and mascot/avatar assets over generic stock artwork.
- Icons must be recognizable and consistent in stroke, fill and optical size.
- Do not use emoji as a replacement for core product iconography.
- Decorative illustrations must not carry essential information by themselves.

---

## 5. Gamification and personal achievement

Gamification must reinforce learning progress, not create pressure or distract from learning.

### 5.1 Product rules

**[LOCKED PRODUCT RULE]**

- Personal progress only.
- No public ranking or leaderboard.
- Coins, badges, goals and medals are part of the product model.
- Skill medals: 80 bronze, 90 silver, 100 gold.
- Re-practice does not award additional coins; time still counts.
- Hint usage does not reduce SmartScore.
- Personal achievement must not be presented as competition against other students.

### 5.2 Visual treatment

- Make achievements visually rewarding through controlled color, 3D objects, celebratory motion and clear language.
- Keep reward visuals secondary during active question solving.
- Celebrate meaningful milestones, not every tiny interaction.
- Avoid full-screen celebrations that repeatedly interrupt practice.
- Use short, dismissible celebration moments.
- Ensure the achievement remains understandable without animation.
- Never imply that a student is behind other students.

### 5.3 Progress communication

Progress must answer:

- What has the student completed?
- What is the current level or state?
- What is the next useful action?

Do not show a decorative percentage without a defined calculation. Do not imply mastery where the source data does not support it.

---

## 6. Navigation and page composition

### 6.1 Navigation

Follow the approved sitemap and role-specific navigation architecture.

- Do not invent new destinations.
- Keep the primary navigation concise.
- Prefer no more than 5 primary navigation items per role, consistent with UXA v2.1.
- Keep frequent actions visible and infrequent utilities secondary.
- Show the current location clearly using more than color alone.
- Do not rely on hover-only navigation.
- Preserve context when opening details, dialogs or temporary tasks.
- Keep student navigation simpler and less operational than teacher navigation.

### 6.2 Page composition order

Use this as the default composition model, adapting only when the task requires it:

1. Navigation / context.
2. Page title and short purpose statement, if needed.
3. Primary action or primary content.
4. Supporting content.
5. Secondary information and utilities.

Do not force a title block, description and action row onto every page if the task is already obvious.

### 6.3 One primary action

Every page must identify one primary action. Other actions must be visually secondary.

Examples:
- Student Home: continue or start the most relevant practice.
- Skill Library: choose a skill or topic.
- Practice Session: submit the current answer.
- Session Summary: continue to the next useful step.
- Teacher Home: act on the most important class need.
- Assignment Builder: proceed to review.
- Assignment Review: publish or return to edit.

These examples do not authorize changing the underlying product flow.

---

## 7. Mobile-first responsive system

### 7.1 Required design order

Design and validate in this order:

1. 360px mobile.
2. 390px mobile.
3. 430px large mobile.
4. 768px tablet.
5. 1024px laptop.
6. 1280px desktop.
7. 1440px wide desktop.

Do not design a desktop page and then merely stack its cards for mobile.

### 7.2 Mobile requirements

- Single-column composition for most student surfaces.
- Primary actions must be reachable without precision pointer movement.
- Avoid horizontal page scrolling.
- Keep touch targets at least 44×44 CSS px where practical.
- Avoid fixed elements covering content or keyboard focus.
- Keep the most important action in a predictable location.
- Use bottom navigation only if it is already supported by the approved information architecture; do not add it as a new destination model without approval.
- Use compact, readable cards and lists.
- Keep page headings concise.
- Avoid multi-column metric dashboards on mobile.
- Use accordions or detail routes for secondary information.
- Keep practice question content within a stable, distraction-free frame.

### 7.3 Tablet and desktop

- Scale the same information hierarchy; do not introduce new content just because space is available.
- Use additional width for readable grouping and comparison, not for showing every module at once.
- Keep long text at a controlled measure.
- Use multi-column layouts only when the content benefits from side-by-side comparison.
- Maintain a clear main content area and predictable navigation.
- On wide screens, avoid stretching cards and paragraphs across the entire viewport.

### 7.4 Grid and spacing

Existing layout tokens remain the source of truth. The previous design baseline used a 4px spacing foundation and responsive grids. Do not invent conflicting values.

If the existing token files are missing or inconsistent, report the issue before creating new global tokens.

---

## 8. Typography, Persian and RTL

- Preserve the approved Naranj Persian and English font assignments and local font files.
- Persian is the default language and RTL is the default direction.
- Use CSS logical properties.
- Keep text hierarchy clear through size, weight, spacing and line-height, not color alone.
- Do not use too many font sizes or weights on one page.
- Keep student-facing copy short, concrete and age-appropriate.
- Use consistent Persian terminology for product concepts.
- Handle mixed Persian/Latin text, URLs, IDs, numbers, dates and mathematical expressions correctly.
- Do not mirror non-directional icons.
- Mathematical notation must follow the approved math rendering and direction rules.
- Verify real Persian copy in rendered UI; placeholder Latin copy is not an adequate RTL test.

---

## 9. Core component behavior and visual standards

Use the existing component library and tokens. Extend components only when a real product need requires it.

### 9.1 Cards

- A card must represent a meaningful content group or action.
- Do not turn every paragraph, number or label into its own card.
- Avoid nested cards.
- Use a clear title and one dominant action at most.
- Keep card content short and scannable.
- Do not make a card fully clickable if it contains multiple independent actions.

### 9.2 Buttons

- One primary button per task area.
- Use specific action labels.
- Secondary and tertiary actions must be visually quieter.
- Preserve button dimensions during loading.
- Disabled states must explain why when the reason is not self-evident.
- Never use a button style for ordinary navigation links.

### 9.3 Forms

- Every input has a persistent visible label.
- Place errors next to the relevant input.
- Preserve values after recoverable errors.
- Keep forms focused and group related fields.
- Do not expose unnecessary fields in the initial view.
- Use progressive disclosure for optional or advanced fields.

### 9.4 Tables and lists

- Use tables for comparison and structured teacher workflows.
- Respect the maximum 6-column guidance from UXA v2.1.
- On mobile, stack records or use an intentional, discoverable horizontal-scroll pattern.
- Do not use spreadsheet-like tables for student learning content unless required by the task.

### 9.5 Progress and status

- Pair progress visuals with clear labels or values.
- Use consistent status language and appearance.
- Do not imply precision unsupported by data.
- Never show missing data as zero.
- Keep progress and reward systems from competing with the primary task.

### 9.6 Feedback, empty and error states

Every page must define relevant states:

- Initial
- Loading
- Empty
- No results
- Success
- Error
- Offline
- Submitting / Pending
- Saved
- Permission denied
- Expired session
- Completed

Follow UXA v2.1 system-state rules:

- Never claim an action was saved before server confirmation.
- Never show zero as a replacement for unavailable data.
- Explain what happened, what was preserved and what the user can do next.
- Do not use raw technical error codes in user-facing copy.
- Preserve entered data where recovery is possible.

---

## 10. Student experience requirements

### 10.1 Student Home

The home page must quickly answer: **What should I do next?**

Priority order:

1. Most urgent teacher assignment, when present.
2. Resume an unfinished practice session, when present.
3. A small number of relevant recommendations (3–5 as defined by UXA v2.1).
4. Personal goals, coins, streaks or achievements as supporting content.

Do not place all four areas at equal visual weight.

The initial mobile viewport should prioritize the most relevant action. Secondary recommendations and reward details should be lower on the page or available through a deliberate detail action.

### 10.2 Skill Library

The library is for discovery and selection, not active question solving.

- Preserve the approved taxonomy: Subject → Grade → Topic → Subtopic → Skill → Question.
- Make the current level of the hierarchy clear.
- Avoid displaying every level as a dense nested list at once.
- Provide a clear route back to the parent level.
- Do not invent student-facing skill preview behavior. `STU-03` appears in the page inventory but its existence/behavior is not confirmed in UXA v2.1. Treat it as **[OPEN DECISION]** until approved.
- Do not confuse student skill discovery with the teacher's confirmed `TCH-08` skill preview.

### 10.3 Practice Session

**[LOCKED PRODUCT RULE]**

- One question at a time.
- The question and answer controls are the dominant content.
- No return to a previous question.
- No editing a submitted answer.
- No retry after an incorrect answer.
- Timer is elapsed time (count-up), never a countdown.
- Hint does not reduce SmartScore.
- Local answer validation follows the question-type contract.
- Feedback shows the result, correct answer, explanation and method where specified.
- Continue is explicit; never auto-advance.
- Session ends at SmartScore 100 or when the student exits, according to the approved flow.
- Confirmed answers are preserved and resume behavior follows the technical persistence rules.

Visual requirements:

- Remove unrelated navigation and decorative clutter from the practice environment.
- Do not show large reward panels beside the question.
- Keep progress, score and elapsed time secondary and compact.
- Make the answer interaction easy to understand and operate on mobile.
- Do not introduce motion that delays answering.
- Do not add a 3D scene behind the question or answer controls.
- Do not invent question types or alter answer contracts.

### 10.4 Feedback and summary

- Feedback must teach, not merely judge.
- Clearly distinguish correct/incorrect status from the explanation.
- Use supportive, neutral language.
- Show the correct answer and method where the approved question contract requires them.
- Keep reward celebration secondary to understanding the answer.
- Session Summary must communicate the outcome and one clear next action.
- Do not invent historical analytics or metrics that are not supported.

### 10.5 Onboarding

The new approved first-run sequence is:

1. Avatar selection.
2. Guided tour.
3. Student Home.

Avatar selection requirements:

- Avatar is cosmetic and must not imply ability, grade, gender performance or academic level.
- The selection screen should be visual-first and simple.
- Show a manageable number of options at once; the exact count is **[OPEN DECISION]**.
- Make the selected state unmistakable without relying on color alone.
- Do not require extensive customization.
- The ability to change the avatar later is a **[DESIGN RECOMMENDATION]** pending product confirmation.

Guided tour requirements:

- Explain only the essential parts of the product.
- Use short, contextual steps anchored to real interface elements.
- Avoid covering the entire screen with a large blocking overlay.
- Show clear progress through the tour.
- Provide Back, Next and Finish controls.
- Recommended: allow Skip and replay later.
- Do not explain every feature or every navigation item.
- The tour must work on 360px mobile without obscuring the relevant control.
- Respect reduced-motion settings.

---

## 11. Teacher experience requirements

Teacher interfaces support more complex operational tasks, but should still be easy to scan.

### 11.1 Teacher Home

- Keep the active class visible and easy to switch.
- Prioritize the most actionable class information.
- Provide direct access to frequent teacher actions defined in UXA v2.1.
- Avoid showing every analytics metric on the home page.
- Use compact summaries that lead to detailed views.
- Every analytics surface should end in a meaningful teaching action.

### 11.2 Skill discovery and preview

- Preserve teacher skill-library and preview behavior.
- Preview must support the teacher's decision about whether a skill is appropriate.
- Do not let the preview become a dense content dump.
- Keep learning objective and sample questions easy to locate.
- Any additional preview content, such as answer keys or explanations, remains subject to the open product decision.

### 11.3 Assignment creation and tracking

Preserve the approved sequence:

Recipient → Skills → Schedule / Instructions → Review → Publish.

- Keep the current class context visible.
- Preserve selections when moving backward.
- Warn about duplicate assignments without blocking where UXA v2.1 says the warning is non-blocking.
- Do not allow invalid past deadlines.
- Do not claim publication before server confirmation.
- Use a review step before publishing.
- Tracking should distinguish aggregate and per-student views.
- Do not use judgmental labels such as “weak student”.
- Do not invent teacher permissions or secondary-teacher behavior where it remains open.

### 11.4 Analytics

- Show only metrics with defined meaning, denominator and time window.
- Distinguish no data from zero.
- Use visualizations only when they make a comparison or trend easier to understand.
- Avoid dashboard overload.
- End the analysis with a relevant next action.
- Keep detailed definitions and secondary breakdowns one level deeper.

---

## 12. Motion and interaction

Motion must support orientation, feedback and continuity.

### 12.1 Allowed motion roles

- Short transitions between related states.
- Small hover/press feedback on pointer devices.
- Meaningful achievement moments.
- Subtle 3D character idle motion in non-critical contexts.
- Guided-tour transitions that clarify the current step.

### 12.2 Disallowed or discouraged

- Continuous decorative movement near questions.
- Large parallax effects on task-focused pages.
- Repeated confetti or full-screen reward interruptions.
- Long transitions that delay a primary action.
- Motion as the only signal of success or failure.
- Auto-advancing educational feedback.

Honor `prefers-reduced-motion` and provide static alternatives.

---

## 13. Accessibility, safety and age-appropriate design

Target WCAG 2.2 AA, subject to validation.

- Minimum text and component contrast must be verified against actual tokens.
- Do not communicate status through color alone.
- Use semantic controls and logical keyboard order.
- Make focus visible and unobscured.
- Provide accessible names for icon-only controls.
- Keep touch targets at least 44×44 CSS px where practical.
- Use age-appropriate Persian.
- Avoid manipulative urgency, shame, public comparison or pressure.
- Do not use streaks, goals or rewards to punish absence.
- Avoid excessive notifications and attention-grabbing animations.
- Do not expose one student's performance to other students.
- Do not use avatar appearance to infer academic ability or personal traits.

---

## 14. Performance and implementation constraints

The 3D direction must not compromise performance or task completion.

- Prefer optimized, appropriately sized assets.
- Lazy-load non-critical 3D and illustration assets.
- Avoid loading large 3D scenes on every page.
- Use static image fallbacks where needed.
- Avoid unnecessary layout shifts.
- Keep interactions responsive on mid-range mobile devices.
- Do not block the first meaningful interaction while decorative assets load.
- Test the practice flow with 3D and decorative assets disabled; core functionality must remain complete.
- Use existing project technology and architecture unless an explicit technical change is approved.

**[TECHNICAL VALIDATION]** Performance budgets, asset formats, device test matrix and loading thresholds must be agreed with engineering.

---

## 15. Required output from the AI design agent

The agent must not jump directly into polished screens without first understanding the current implementation and the product rules.

### Phase A — Audit

1. Inspect the current repository and identify the app framework, routes, components, tokens and existing assets.
2. Inspect every page in the current product, including internal pages and role-specific states.
3. Compare each page against UXA v2.1, approved demo scope and this document.
4. Identify information overload, repeated content, weak hierarchy, inconsistent components, mobile issues and visual inconsistency.
5. Report findings before making broad structural changes.

### Phase B — Experience structure

For every in-scope page, produce:

- Page ID and page name.
- Primary user role.
- User goal.
- Entry points.
- Primary action.
- Secondary actions.
- Essential information.
- Supporting information.
- Content to hide, defer or remove.
- Above-the-fold content budget.
- Mobile-first layout structure.
- Tablet and desktop adaptation.
- Loading, empty, error, success and permission states as applicable.
- Interaction rules.
- Accessibility notes.
- Dependencies and unresolved decisions.
- Acceptance criteria.

### Phase C — Visual direction

Before applying a full visual redesign:

1. Create a small visual exploration for the 3D style.
2. Show how the approved palette is applied to real interface components.
3. Demonstrate one student page and one teacher page.
4. Demonstrate the mobile-first composition.
5. Demonstrate the practice screen's focused, low-distraction treatment.
6. Validate hierarchy and density before scaling the system to all pages.

### Phase D — Implementation

- Reuse and consolidate components.
- Preserve product behavior.
- Use the existing brand and typography tokens.
- Implement mobile first.
- Keep all pages responsive.
- Avoid placeholder interactions and fake data.
- Do not invent missing content or product rules.
- Keep the code maintainable and consistent with the existing project.

### Phase E — QA and delivery

Test at:

- 360px
- 390px
- 430px
- 768px
- 1024px
- 1280px
- 1440px

Deliver:

- Updated page inventory and implementation map.
- Page-by-page audit findings.
- Journey Maps for Student and Teacher.
- Task Specifications for every in-scope page.
- Visual direction / 3D art-direction sample.
- Updated responsive implementation.
- List of unresolved decisions.
- QA report with screenshots or reproducible notes.
- Build and runtime status.

---

## 16. Acceptance criteria

The redesign is not successful merely because it looks more colorful or uses 3D.

It is successful when:

1. The primary task on each page is immediately understandable.
2. The first mobile viewport is visibly less crowded than the current version.
3. Secondary information is available without competing with the primary task.
4. No approved product capability or business rule has been silently removed or changed.
5. Student pages feel engaging but remain calm and focused.
6. Teacher pages are scannable and operationally efficient.
7. 3D assets are consistent, purposeful and performant.
8. Existing brand colors and typography remain intact.
9. Mobile layouts are designed intentionally and work without horizontal page overflow.
10. Practice remains distraction-free and follows all approved session rules.
11. Gamification supports personal progress and never introduces public ranking.
12. Every implemented page includes the relevant loading, empty, error and success states.
13. Persian, RTL, mixed-direction content and mathematical notation are verified in the actual UI.
14. All visible controls work as labeled.
15. The project builds and runs without new errors.

---

## 17. Explicit prohibitions

The AI agent MUST NOT:

- Replace the Naranj brand palette or typography.
- Introduce public leaderboards, rankings or student-versus-student competition.
- Invent new roles, permissions, screens, question types or product policies.
- Treat `STU-03` student Skill Preview as confirmed; it remains an open decision in UXA v2.1.
- Confuse student `STU-03` with teacher `TCH-08`.
- Change the practice session's forward-only behavior.
- Add countdown timers or time pressure to practice.
- Add retry behavior after a submitted answer unless product rules are explicitly changed.
- Auto-advance after feedback.
- Put distracting 3D decoration behind math questions or answer controls.
- Use 3D in every card.
- Increase information density to make desktop pages appear more “complete”.
- Hide critical actions or error recovery behind hover.
- use color alone to communicate status.
- Create fake metrics or show unavailable values as zero.
- Add unsupported navigation destinations.
- Implement unresolved product decisions as if they were confirmed.

---

## 18. Final instruction

**Redesign Naranj to be visually richer, more engaging and unmistakably recognizable, while making every screen simpler to understand and easier to use.**

The target is not “more UI”. The target is **less cognitive load, stronger hierarchy, more purposeful color, coherent 3D personality and faster access to the user's next action.**

When uncertain, preserve the product rule, reduce visual noise, disclose information progressively and report the unresolved decision instead of inventing it.
