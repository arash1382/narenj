# Naranj — Color System Specification

**Version:** 1.0.0  
**Status:** Proposed design-system baseline for demo implementation  
**Language:** Token names are English for code consistency; product content is Persian (RTL).

## 1. Color direction

Naranj should feel warm, optimistic, energetic and trustworthy without looking like a toy interface. The palette combines a mature citrus orange with a calm teal, warm neutrals and a restrained golden accent.

- **Primary orange:** `#E9782B` — medium-depth, warm, recognizably citrus. It is neither fluorescent nor brown/dark.
- **Secondary teal:** `#218C83` — balances the orange and supports learning, navigation and progress states.
- **Accent yellow:** `#F2C14E` — used sparingly for rewards, stars and celebratory moments.
- **Warm neutral scale:** reduces the clinical feel of pure grey and supports long learning sessions.

The selected palette is a proposed starting point for the demo. It should be validated against the actual logo, mascot renders and representative screens before being treated as immutable brand governance.

## 2. Brand palette

### Primary — Citrus Orange

| Token | Hex | Intended role |
|---|---|---|
| `primary.50` | `#FFF6EF` | Very soft orange-tinted surface |
| `primary.100` | `#FCE9DA` | Selected backgrounds, subtle highlights |
| `primary.200` | `#F8D1B5` | Soft borders and decorative fills |
| `primary.300` | `#F3B287` | Illustration accents, disabled fills |
| `primary.400` | `#ED9257` | Secondary emphasis |
| `primary.500` | `#E9782B` | Main brand orange |
| `primary.600` | `#D9651B` | Hover / stronger emphasis |
| `primary.700` | `#B94F14` | Active / pressed |
| `primary.800` | `#943F12` | Deep brand accent |
| `primary.900` | `#71320F` | Deepest orange tone |

**Use `primary.500` for:** primary CTA fills when paired with a sufficiently dark foreground, brand marks, active progress accents and key highlights.  
**Do not use it for:** long text, large uninterrupted page backgrounds, or tiny orange text on white.

### Secondary — Learning Teal

| Token | Hex | Intended role |
|---|---|---|
| `secondary.50` | `#EFF9F7` | Teal-tinted surface |
| `secondary.100` | `#D9F0EC` | Selection and information panels |
| `secondary.200` | `#B5E1DA` | Soft borders |
| `secondary.300` | `#83C9BE` | Supporting graphics |
| `secondary.400` | `#4EAA9D` | Mid-tone accent |
| `secondary.500` | `#218C83` | Secondary actions and supporting highlights |
| `secondary.600` | `#18756E` | Hover / links |
| `secondary.700` | `#155E59` | Active / pressed |
| `secondary.800` | `#144C49` | Deep accent |
| `secondary.900` | `#123F3D` | Deepest teal |

Use teal to balance orange. It can identify secondary actions, links, progress indicators and selected supporting navigation. Do not make every component two-tone.

### Accent — Citrus Gold

| Token | Hex | Intended role |
|---|---|---|
| `accent.50` | `#FFFAE8` | Reward background |
| `accent.100` | `#FFF1C2` | Soft celebratory surface |
| `accent.200` | `#FBE18A` | Stars and badges |
| `accent.300` | `#F5D05D` | Illustration highlights |
| `accent.400` | `#F2C14E` | Main accent gold |
| `accent.500` | `#DFA92D` | Stronger gold accent |
| `accent.600` | `#B9851F` | Deep gold |
| `accent.700` | `#8E641B` | Deepest gold |

Gold is a **limited accent**, mainly for coins, stars, rewards and success celebrations. It is not a competing primary color.

## 3. Neutral palette

| Token | Hex | Intended role |
|---|---|---|
| `neutral.0` | `#FFFFFF` | Pure white |
| `neutral.50` | `#FAF9F6` | App canvas |
| `neutral.100` | `#F3F1EC` | Subtle panels |
| `neutral.200` | `#E7E3DC` | Default borders / dividers |
| `neutral.300` | `#D5D0C7` | Strong borders |
| `neutral.400` | `#AAA49A` | Disabled text / icons |
| `neutral.500` | `#79736B` | Tertiary text |
| `neutral.600` | `#5F5A53` | Secondary text |
| `neutral.700` | `#45413C` | Strong text |
| `neutral.800` | `#2E2B27` | Primary text |
| `neutral.900` | `#1F1D1A` | Highest emphasis |
| `neutral.950` | `#141311` | Deep inverse surfaces |

Warm neutrals are the default foundation. Avoid using pure black for ordinary text and avoid stacking too many subtly different grey surfaces.

## 4. Semantic status colors

Status colors communicate meaning and must not be used as decoration.

### Success

- Background: `#EFF8F1` (`success.50`)
- Soft background: `#D9EEDC` (`success.100`)
- Main: `#2F855A` (`success.500`)
- Hover / strong: `#276C4A` (`success.600`)
- Deep: `#20583D` (`success.700`)

Use for correct answers, completed tasks, saved confirmation and positive progress.

### Warning

- Background: `#FFF7E8` (`warning.50`)
- Soft background: `#FCE8BF` (`warning.100`)
- Main: `#A96812` (`warning.500`)
- Hover / strong: `#87520E` (`warning.600`)
- Deep: `#68400D` (`warning.700`)

Use for approaching deadlines, caution, incomplete steps and non-blocking attention.

### Danger / Error

- Background: `#FFF1F0` (`danger.50`)
- Soft background: `#F8DAD7` (`danger.100`)
- Main: `#C4473A` (`danger.500`)
- Hover / strong: `#A9362D` (`danger.600`)
- Deep: `#852B25` (`danger.700`)

Use for validation errors, failed actions, destructive actions and critical problems. Do not use danger red for ordinary incorrect practice answers if the learning feedback should remain encouraging; use neutral instructional feedback or a gentle warning treatment where appropriate.

### Information

- Background: `#EFF6FD` (`info.50`)
- Soft background: `#DCEBFA` (`info.100`)
- Main: `#3478B8` (`info.500`)
- Hover / strong: `#285F95` (`info.600`)
- Deep: `#204B75` (`info.700`)

Use for tips, system information, help messages and neutral notices.

## 5. Semantic UI tokens

### Surfaces

| Token | Hex | Use |
|---|---|---|
| `surface.canvas` | `#FAF9F6` | Overall app background |
| `surface.page` | `#FFFFFF` | Main content surface |
| `surface.subtle` | `#F3F1EC` | Quiet grouped content |
| `surface.raised` | `#FFFFFF` | Cards, menus, popovers |
| `surface.sunken` | `#EDEAE4` | Inset controls and recessed regions |
| `surface.inverse` | `#2E2B27` | Dark contrast panel |

### Text

| Token | Hex | Use |
|---|---|---|
| `text.primary` | `#2E2B27` | Main body and heading text |
| `text.secondary` | `#5F5A53` | Supporting copy |
| `text.tertiary` | `#79736B` | Metadata; check contrast for small text |
| `text.disabled` | `#AAA49A` | Disabled labels only; not essential information |
| `text.inverse` | `#FFFFFF` | Text on sufficiently dark surfaces |
| `text.link` | `#18756E` | Inline links |
| `text.linkHover` | `#155E59` | Hovered links |
| `text.onPrimary` | `#1F1D1A` | Foreground on primary orange |
| `text.onSecondary` | `#FFFFFF` | Foreground on secondary teal |
| `text.onDanger` | `#FFFFFF` | Foreground on danger |
| `text.onSuccess` | `#FFFFFF` | Foreground on success |
| `text.onInfo` | `#FFFFFF` | Foreground on info |

### Borders and focus

| Token | Hex | Use |
|---|---|---|
| `border.default` | `#E7E3DC` | Standard component borders |
| `border.strong` | `#D5D0C7` | High-emphasis borders |
| `border.subtle` | `#F3F1EC` | Subtle separators |
| `border.focus` | `#218C83` | Focused controls |
| `focus.ring` | `#218C83` | Keyboard focus ring |
| `focus.ringOnDark` | `#F5D05D` | Focus ring on dark surfaces |

### Interactive states

| Component state | Token | Hex |
|---|---|---|
| Primary default | `interactive.primary` | `#E9782B` |
| Primary hover | `interactive.primaryHover` | `#D9651B` |
| Primary pressed | `interactive.primaryActive` | `#B94F14` |
| Primary disabled fill | `interactive.primaryDisabled` | `#F3B287` |
| Secondary default | `interactive.secondary` | `#218C83` |
| Secondary hover | `interactive.secondaryHover` | `#18756E` |
| Secondary pressed | `interactive.secondaryActive` | `#155E59` |
| Secondary disabled fill | `interactive.secondaryDisabled` | `#83C9BE` |
| Selected background | `interactive.selection` | `#FCE9DA` |
| Selected border | `interactive.selectionBorder` | `#E9782B` |

Disabled controls should also have reduced emphasis and must not be the only way to communicate availability. Do not rely on color alone to distinguish hover, pressed, selected or disabled states.

## 6. Recommended component mapping

| UI element | Recommended color treatment |
|---|---|
| Main CTA | Primary orange with `text.onPrimary` |
| Secondary CTA | Teal with white text |
| Tertiary button | Neutral surface with primary/teal text |
| Navigation active item | `primary.50` surface + `primary.700` text or teal treatment |
| Links | `text.link` |
| Main page | `surface.canvas` |
| Cards | `surface.raised` |
| Card borders | `border.default` |
| Input default | White surface + `border.strong` |
| Input focus | `border.focus` + visible focus ring |
| Input error | Danger border + danger helper text |
| Correct answer | Success treatment, icon and explicit confirmation |
| Incorrect answer | Supportive feedback; avoid harsh red as the default |
| Progress | Teal or primary orange; define meaning consistently |
| Coins / stars / rewards | Accent gold |
| Deadline approaching | Warning |
| Critical system error | Danger |

## 7. Accessibility and contrast rules

Target WCAG 2.2 AA:

- Normal text: contrast ratio at least **4.5:1**.
- Large text: at least **3:1**.
- Meaningful UI boundaries and graphical controls: at least **3:1** against adjacent colors where WCAG requires it.
- Keyboard focus must be clearly visible.
- Never convey correctness, status, selection or errors by color alone.

Important practical note: the primary orange `#E9782B` is a brand color, not a safe white-text background for small text. Use dark `text.onPrimary` on it. For a white-text orange button, use the deeper `primary.700` (`#B94F14`) and validate contrast in implementation.

Recommended foreground pairings:
- `#2E2B27` on `#FFFFFF` or `#FAF9F6`.
- `#1F1D1A` on `#E9782B`.
- `#FFFFFF` on `#18756E`.
- `#FFFFFF` on `#276C4A`.
- `#FFFFFF` on `#A9362D`.
- `#FFFFFF` on `#285F95`.

Do not use `neutral.400` or `neutral.500` for essential small text on white without checking contrast.

## 8. Usage proportions

A useful starting balance for typical screens:

- 65–75% warm neutral surfaces.
- 15–20% primary orange and its tints.
- 8–12% secondary teal and its tints.
- 2–5% accent gold and semantic colors.

These are visual balancing guidelines, not strict per-screen quotas.

## 9. Design consistency rules

1. Orange owns the brand. Teal supports it. Gold celebrates.
2. Keep large surfaces neutral; reserve saturated colors for actions, feedback and meaningful emphasis.
3. Use one dominant colored action per screen whenever possible.
4. Use semantic colors consistently across the student and teacher experiences.
5. Keep all status colors paired with labels/icons.
6. Do not introduce new hex values directly in components. Add a named token first.
7. For illustrations and the mascot, colors may be more expressive, but interactive UI must follow semantic tokens.
8. The demo uses a light theme baseline. Dark mode is not included in this specification.

## 10. Open validation items

Before final design-system sign-off:
- Test the palette against the final Naranj logo and mascot.
- Check contrast in actual button, input, badge, chart and feedback components.
- Validate colors on common laptop and tablet displays.
- Confirm whether the final product needs a dark theme.
- Review semantic feedback colors with the educational team, especially the treatment of incorrect answers.

Until these checks are complete, treat this as **Color System v1.0 — Demo Baseline**, not immutable brand specification.
