# NARANJ — Character and Onboarding Specification

## Character governance
- Use the supplied approved Naranj mascot and avatar assets as the identity reference.
- Do not redesign, replace, distort or create inconsistent mascot variants.
- Mascot is a recognizable helper and should not appear as decoration in every component.
- Student-facing characters must remain age-appropriate and culturally appropriate. Girls must have appropriate hair coverage in all illustrations and avatar designs.
- Do not introduce new character lore, dialogue or personality traits unless approved.

## Onboarding — binding owner override
The latest explicit product-owner decision is:
1. Student selects an avatar.
2. Student completes an interactive guided tour.

This overrides older documents that described avatar selection as optional or discouraged a mandatory avatar wizard.

## Implementation constraints
- Make avatar choice understandable and visually comparable.
- Preserve the selected avatar across the onboarding journey and subsequent authenticated sessions according to the confirmed account model.
- Provide clear progress through the tour and a clear completion state.
- The tour must teach real interface actions, not be a sequence of promotional slides.
- Do not invent tour steps, rewards, skip rules, avatar editing rules or persistence behavior where the product sources do not specify them; add these to the open decision register.
- Ensure the onboarding is responsive, RTL-first, keyboard accessible and usable with reduced motion.

## Teacher onboarding
Teacher onboarding is separate from the student avatar/tour journey. Do not reuse student-specific steps for teachers.


## Illustration categories and role-based asset selection

**Owner-provided direction:** Illustration assets are organized into distinct categories. The UI must select the appropriate illustration family according to the user's selected role/profile context rather than displaying one generic illustration to everyone.

### Current category taxonomy

| Asset category | Intended context | Selection rule |
|---|---|---|
| `default` | Neutral/default state where no more specific role or profile category applies | Use only as an intentional neutral fallback |
| `boy` | Boy student profile | Use the boy illustration family |
| `girl` | Girl student profile | Use the girl illustration family |
| `parent` | Parent-facing role/context | Use parent-specific illustrations; support mother and father variants as separate subcategories |
| `teacher` | Teacher role/context | Use the teacher illustration family |

### Parent variants

The parent category must not be treated as a single fixed gender presentation. Its asset family must support at least:
- `parent/mother`
- `parent/father`

If the product later supports a different parent/guardian representation, add it as a separately named variant rather than silently reusing an unrelated illustration.

### Selection logic

1. Resolve the active account role first (student, parent, teacher).
2. For a student, resolve the selected student profile/avatar category (`boy` or `girl`) where that context is available.
3. For a parent, resolve the selected parent variant (`mother` or `father`) where the UI needs a parent illustration.
4. For a teacher, use the `teacher` category.
5. Use `default` only when the context is genuinely neutral or the specific asset is unavailable and a fallback is explicitly acceptable.
6. Never infer the illustration category from the user's name, appearance, or other unrelated personal data.
7. Keep asset selection separate from authorization and product-role permissions. An illustration category must never determine what a user can access.

### Variant support

Each category may contain multiple approved illustration variants. The implementation must therefore support a category-to-asset collection, not a single hard-coded image per role.

Recommended asset organization (proposed naming convention):

```text
illustrations/
  default/
    default-01.webp
    default-02.webp
  student/
    boy/
      boy-01.webp
      boy-02.webp
    girl/
      girl-01.webp
      girl-02.webp
  parent/
    mother/
      mother-01.webp
      mother-02.webp
    father/
      father-01.webp
      father-02.webp
  teacher/
    teacher-01.webp
    teacher-02.webp
```

This is a proposed folder convention, not a claim that these exact files already exist. Preserve the actual supplied asset filenames if they differ.

### Popup / modal behavior

- Popups and onboarding surfaces must request an illustration using an explicit semantic key (for example `student.girl`, `parent.mother`, `teacher`).
- Do not scatter direct image paths across page components.
- Use a shared illustration registry or resolver so the same role/context always maps consistently.
- If multiple variants exist, choose one deterministically for a given context or use a documented rotation rule. Do not randomly change a user's illustration on every render.
- Keep illustration crop, scale, framing, background and safe area consistent within a family so variants can be swapped without breaking layout.
- The illustration is decorative/contextual; it must not obscure the popup title, explanation or primary action.
- On small screens, preserve the face and defining character features when cropping; use `object-position` or a dedicated mobile asset if required.

### Cultural and identity constraints

- Girl student illustrations must retain appropriate hair coverage, consistent with the approved Naranj visual direction.
- Do not convert parent illustrations into student illustrations or teacher illustrations by changing only labels.
- Do not create new character designs or demographic representations without approval.
- Do not assume the `default` asset is appropriate for every unknown role. If the role is unknown, use a neutral non-character treatment unless the product owner approves the default character as a fallback.

### Open data requirements

The current screenshot establishes the category labels `boy`, `default`, `girl`, `parent`, and `teacher`. It does not establish the final asset count per category, exact parent selection UI, whether parent gender is stored as a profile attribute, or the selection rules for mixed/guardian households. Keep those details open until the asset inventory and account model confirm them.


## Latest owner clarification — MVP role and illustration scope

- The MVP role scope is **Student and Teacher**.
- The user enters through the school-code flow; the system determines whether the account is a student or teacher. Do not add a separate role chooser if the authenticated school/account context already resolves the role.
- The parent role is not an MVP focus. Keep a future-compatible `parent` illustration category in the asset taxonomy, but do not build parent-specific product flows, onboarding or menus now.
- The number of illustrations differs by category. Do not force equal variant counts or create duplicates.
- The illustration family is selected after the account/profile context is known. It must never determine permissions or role.
