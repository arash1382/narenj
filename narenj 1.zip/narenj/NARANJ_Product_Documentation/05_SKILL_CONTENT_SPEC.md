# Skill Content Specification — source workbook audit

- Source: `skill form - v5.ods`
- This document transcribes workbook data; it does not fabricate missing IDs, prerequisites, ordering, or question assignments.

## Sheet: main topics

- Physical rows: 502
- Non-empty rows: 500

### Row 1
- Column 1: شناسه درس
- Column 2: کد مبحث
- Column 3: عنوان مبحث
- Column 4: ترتیب الویت بندی شده مباحث

### Row 2
- Column 1: topic slug
- Column 2: topic code: به فرم 3 حرف انگلیسی
- Column 3: topic name

### Row 3
- Column 1: math
- Column 2: A
- Column 3: درک اعداد

### Row 4
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات

### Row 5
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی

### Row 6
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری

### Row 7
- Column 1: math
- Column 2: E
- Column 3: آمار و احتمال

### Row 8
- Column 1: math
- Column 2: F
- Column 3: سواد مالی

### Row 9
- Column 1: math
- Column 2: G
- Column 3: حل مسئله

### Row 10
- Column 1: math
- Column 2: H
- Column 3: جبر و الگوها

### Row 11
- Column 1: math
- Column 2: I
- Column 3: منطق و استدلال

### Row 12
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد

### Row 13
- Column 1: math
- Column 2: K

### Row 14
- Column 1: math

### Row 15
- Column 1: math

### Row 16
- Column 1: math

### Row 17
- Column 1: math

### Row 18
- Column 1: math

### Row 19
- Column 1: math

### Row 20
- Column 1: math

### Row 21
- Column 1: math

### Row 22
- Column 1: math

### Row 23
- Column 1: math

### Row 24
- Column 1: math

### Row 25
- Column 1: math

### Row 26
- Column 1: math

### Row 27
- Column 1: math

### Row 28
- Column 1: math

### Row 29
- Column 1: math

### Row 30
- Column 1: math

### Row 31
- Column 1: math

### Row 32
- Column 1: math

### Row 33
- Column 1: math

### Row 34
- Column 1: math

### Row 35
- Column 1: math

### Row 36
- Column 1: math

### Row 37
- Column 1: math

### Row 38
- Column 1: math

### Row 39
- Column 1: math

### Row 40
- Column 1: math

### Row 41
- Column 1: math

### Row 42
- Column 1: math

### Row 43
- Column 1: math

### Row 44
- Column 1: math

### Row 45
- Column 1: math

### Row 46
- Column 1: math

### Row 47
- Column 1: math

### Row 48
- Column 1: math

### Row 49
- Column 1: math

### Row 50
- Column 1: math

### Row 51
- Column 1: math

### Row 52
- Column 1: math

### Row 53
- Column 1: math

### Row 54
- Column 1: math

### Row 55
- Column 1: math

### Row 56
- Column 1: math

### Row 57
- Column 1: math

### Row 58
- Column 1: math

### Row 59
- Column 1: math

### Row 60
- Column 1: math

### Row 61
- Column 1: math

### Row 62
- Column 1: math

### Row 63
- Column 1: math

### Row 64
- Column 1: math

### Row 65
- Column 1: math

### Row 66
- Column 1: math

### Row 67
- Column 1: math

### Row 68
- Column 1: math

### Row 69
- Column 1: math

### Row 70
- Column 1: math

### Row 71
- Column 1: math

### Row 72
- Column 1: math

### Row 73
- Column 1: math

### Row 74
- Column 1: math

### Row 75
- Column 1: math

### Row 76
- Column 1: math

### Row 77
- Column 1: math

### Row 78
- Column 1: math

### Row 79
- Column 1: math

### Row 80
- Column 1: math

### Row 81
- Column 1: math

### Row 82
- Column 1: math

### Row 83
- Column 1: math

### Row 84
- Column 1: math

### Row 85
- Column 1: math

### Row 86
- Column 1: math

### Row 87
- Column 1: math

### Row 88
- Column 1: math

### Row 89
- Column 1: math

### Row 90
- Column 1: math

### Row 91
- Column 1: math

### Row 92
- Column 1: math

### Row 93
- Column 1: math

### Row 94
- Column 1: math

### Row 95
- Column 1: math

### Row 96
- Column 1: math

### Row 97
- Column 1: math

### Row 98
- Column 1: math

### Row 99
- Column 1: math

### Row 100
- Column 1: math

### Row 101
- Column 1: math

### Row 102
- Column 1: math

### Row 103
- Column 1: math

### Row 104
- Column 1: math

### Row 105
- Column 1: math

### Row 106
- Column 1: math

### Row 107
- Column 1: math

### Row 108
- Column 1: math

### Row 109
- Column 1: math

### Row 110
- Column 1: math

### Row 111
- Column 1: math

### Row 112
- Column 1: math

### Row 113
- Column 1: math

### Row 114
- Column 1: math

### Row 115
- Column 1: math

### Row 116
- Column 1: math

### Row 117
- Column 1: math

### Row 118
- Column 1: math

### Row 119
- Column 1: math

### Row 120
- Column 1: math

### Row 121
- Column 1: math

### Row 122
- Column 1: math

### Row 123
- Column 1: math

### Row 124
- Column 1: math

### Row 125
- Column 1: math

### Row 126
- Column 1: math

### Row 127
- Column 1: math

### Row 128
- Column 1: math

### Row 129
- Column 1: math

### Row 130
- Column 1: math

### Row 131
- Column 1: math

### Row 132
- Column 1: math

### Row 133
- Column 1: math

### Row 134
- Column 1: math

### Row 135
- Column 1: math

### Row 136
- Column 1: math

### Row 137
- Column 1: math

### Row 138
- Column 1: math

### Row 139
- Column 1: math

### Row 140
- Column 1: math

### Row 141
- Column 1: math

### Row 142
- Column 1: math

### Row 143
- Column 1: math

### Row 144
- Column 1: math

### Row 145
- Column 1: math

### Row 146
- Column 1: math

### Row 147
- Column 1: math

### Row 148
- Column 1: math

### Row 149
- Column 1: math

### Row 150
- Column 1: math

### Row 151
- Column 1: math

### Row 152
- Column 1: math

### Row 153
- Column 1: math

### Row 154
- Column 1: math

### Row 155
- Column 1: math

### Row 156
- Column 1: math

### Row 157
- Column 1: math

### Row 158
- Column 1: math

### Row 159
- Column 1: math

### Row 160
- Column 1: math

### Row 161
- Column 1: math

### Row 162
- Column 1: math

### Row 163
- Column 1: math

### Row 164
- Column 1: math

### Row 165
- Column 1: math

### Row 166
- Column 1: math

### Row 167
- Column 1: math

### Row 168
- Column 1: math

### Row 169
- Column 1: math

### Row 170
- Column 1: math

### Row 171
- Column 1: math

### Row 172
- Column 1: math

### Row 173
- Column 1: math

### Row 174
- Column 1: math

### Row 175
- Column 1: math

### Row 176
- Column 1: math

### Row 177
- Column 1: math

### Row 178
- Column 1: math

### Row 179
- Column 1: math

### Row 180
- Column 1: math

### Row 181
- Column 1: math

### Row 182
- Column 1: math

### Row 183
- Column 1: math

### Row 184
- Column 1: math

### Row 185
- Column 1: math

### Row 186
- Column 1: math

### Row 187
- Column 1: math

### Row 188
- Column 1: math

### Row 189
- Column 1: math

### Row 190
- Column 1: math

### Row 191
- Column 1: math

### Row 192
- Column 1: math

### Row 193
- Column 1: math

### Row 194
- Column 1: math

### Row 195
- Column 1: math

### Row 196
- Column 1: math

### Row 197
- Column 1: math

### Row 198
- Column 1: math

### Row 199
- Column 1: math

### Row 200
- Column 1: math

### Row 201
- Column 1: math

### Row 202
- Column 1: math

### Row 203
- Column 1: math

### Row 204
- Column 1: math

### Row 205
- Column 1: math

### Row 206
- Column 1: math

### Row 207
- Column 1: math

### Row 208
- Column 1: math

### Row 209
- Column 1: math

### Row 210
- Column 1: math

### Row 211
- Column 1: math

### Row 212
- Column 1: math

### Row 213
- Column 1: math

### Row 214
- Column 1: math

### Row 215
- Column 1: math

### Row 216
- Column 1: math

### Row 217
- Column 1: math

### Row 218
- Column 1: math

### Row 219
- Column 1: math

### Row 220
- Column 1: math

### Row 221
- Column 1: math

### Row 222
- Column 1: math

### Row 223
- Column 1: math

### Row 224
- Column 1: math

### Row 225
- Column 1: math

### Row 226
- Column 1: math

### Row 227
- Column 1: math

### Row 228
- Column 1: math

### Row 229
- Column 1: math

### Row 230
- Column 1: math

### Row 231
- Column 1: math

### Row 232
- Column 1: math

### Row 233
- Column 1: math

### Row 234
- Column 1: math

### Row 235
- Column 1: math

### Row 236
- Column 1: math

### Row 237
- Column 1: math

### Row 238
- Column 1: math

### Row 239
- Column 1: math

### Row 240
- Column 1: math

### Row 241
- Column 1: math

### Row 242
- Column 1: math

### Row 243
- Column 1: math

### Row 244
- Column 1: math

### Row 245
- Column 1: math

### Row 246
- Column 1: math

### Row 247
- Column 1: math

### Row 248
- Column 1: math

### Row 249
- Column 1: math

### Row 250
- Column 1: math

### Row 251
- Column 1: math

### Row 252
- Column 1: math

### Row 253
- Column 1: math

### Row 254
- Column 1: math

### Row 255
- Column 1: math

### Row 256
- Column 1: math

### Row 257
- Column 1: math

### Row 258
- Column 1: math

### Row 259
- Column 1: math

### Row 260
- Column 1: math

### Row 261
- Column 1: math

### Row 262
- Column 1: math

### Row 263
- Column 1: math

### Row 264
- Column 1: math

### Row 265
- Column 1: math

### Row 266
- Column 1: math

### Row 267
- Column 1: math

### Row 268
- Column 1: math

### Row 269
- Column 1: math

### Row 270
- Column 1: math

### Row 271
- Column 1: math

### Row 272
- Column 1: math

### Row 273
- Column 1: math

### Row 274
- Column 1: math

### Row 275
- Column 1: math

### Row 276
- Column 1: math

### Row 277
- Column 1: math

### Row 278
- Column 1: math

### Row 279
- Column 1: math

### Row 280
- Column 1: math

### Row 281
- Column 1: math

### Row 282
- Column 1: math

### Row 283
- Column 1: math

### Row 284
- Column 1: math

### Row 285
- Column 1: math

### Row 286
- Column 1: math

### Row 287
- Column 1: math

### Row 288
- Column 1: math

### Row 289
- Column 1: math

### Row 290
- Column 1: math

### Row 291
- Column 1: math

### Row 292
- Column 1: math

### Row 293
- Column 1: math

### Row 294
- Column 1: math

### Row 295
- Column 1: math

### Row 296
- Column 1: math

### Row 297
- Column 1: math

### Row 298
- Column 1: math

### Row 299
- Column 1: math

### Row 300
- Column 1: math

### Row 301
- Column 1: math

### Row 302
- Column 1: math

### Row 303
- Column 1: math

### Row 304
- Column 1: math

### Row 305
- Column 1: math

### Row 306
- Column 1: math

### Row 307
- Column 1: math

### Row 308
- Column 1: math

### Row 309
- Column 1: math

### Row 310
- Column 1: math

### Row 311
- Column 1: math

### Row 312
- Column 1: math

### Row 313
- Column 1: math

### Row 314
- Column 1: math

### Row 315
- Column 1: math

### Row 316
- Column 1: math

### Row 317
- Column 1: math

### Row 318
- Column 1: math

### Row 319
- Column 1: math

### Row 320
- Column 1: math

### Row 321
- Column 1: math

### Row 322
- Column 1: math

### Row 323
- Column 1: math

### Row 324
- Column 1: math

### Row 325
- Column 1: math

### Row 326
- Column 1: math

### Row 327
- Column 1: math

### Row 328
- Column 1: math

### Row 329
- Column 1: math

### Row 330
- Column 1: math

### Row 331
- Column 1: math

### Row 332
- Column 1: math

### Row 333
- Column 1: math

### Row 334
- Column 1: math

### Row 335
- Column 1: math

### Row 336
- Column 1: math

### Row 337
- Column 1: math

### Row 338
- Column 1: math

### Row 339
- Column 1: math

### Row 340
- Column 1: math

### Row 341
- Column 1: math

### Row 342
- Column 1: math

### Row 343
- Column 1: math

### Row 344
- Column 1: math

### Row 345
- Column 1: math

### Row 346
- Column 1: math

### Row 347
- Column 1: math

### Row 348
- Column 1: math

### Row 349
- Column 1: math

### Row 350
- Column 1: math

### Row 351
- Column 1: math

### Row 352
- Column 1: math

### Row 353
- Column 1: math

### Row 354
- Column 1: math

### Row 355
- Column 1: math

### Row 356
- Column 1: math

### Row 357
- Column 1: math

### Row 358
- Column 1: math

### Row 359
- Column 1: math

### Row 360
- Column 1: math

### Row 361
- Column 1: math

### Row 362
- Column 1: math

### Row 363
- Column 1: math

### Row 364
- Column 1: math

### Row 365
- Column 1: math

### Row 366
- Column 1: math

### Row 367
- Column 1: math

### Row 368
- Column 1: math

### Row 369
- Column 1: math

### Row 370
- Column 1: math

### Row 371
- Column 1: math

### Row 372
- Column 1: math

### Row 373
- Column 1: math

### Row 374
- Column 1: math

### Row 375
- Column 1: math

### Row 376
- Column 1: math

### Row 377
- Column 1: math

### Row 378
- Column 1: math

### Row 379
- Column 1: math

### Row 380
- Column 1: math

### Row 381
- Column 1: math

### Row 382
- Column 1: math

### Row 383
- Column 1: math

### Row 384
- Column 1: math

### Row 385
- Column 1: math

### Row 386
- Column 1: math

### Row 387
- Column 1: math

### Row 388
- Column 1: math

### Row 389
- Column 1: math

### Row 390
- Column 1: math

### Row 391
- Column 1: math

### Row 392
- Column 1: math

### Row 393
- Column 1: math

### Row 394
- Column 1: math

### Row 395
- Column 1: math

### Row 396
- Column 1: math

### Row 397
- Column 1: math

### Row 398
- Column 1: math

### Row 399
- Column 1: math

### Row 400
- Column 1: math

### Row 401
- Column 1: math

### Row 402
- Column 1: math

### Row 403
- Column 1: math

### Row 404
- Column 1: math

### Row 405
- Column 1: math

### Row 406
- Column 1: math

### Row 407
- Column 1: math

### Row 408
- Column 1: math

### Row 409
- Column 1: math

### Row 410
- Column 1: math

### Row 411
- Column 1: math

### Row 412
- Column 1: math

### Row 413
- Column 1: math

### Row 414
- Column 1: math

### Row 415
- Column 1: math

### Row 416
- Column 1: math

### Row 417
- Column 1: math

### Row 418
- Column 1: math

### Row 419
- Column 1: math

### Row 420
- Column 1: math

### Row 421
- Column 1: math

### Row 422
- Column 1: math

### Row 423
- Column 1: math

### Row 424
- Column 1: math

### Row 425
- Column 1: math

### Row 426
- Column 1: math

### Row 427
- Column 1: math

### Row 428
- Column 1: math

### Row 429
- Column 1: math

### Row 430
- Column 1: math

### Row 431
- Column 1: math

### Row 432
- Column 1: math

### Row 433
- Column 1: math

### Row 434
- Column 1: math

### Row 435
- Column 1: math

### Row 436
- Column 1: math

### Row 437
- Column 1: math

### Row 438
- Column 1: math

### Row 439
- Column 1: math

### Row 440
- Column 1: math

### Row 441
- Column 1: math

### Row 442
- Column 1: math

### Row 443
- Column 1: math

### Row 444
- Column 1: math

### Row 445
- Column 1: math

### Row 446
- Column 1: math

### Row 447
- Column 1: math

### Row 448
- Column 1: math

### Row 449
- Column 1: math

### Row 450
- Column 1: math

### Row 451
- Column 1: math

### Row 452
- Column 1: math

### Row 453
- Column 1: math

### Row 454
- Column 1: math

### Row 455
- Column 1: math

### Row 456
- Column 1: math

### Row 457
- Column 1: math

### Row 458
- Column 1: math

### Row 459
- Column 1: math

### Row 460
- Column 1: math

### Row 461
- Column 1: math

### Row 462
- Column 1: math

### Row 463
- Column 1: math

### Row 464
- Column 1: math

### Row 465
- Column 1: math

### Row 466
- Column 1: math

### Row 467
- Column 1: math

### Row 468
- Column 1: math

### Row 469
- Column 1: math

### Row 470
- Column 1: math

### Row 471
- Column 1: math

### Row 472
- Column 1: math

### Row 473
- Column 1: math

### Row 474
- Column 1: math

### Row 475
- Column 1: math

### Row 476
- Column 1: math

### Row 477
- Column 1: math

### Row 478
- Column 1: math

### Row 479
- Column 1: math

### Row 480
- Column 1: math

### Row 481
- Column 1: math

### Row 482
- Column 1: math

### Row 483
- Column 1: math

### Row 484
- Column 1: math

### Row 485
- Column 1: math

### Row 486
- Column 1: math

### Row 487
- Column 1: math

### Row 488
- Column 1: math

### Row 489
- Column 1: math

### Row 490
- Column 1: math

### Row 491
- Column 1: math

### Row 492
- Column 1: math

### Row 493
- Column 1: math

### Row 494
- Column 1: math

### Row 495
- Column 1: math

### Row 496
- Column 1: math

### Row 497
- Column 1: math

### Row 498
- Column 1: math

### Row 499
- Column 1: math

### Row 500
- Column 1: math

## Sheet: skills

- Physical rows: 691
- Non-empty rows: 688

### Row 1
- Column 1: شناسه درس
- Column 2: کد مبحث اصلی
- Column 3: عنوان مبحث اصلی
- Column 4: کد مبحث
- Column 5: عنوان مبحث
- Column 6: عنوان مهارت
- Column 7: کد مهارت
- Column 8: کد پایه
- Column 9: پیش نیاز های مهارت
- Column 10: پس نیاز های مهارت
- Column 11: هدف آموزشی
- Column 12: کج فهمی
- Column 13: ترتیب مهارت ها
- Column 14: نوع سوالات

### Row 2
- Column 1: topic slug
- Column 2: topic code: به فرم 1 حرف انگلیسی
- Column 3: topic name
- Column 4: Sub topic code:  topic_code. Sub Topic_code
- Column 5: Sub topic name
- Column 6: skill name
- Column 7: skill code: به فرم sub topic_code. Topic_code . #num
- Column 8: grade code
- Column 10: learning objective
- Column 11: misconceptions
- Column 12: sequence
- Column 13: QUESTION TYPE

### Row 3
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: ساخت و نمایش اعداد به کمک مدل‌های مختلف ارزش مکانی (کوییزنر، چرتکه,جدول ارزش مکانی و پول)
- Column 8: 4
- Column 11: اعداد تا ۹ رقم را روی جدول ارزش مکانی نشان دهد و بازنمایی‌های مختلف مثل چرتکه، کوییزنر و پول عدد را نمایش دهد.

### Row 4
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: پیدا کردن ارزش ارقام در عددها
- Column 8: 4
- Column 11: بتواند ارزش هر رقم را در یک عدد بدست بیاورد.

### Row 5
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: نوشتن عدد به رقم و حروف تا مرتبه‌ی میلیون
- Column 8: 4
- Column 11: بتواند اعداد را به رقم و حروف بنویسد.
- Column 12: سه رقم سه رقم از سمت راست جدا نمیکند. جدا کردن مرتبه ها را از سمت چپ انجام می دهد .

### Row 6
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: پیدا کردن ارتباط بین ارزش‌های مکانی مختلف با یکدیگر
- Column 8: 4
- Column 11: ارزش مرتبه‌های جدول ارزش مکانی و ارتباط بین ستون‌ها را درک کند و بداند که اگر رقمی در یک عدد جابجا شد، ارزش آن رقم چه تغییری می‌کند.
- Column 12: وقتی تعداد ارقام یک خانه بیشتر از ۱۰ تا می‌شود مثلا وقتی می گوییم ۱۲ بسته ی ۱۰۰ تایی داریم نمی تواند تشخیص دهد که معادل با ۱ هزارتایی و ۲ صدتایی است.

### Row 7
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: نوشتن اعداد به فرم گسترده و استاندارد
- Column 8: 4
- Column 11: بتواند اعداد را به فرم گسترده بنویسد و یا فرم گسترده را به فرم استاندارد تبدیل کند.

### Row 8
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: ساختن یک عدد بااطلاعات داده‌شده(من چه عددی هستم؟)
- Column 8: 4
- Column 11: بتواند با استفاده از اطلاعات سوال، اعداد خواسته شده را بسازد.

### Row 9
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AA
- Column 5: ارزش مکانی
- Column 6: پیدا کردن مصادیق اعداد کوچک و بزرگ در زندگی
- Column 8: 4
- Column 11: از اعداد بزرگ (مثل میلیون) درک و تصور دارد و می‌تواند مصادیق مربوط به این اعداد را در زندگی روزمره بیان کند.

### Row 10
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AB
- Column 5: مقایسه
- Column 6: مقایسه اعداد تا میلیون
- Column 8: 4
- Column 11: مقایسه اعداد و عبارت‌های عددی تا ۹ رقم
- Column 12: به تعداد ارقام توجه نمی کند فقط به بزرگی ارقام توجه دارد مثلا ۹۹۹ از ۱۰۰۰ بزرگتر نیست اما به دلیل وجود ارقام بزرگ آن را بزرگتر در نظر می گیرد.

### Row 11
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AB
- Column 5: مقایسه
- Column 6: مقایسه عبارت‌ها
- Column 8: 4
- Column 11: مقایسه اعداد و عبارت‌های عددی تا ۹ رقم

### Row 12
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AB
- Column 5: مقایسه
- Column 6: مرتب کردن اعداد
- Column 8: 4
- Column 11: مرتب کردن تعدادی عدد با نظم گفته شده در سوال

### Row 13
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: تقریب اعداد در مرتبه‌ی دهگان
- Column 8: 4
- Column 11: تقریب اعداد در مرتبه‌ی دهگان (صفر شدن مرتبه‌های کوچکتر از دهگان)

### Row 14
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: تقریب اعداد در مرتبه‌ی صدگان
- Column 8: 4
- Column 11: تقریب اعداد در مرتبه‌ی صدگان (صفر شدن مرتبه‌های کوچکتر از صدگان)

### Row 15
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: تقریب اعداد در مرتبه‌ی هزار
- Column 8: 4
- Column 11: تقریب اعداد در مرتبه‌ی هزار (صفر شدن مرتبه‌های کوچکتر از هزار)

### Row 16
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: تقریب اعداد در مرتبه‌ی میلیون
- Column 8: 4
- Column 11: تقریب اعداد در مرتبه‌ی میلیون (صفر شدن مرتبه‌های کوچکتر از میلیون)

### Row 17
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: نمایش تقریبی اعداد روی محور
- Column 8: 4
- Column 11: نشان دادن محل تقریبی اعداد تا ۹ رقم روی محور (محور با توجه به تقریب درجه‌بندی شده)

### Row 18
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AC
- Column 5: تقریب و تخمین
- Column 6: کاربرد تقریب در زندگی
- Column 8: 4
- Column 11: می‌تواند از تقریب در زندگی روزمره استفاده کند.

### Row 19
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AD
- Column 5: اعداد صحیح

### Row 20
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نمایش اعداد اعشاری با شکل و محور (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری با مرتبه‌ی دهم را با رنگ‌آمیزی شکل‌های ۱۰ قسمتی و نشان دادن روی محور با تقسیمات دهم نمایش دهد.

### Row 21
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نمایش اعداد اعشاری با شکل و محور (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری با مرتبه‌ی صدم را روی شبکه‌ی ۱۰۰تایی (مربعی) و محور اعداد با تقسیمات صدم به‌درستی نمایش دهد.

### Row 22
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نوشتن اعداد اعشاری به رقم و حروف (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری تا مرتبه‌ی دهم را با ممیز بخواند و به رقم و حروف بنویسد.

### Row 23
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نوشتن اعداد اعشاری به رقم و حروف (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری تا مرتبه‌ی صدم را با ممیز بخواند و به رقم و حروف بنویسد.

### Row 24
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: ارزش مکانی رقم‌ها در اعداد اعشاری(مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند ارزش هر رقم (یکان و دهم) را در جدول ارزش مکانی و خارج از آن تعیین کند.

### Row 25
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: ارزش مکانی رقم‌ها در اعداد اعشاری(مرتبه‌ی صدم)
- Column 8: 4
- Column 11: جدول ارزش مکانی اعشاری را رسم کند و ارزش رقم‌های صدم، دهم و بخش صحیح را در عدد مشخص نماید.

### Row 26
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نوشتن اعداد اعشاری به فرم گسترده و استاندارد (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند عدد اعشاری (تا دهم) را به‌صورت مجموع بخش صحیح و دهم باز کند یا شکل گسترده را به عدد استاندارد تبدیل کند.

### Row 27
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: نوشتن اعداد اعشاری به فرم گسترده و استاندارد (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند عدد اعشاری (تا صدم) را به‌صورت گسترده بنویسد و از فرم گسترده به عدد استاندارد بازگرداند.

### Row 28
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تقریب اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند عدد اعشاری را به نزدیک‌ترین عدد صحیح (با توجه به رقم دهم) یا با روش قطع‌کردن/گردکردن تا دهم تقریب بزند.

### Row 29
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تقریب اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند عدد اعشاری تا مرتبه‌ی صدم را به نزدیک‌ترین دهم یا عدد صحیح تقریب بزند.

### Row 30
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد اعشاری + مرتب کردن(مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند دو یا چند عدد اعشاری تا مرتبه‌ی دهم را مقایسه کند و آن‌ها را به ترتیب صعودی یا نزولی مرتب نماید.

### Row 31
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد اعشاری + مرتب کردن(مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری با مرتبه‌های متفاوت (دهم و صدم) را با هم مقایسه کرده و مرتب کند (با توجه به ارزش مکانی).

### Row 32
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تبدیل کسر به اعشار با شکل و محور  (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند کسرهای با مخرج ۱۰ را با رسم شکل یا نمایش روی محور به نماد اعشاری ممیزدار تبدیل کند و برعکس.

### Row 33
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تبدیل کسر به اعشار با شکل و محور (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند کسرهای با مخرج ۱۰۰ را با استفاده از شبکه‌ی صدتایی و محور به عدد اعشاری تبدیل کند و برعکس.

### Row 34
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تبدیل کسر به اعشار  (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند کسرها و عددهای مخلوط با مخرج ۱۰ را مستقیماً به عدد اعشاری بنویسد و برعکس.

### Row 35
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تبدیل کسر به اعشار (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند کسرها و عددهای مخلوط با مخرج ۱۰۰ را بدون نیاز به شکل به عدد اعشاری تبدیل کند و برعکس.

### Row 36
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: جمع اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند دو عدد اعشاری تا یک رقم اعشار را به‌صورت سطری و ستونی (با رعایت انتقال و زیرهم‌نویسی ممیز) جمع کند.

### Row 37
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: جمع اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری تا دو رقم اعشار را با هم‌تراز کردن ممیزها و انتقال مرتبه‌ها جمع کند.

### Row 38
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌ی های جمع اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: مسائل کلامی و کاربردیِ شامل جمع اعداد اعشاری تا مرتبه‌ی دهم را درک کرده و حل کند.

### Row 39
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌ی های جمع اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: مسائل واقعی (مانند طول و پول) شامل جمع اعداد اعشاری تا مرتبه‌ی صدم را حل نماید.

### Row 40
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در جمع اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: با استفاده از رابطه‌ی بین جمع و تفریق، مقدار مجهول در تساوی‌های جمع اعشاری (تا دهم) را به دست آورد.

### Row 41
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در جمع اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: مجهول در عبارت‌های جمع اعشاری تا مرتبه‌ی صدم را با محاسبات معکوس یا جبر ابتدایی بیابد.

### Row 42
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تفریق اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند دو عدد اعشاری تا مرتبه‌ی دهم را به‌درستی از هم کم کند (با و بدون نیاز به قرض گرفتن از یکان).

### Row 43
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: تفریق اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند اعداد اعشاری تا مرتبه‌ی صدم را با تراز کردن ممیزها و قرض گرفتن بین مرتبه‌ها تفریق کند.

### Row 44
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌ی های تفریق اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: مسائل کلامی روزمره مربوط به اختلاف و باقیمانده با اعداد اعشاری تا مرتبه‌ی دهم را حل کند.

### Row 45
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌ی های تفریق اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: مسائل متنی شامل تفریق اعداد اعشاری تا دو رقم اعشار را فرمول‌بندی و محاسبه کند.

### Row 46
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در تفریق اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: مقدار نامعلوم را در تساوی‌های تفریق اعشاری تا دهم مشخص کند.

### Row 47
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در تفریق اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: مجهول را در عبارت‌های تفریق اعشاری تا مرتبه‌ی صدم با استفاده از رابطه‌ی جمع و تفریق پیدا کند.

### Row 48
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌های محاسبات تقریبی اعداد اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: قبل از محاسبه‌ی دقیق، پاسخ جمع یا تفریق اعشاری (تا دهم) را با تقریب زدن تخمین بزند.

### Row 49
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مساله‌های محاسبات تقریبی اعداد اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: حاصل عملیات اعداد اعشاری تا صدم را در مسائل دنیای واقعی با تقریب مناسب تخمین بزند.

### Row 50
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در الگوهای عددی اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: رابطه‌ی افزایشی یا کاهشی اعشاری (با گام‌های دهم) را کشف کرده و جملات بعدی را بنویسد.

### Row 51
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: پیدا کردن عدد نامعلوم در الگوهای عددی اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: نظم و الگوی دنباله‌های اعشاری با گام‌های صدم را پیدا کرده و عدد مجهول را مشخص کند.

### Row 52
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد و عبارت‌های کسری و اعشاری با شکل و محور  (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: با بازنمایی همزمان روی شکل یا محور، ارتباط و برابری/نابرابری بین یک کسر و عدد اعشاری (دهم) را نشان دهد.

### Row 53
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد و عبارت‌های کسری و اعشاری با شکل و محور (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: با کمک شکل واحد (شبکه ۱۰۰تایی) یا محور، عبارت‌های کسری و اعشاری تا صدم را مقایسه کند.

### Row 54
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد و عبارت‌های کسری و اعشاری (مرتبه‌ی دهم)
- Column 8: 4
- Column 11: بتواند با هم‌ارز کردن کسر و اعشار (تبدیل به یک فرمت)، کسرها و اعداد اعشاری دهم را مقایسه کند.

### Row 55
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AE
- Column 5: اعداد اعشاری
- Column 6: مقایسه‌ی اعداد و عبارت‌های کسری و اعشاری (مرتبه‌ی صدم)
- Column 8: 4
- Column 11: بتواند عبارات کسری و اعشاری تا مرتبه‌ی صدم را به‌طور نمادین با هم مقایسه کرده و علامت مناسب درج کند.

### Row 56
- Column 3: درک اعداد
- Column 5: ارتباط بین اعداد کسری و اعشاری و طبیعی
- Column 9: درک کند که اعداد اعشاری نمایش دیگری از کسرها هستند و موقعیت اعداد صحیح/طبیعی را در بین اعداد کسری و اعشاری بشناسد.

### Row 57
- Column 3: درک اعداد
- Column 5: مصادیق اعداد کسری و اعشاری و طبیعی در زندگی
- Column 9: بتواند کاربرد هر یک از اعداد صحیح، کسری و اعشاری را در ابزارهای اندازه‌گیری (متر، خط‌کش، ترازو) و زندگی روزمره توضیح دهد.

### Row 58
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: تشخیص و نمایش کسرهای واحد پرکاربرد (نصف، ثلث و ربع) با کمک شکل (با قسمت بندی مساوی و نامساوی)
- Column 8: 4
- Column 11: کسرهای ۱/۲، ۱/۳ و ۱/۴ را روی شکل‌هایی با بخش‌بندی‌های هم‌اندازه یا نیازمند بازآرایی تشخیص دهد و مفهوم مساحت برابر را درک کند.

### Row 59
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: نمایش کسرهای واحد پیچیده‌تر با کمک شکل
- Column 8: 4
- Column 11: کسرهای واحدی مانند ۱/۵، ۱/۶، ۱/۸ و ... را با تقسیم‌بندی درست یک واحد کامل روی شکل نمایش دهد.

### Row 60
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: درک و نمایش کسر با استفاده از نوار کسر
- Column 8: 4
- Column 11: بتواند با دست‌ورزی یا رسم نوار کسر، مفهوم کل، جزء و کسرهای معادل را نشان دهد.

### Row 61
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: درک و نمایش کسر با استفاده مدل مساحتی
- Column 8: 4
- Column 11: کسرها را با استفاده از سطوح دو‌بعدی (دایره، مستطیل و مربع) با تقسیمات هم‌مساحت مدل‌سازی کند.

### Row 62
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: نمایش کسر روی شکل
- Column 8: 4
- Column 11: با توجه به صورت و مخرج کسر داده‌شده، شکل واحد را به قسمت‌های مساوی تقسیم کرده و به تعداد صورت رنگ‌آمیزی کند.
- Column 12: شکلی که به ۴ قسمت نامساوی تقسیم شده را رسم می‌کند و یک قسمتش را رنگ می‌زند و  اشتباها آن را یک چهارم نمایش  می‌داند، چون شرط «تقسیم به قسمت‌های مساوی» را درک نکرده است.

### Row 63
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: نوشتن کسرها به شکل جمع کسرهای واحد (با شکل و بدون شکل)
- Column 8: 4
- Column 11: بتواند یک کسر را به صورت مجموع کسرهای واحد متناظر بنویسد و با شکل اثبات کند.

### Row 64
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: نمایش کسر روی محور اعداد
- Column 8: 4
- Column 11: بتواند فاصله بین اعداد صحیح را روی محور با توجه به مخرج تقسیم‌بندی کرده و موقعیت کسر را علامت بزند.

### Row 65
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مساله‌های کسر با استفاده از رسم شکل
- Column 8: 4
- Column 11: مسائل متنیِ مفهوم جزء از کلِ کسر را با استراتژی رسم شکل مرحله‌به‌مرحله مدل‌سازی و حل نماید.

### Row 66
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مساله‌های کسری از کل یا کسری از یک تعداد با استفاده از رسم شکل
- Column 8: 4
- Column 11: بتواند کسر از یک مجموعه‌ی گسسته (مانند تعداد اشیاء) را با دسته‌بندی و رسم شکل محاسبه کند.

### Row 67
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: پیدا کردن کسرهای معادل با استفاده از مدل مساحتی
- Column 8: 4
- Column 11: با تقسیم‌بندی مجدد بخش‌های رنگ‌شده در یک شکل مساحتی، برابری دو کسر با مخرج‌های متفاوت را نشان دهد.

### Row 68
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: پیدا کردن کسرهای معادل با استفاده از محور
- Column 8: 4
- Column 11: با ریزتر کردن بخش‌بندی‌های محور اعداد، کسرهای مساوی و هم‌مکان را بیابد.

### Row 69
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: پیدا کردن کسرهای معادل
- Column 8: 4
- Column 11: بتواند با ضرب یا تقسیم صورت و مخرج در یک عدد ثابت غیرصفر، کسرهای مساوی بسازد.

### Row 70
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: پیدا کردن عدد نامعلوم در الگوی کسرهای معادل
- Column 8: 4
- Column 11: با کشف ضریب ضرب یا تقسیم در صورت یا مخرج، عدد مجهول در تساوی کسرها را پیدا کند.

### Row 71
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: نوشتن کسرهای معادل با مخرج ۱۰ و ۱۰۰
- Column 8: 4
- Column 11: بتواند کسرهایی با مخرج‌های ۲، ۴، ۵، ۲۰، ۲۵، ۵۰ را با ضرب صورت و مخرج به کسر مساوی با مخرج ۱۰ یا ۱۰۰ تبدیل کند.

### Row 72
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: ساده کردن کسرها
- Column 8: 4
- Column 11: بتواند با تقسیم صورت و مخرج بر عامل مشترک، کسر را تا حد امکان ساده‌تر بنویسد.

### Row 73
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مقایسه کسرها با مخرج برابر (با کمک شکل و محور)
- Column 8: 4
- Column 11: با مدل‌سازی بصری نشان دهد که بین دو کسر با مخرج یکسان، کسری بزرگتر است که صورت بزرگتری دارد.

### Row 74
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مقایسه کسرها با مخرج برابر (بدون شکل)
- Column 8: 4
- Column 11: بتواند قاعده‌ی مقایسه‌ی کسرهای هم‌مخرج را بدون تکیه بر تصویر بیان کرده و نماد مناسب قرار دهد.

### Row 75
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مقایسه‌ کسرها با کمک کسر نصف به عنوان معیار
- Column 8: 4
- Column 11: بدون مخرج مشترک‌گیری، با مقایسه هر کسر با عدد ۱/۲ (بزرگتر از نصف، کوچکتر از نصف)، دو کسر را با هم مقایسه کند.

### Row 76
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مقایسه کسرها با صورت یا مخرج برابر
- Column 8: 4
- Column 11: قاعده‌ی مقایسه‌ی کسرهای هم‌صورت و هم‌مخرج را به درستی به کار بگیرد.
- Column 12: فکر میکند یک هشتم از یک چهارم بزرگتر است چون یک هشتم مخرج بزرگتری دارد.

### Row 77
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AF
- Column 5: اعداد کسری
- Column 6: مقایسه‌ و مرتب کردن کسرها (در حالت کلی)
- Column 8: 4
- Column 11: بتواند با روش هم‌مخرج کردن، تبدیل به کسر مساوی، یا استفاده از کسرهای طلایی مثل نصف، چند کسر ناهم‌مخرج را مرتب کند.

### Row 78
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AG
- Column 5: نسبت و تناسب و درصد

### Row 79
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AH
- Column 5: شمارش و نمایش عددی
- Column 6: شمارش ده‌تایی رسیدن به میلیون
- Column 8: 4
- Column 11: الگوی شمارش ۱۰تایی را تا رسیدن به عدد یک میلیون به صورت صعودی و نزولی ادامه دهد.

### Row 80
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AH
- Column 5: شمارش و نمایش عددی
- Column 6: شمارش صدتایی رسیدن به میلیون
- Column 8: 4
- Column 11: الگوی شمارش ۱۰۰تایی را تا مرز مرتبه‌ی میلیون با درک تغییر ارزش‌های مکانی ادامه دهد.

### Row 81
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AH
- Column 5: شمارش و نمایش عددی
- Column 6: شمارش هزارتایی رسیدن به میلیون
- Column 8: 4
- Column 11: الگوی شمارش ۱۰۰۰تایی را با تسلط بر تغییرات طبقه هزار تا رسیدن به یک میلیون بیان کند.

### Row 82
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.AJ
- Column 5: اعداد طبیعی
- Column 7: 4

### Row 83
- Column 1: math
- Column 2: A
- Column 3: درک اعداد
- Column 4: A.A.K
- Column 5: اعدادمختلط و حقیقی
- Column 7: 4

### Row 84
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.A
- Column 5: جمع
- Column 6: جمع اعداد تا ۹ رقم
- Column 8: 4
- Column 11: بتواند دو یا چند عدد تا ۹ رقم را با رعایت ارزش مکانی و انتقال مرتبه‌ها  جمع کند.

### Row 85
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.A
- Column 5: جمع
- Column 6: پیدا کردن رقم نامعلوم در یک جمع
- Column 8: 4
- Column 11: با استفاده از منطق جمع و روابط ارزش مکانی، رقم‌های خالی یا پنهان را در تساوی جمع پیدا کند.

### Row 86
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.A
- Column 5: جمع
- Column 6: مساله‌های جمع
- Column 8: 4
- Column 11: مسائل کلامی و چندمرحله‌ای شامل جمع اعداد بزرگ (تا ۹ رقم) را درک و حل کند.

### Row 87
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.A
- Column 5: جمع
- Column 6: جمع تقریبی اعداد و مساله‌ها
- Column 8: 4
- Column 11: قبل از محاسبه‌ی دقیق، حاصل جمع اعداد بزرگ را با تقریب زدن تخمین بزند و مسائل مربوط به آن را حل کند.

### Row 88
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.A
- Column 5: جمع
- Column 6: خواص جمع
- Column 8: 4
- Column 11: خواص جمع (مانند خاصیت جابه‌جایی، شرکت‌پذیری و عضو بی‌اثر یعنی صفر) را بشناسد و در محاسبات به کار ببرد.

### Row 89
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.B
- Column 5: تفریق
- Column 6: تفریق اعداد تا ۹ رقم
- Column 8: 4
- Column 11: بتواند دو عدد تا ۹ رقم را با رعایت ارزش مکانی و عمل قرض گرفتن بین مرتبه‌ها از هم تفریق کند.
- Column 12: تفریق عدد کوچک‌تر از بزرگ‌تر بدون توجه به موقعیت بالا و پایین: در تفریق ۲۷ از عدد ۵۲   در ستون یکان چون نمی‌تواند ۷ تا از ۲ تا کم  کند، ۲ تا از ۷ کم می‌کند و حاصل را ۵ می‌نویسد (جواب اشتباه: ۳۵).

### Row 90
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.B
- Column 5: تفریق
- Column 6: پیدا کردن رقم نامعلوم در یک تفریق
- Column 8: 4
- Column 11: با استفاده از رابطه‌ی معکوس جمع و تفریق، رقم‌های نامعلوم را در محاسبات تفریق تعیین کند.

### Row 91
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.B
- Column 5: تفریق
- Column 6: مساله‌های تفریق
- Column 8: 4
- Column 11: مسائل متنی و کاربردی مربوط به مفهوم اختلاف و باقی‌مانده را با اعداد تا ۹ رقم حل کند.

### Row 92
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.B
- Column 5: تفریق
- Column 6: تفریق تقریبی اعداد و مساله ها
- Column 8: 4
- Column 11: حاصل تفریق اعداد بزرگ را با استفاده از تقریب تخمین بزند و درستی پاسخ مسائل را بررسی کند.

### Row 93
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.B
- Column 5: تفریق
- Column 6: خواص تفریق
- Column 8: 4
- Column 11: ویژگی‌های تفریق (عدم خاصیت جابه‌جایی و تاثیر صفر در تفریق) را در عبارات ریاضی تشخیص دهد.

### Row 94
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: دسته‌بندی شکل و نوشتن ضرب مرتبط
- Column 8: 4
- Column 11: اشیاء یا شکل‌ها را به گروه‌های مساوی دسته‌بندی کرده و برای آن‌ها عبارت ضرب متناظر بنویسد.

### Row 95
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: استفاده از عبارت جمع متوالی و نوشتن ضرب مرتبط
- Column 8: 4
- Column 11: مفهوم ضرب را به صورت جمع ردیف‌ها یا گروه‌های هم‌اندازه نمایش دهد و جمع متوالی را به ضرب تبدیل کند.

### Row 96
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: شمارش چندتاچندتا (الگوی ثابت) و نوشتن ضرب مرتبط
- Column 8: 4
- Column 11: با استفاده از شمارش جهشی و گام‌های مساوی روی جدول اعداد، ضرب متناظر را بنویسد.

### Row 97
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: استفاده از روش مستطیلی و نوشتن ضرب مرتبط
- Column 8: 4
- Column 11: آرایه‌های شبکه‌ای و مستطیلی را مدل‌سازی کرده و ابعاد سطر و ستون را به حاصل‌ضرب تبدیل کند.

### Row 98
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: استفاده از محور و نوشتن ضرب مرتبط
- Column 8: 4
- Column 11: حرکت‌های رو به جلو با طول گام‌های مساوی را روی محور اعداد رسم کرده و عبارت ضرب آن را بنویسد.
- Column 12: جابجا گرفتن «تعداد پرش‌ها» با «طول هر پرش» (مثلاً ۳ پرش ۴تایی را  شمردن خط‌ها یا نقطه‌ها به جای شمردن فاصله‌ها (فاصله‌های خالی بین اعداد) شروع پرش از عدد ۱ به جای عدد ۰

### Row 99
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: جدول ضرب تا ۱۲
- Column 8: 4
- Column 11: حقایق پایه‌ی جدول ضرب (تا ۱۲×۱۲) را حفظ باشد و با سرعت و دقت در محاسبات استفاده کند.
- Column 12: حفظ طوطیوار و از دست دادن نتیجه در صورت فراموشی یک مورد (ناتوانی در بازسازی حاصل مثلاً از راه جمع مکرر یا دوبرابر کردن) . اشتباه در حاصل ضربهای نزدیک به هم با مضارب ۶، ۷، ۸ و ۹.

### Row 100
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: الگوهای ضرب با‌ افزایش ارزش مکانی
- Column 8: 4
- Column 11: با افزایش ارزش مکانی عامل‌ها (مانند ۲۰×۳ یا ۲۰۰×۳)، الگوی صفرها و تغییر مرتبه را در حاصل‌ضرب کشف کند.

### Row 101
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: ضرب در ۱۰ و ۱۰۰ و ۱۰۰۰
- Column 8: 4
- Column 11: قاعده‌ی ضرب یک عدد در ۱۰، ۱۰۰ و ۱۰۰۰ را با افزودن صفرها به مرتبه‌های مناسب اجرا کند.

### Row 102
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: ضرب در اعداد منتهی به ۰ و ۰۰
- Column 8: 4
- Column 11: حاصل‌ضرب اعدادی را که به صفر ختم می‌شوند با ضرب بخش غیرصفر و انتقال صفرهای پایانی محاسبه کند.
- Column 12: حذف صفرهای میانی به همراه صفرهای انتهایی؛ مثلاً در صفر بین ۲ و ۵ را هم کنار میگذارد و مینویسد: و سپس دو تا صفر میگذارد. اشتباه در شمردن تعداد کل صفرهای غیر صفر (مثلاً در مینویسد ۳۰۰ چون فکر میکند صفر حاصل از یکی از صفرهای پایانی بوده است.)

### Row 103
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: محاسبه‌ی حاصل ضرب تقریبی
- Column 8: 4
- Column 11: با تقریب زدن عامل‌های ضرب، حاصل‌ضرب تقریبی ضرب را تخمین بزند.

### Row 104
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش فرآیندی در محاسبه‌ی حاصل ضرب دو رقم در یک رقم
- Column 8: 4
- Column 11: ضرب دو رقم در یک رقم را به روش مرحله‌به‌مرحله و گسترده‌نویسی (ارزش مکانی ده‌گان و یکان) انجام دهد.

### Row 105
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش مساحتی در محاسبه‌ی حاصل ضرب دو رقم در یک رقم
- Column 8: 4
- Column 11: با رسم مدل مساحتی (مستطیل تفکیک‌شده)، بخش‌های مساحت را محاسبه و برای ضرب دو رقم در یک رقم جمع کند.

### Row 106
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش تکنیکی در محاسبه‌ی حاصل ضرب دو رقم در یک رقم
- Column 8: 4
- Column 11: ضرب دو رقم در یک رقم را با روش خلاصه و تکنیکی (الگوریتم استاندارد با انتقال مرتبه) محاسبه کند.

### Row 107
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: حل مساله ضرب دو رقم در یک رقم
- Column 8: 4
- Column 11: مسائل واقعی و کاربردی مربوط به ضرب دو رقم در یک رقم را مدل‌سازی و حل نماید.

### Row 108
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش فرآیندی در محاسبه‌ی حاصل ضرب سه رقم در یک رقم و نوشتن به فرم گسترده
- Column 8: 4
- Column 11: ضرب سه رقم در یک رقم را به فرم گسترده درآورده و با روش فرآیندی حاصل ضرب هر مرتبه را به دست آورد.

### Row 109
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش مساحتی در محاسبه‌ی حاصل ضرب سه رقم در یک رقم
- Column 8: 4
- Column 11: مستطیل مساحتی را به سه بخش صدگان، دهگان و یکان تقسیم کرده و ضرب سه رقم در یک رقم را نشان دهد.

### Row 110
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش تکنیکی در محاسبه‌ی حاصل ضرب سه رقم در یک رقم
- Column 8: 4
- Column 11: الگوریتم استاندارد و عمودی ضرب سه رقم در یک رقم را با دقت در انتقال‌ها انجام دهد.

### Row 111
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: حل مساله ضرب سه رقم در یک رقم
- Column 8: 4
- Column 11: مسائل چندمرحله‌ای زندگی روزمره شامل ضرب سه رقم در یک رقم را تحلیل و پاسخ دهد.

### Row 112
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: محاسبه‌ی حاصلضرب اعداد چند رقمی در یک رقمی
- Column 8: 4
- Column 11: ضرب هر عدد چندرقمی (مانند ۴ یا ۵ رقمی) در یک عدد یک‌رقمی را با استفاده از ارزش مکانی محاسبه کند.

### Row 113
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: خواص ضرب
- Column 8: 4
- Column 11: خواص ضرب شامل خاصیت جابه‌جایی، شرکت‌پذیری، عضو بی‌اثر (یک) و عضو خنثی‌کننده (صفر) را در عبارات به کار گیرد.

### Row 114
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: محاسبه‌ی حاصل ضرب سه یا چند عدد  یک رقمی
- Column 8: 4
- Column 11: حاصل‌ضرب زنجیره‌ای از سه یا چند عدد یک‌رقمی را با گروه‌بندی مناسب و استفاده از پرانتز محاسبه کند.

### Row 115
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: مساله‌های ضرب سه یا چند عدد یک رقمی
- Column 8: 4
- Column 11: مسائل کلامی نیازمند چند مرحله ضرب متوالی (ترکیب چند دسته یا بُعد) را به درستی حل کند.

### Row 116
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: مقایسه‌ی عبارت‌های ضربی
- Column 8: 4
- Column 11: بدون نیاز به ضرب کامل، روابط بزرگتر، کوچکتر یا مساوی بین دو عبارت ضربی را با مقایسه‌ی عامل‌ها تعیین کند.

### Row 117
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: استفاده از ضرب‌های کمکی در محاسبه‌ی حاصلضرب
- Column 8: 4
- Column 11: برای محاسبه‌ی ضرب‌های دشوار از ضرب‌های ساده‌تر و کمکی مجاور (مانند استفاده از ضرب در ۵ یا ۱۰) بهره ببرد.

### Row 118
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: تبدیل عبارت ضربی به عبارت ضربی دیگر
- Column 8: 4
- Column 11: یک عبارت ضربی را با تجزیه‌ی یکی از عامل‌ها به عامل‌های کوچکتر یا جمع دو عدد بازنویسی کند.

### Row 119
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش فرآیندی در محاسبه‌ی حاصل ضرب دو رقم در دو رقم
- Column 8: 4
- Column 11: ضرب دو رقم در دو رقم را با محاسبه‌ی جداگانه‌ی چهار حاصل‌ضرب جزئی و جمع آن‌ها (فرآیندی) محاسبه کند.

### Row 120
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش مساحتی در محاسبه‌ی حاصل ضرب دو رقم در دو رقم
- Column 8: 4
- Column 11: مدل مساحتی متناظر با ضرب دو رقم در دو رقم را به صورت یک شبکه ۴ قسمتی رسم و محاسبه کند.

### Row 121
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش تکنیکی در محاسبه‌ی حاصل ضرب دو رقم در دو رقم
- Column 8: 4
- Column 11: الگوریتم استاندارد (تکنیکی) ضرب دو رقم در دو رقم را با رعایت ارزش مکانی سطر دوم اجرا کند.

### Row 122
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: حل مساله ضرب دو رقم در دو رقم
- Column 8: 4
- Column 11: مسائل کلامی مربوط به ضرب دو رقم در دو رقم (مانند مساحت، بسته‌بندی، دستمزد) را حل نماید.

### Row 123
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش فرآیندی در محاسبه‌ی حاصل ضرب سه رقم در سه رقم
- Column 8: 4
- Column 11: ضرب سه رقم در سه رقم را با محاسبه‌ی گام‌به‌گام و حفظ مرتبه‌های ارزش مکانی به روش فرآیندی (گسترده کردن عوامل ضرب) پیش ببرد.

### Row 124
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش مساحتی در محاسبه‌ی حاصل ضرب سه رقم در سه رقم
- Column 8: 4
- Column 11: مستطیل مساحتی با تفکیک صدگان، دهگان و یکان هر دو عدد را مدل‌سازی و حل کند.

### Row 125
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: روش تکنیکی در محاسبه‌ی حاصل ضرب سه رقم در سه رقم
- Column 8: 4
- Column 11: الگوریتم استاندارد و خلاصه ضرب سه رقم در سه رقم را با دقت در صفرگذاری سطرهای دوم و سوم انجام دهد.

### Row 126
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.C
- Column 5: ضرب
- Column 6: حل مساله ضرب سه رقم در سه رقم
- Column 8: 4
- Column 11: مسائل پیچیده‌تر با ابعاد بزرگتر را با ضرب سه رقم در سه رقم حل و بررسی کند.

### Row 127
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: نوشتن عبارت تقسیم کلامی و زبان ریاضی و با استفاده از شکل
- Column 8: 4
- Column 11: یک موقعیت مساوی را به صورت عبارت کلامی، شکل‌های گروه‌بندی و نماد تقسیم بنویسد.

### Row 128
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: ارتباط ضرب و تقسیم
- Column 8: 4
- Column 11: درک کند که تقسیم عکس ضرب است و از جملات هم‌خانواده‌ی ضرب برای پاسخ به تقسیم استفاده کند.

### Row 129
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم با کمک شکل
- Column 8: 4
- Column 11: عملیات تقسیم (تقسیم به بخش‌های مساوی یا دسته‌بندی) را با کشیدن و دسته‌بندی شکل نمایش دهد.

### Row 130
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم با کمک روش مساحتی
- Column 8: 4
- Column 11: مفهوم تقسیم را به صورت پیدا کردن یکی از اضلاع یک مستطیل مساحتی مدل‌سازی و محاسبه کند.

### Row 131
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم با کمک تفریق‌های متوالی
- Column 8: 4
- Column 11: حاصل تقسیم را با کم کردن متوالی مقسوم‌علیه از مقسوم تا رسیدن به صفر یا باقیمانده پیدا کند.

### Row 132
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم با کمک خاصیت توزیع پذیری
- Column 8: 4
- Column 11: مقسوم را به اعدادی بخش‌پذیر و ساده تجزیه کرده و با اعمال خاصیت توزیع‌پذیری، خارج‌قسمت را به دست آورد.

### Row 133
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم اعداد تا ۱۲
- Column 8: 4
- Column 11: تقسیم (جدول تقسیم تا عامل‌های ۱۲) را به درستی پاسخ دهد.

### Row 134
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: مساله های تقسیم اعداد  تا  ۱۲
- Column 8: 4
- Column 11: مسائل کلامی ساده شامل تسهیم و افراز تا محدوده جدول ضرب ۱۲ را درک و حل کند.

### Row 135
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: الگوهای تقسیم با‌ افزایش ارزش مکانی
- Column 8: 4
- Column 11: ارتباط و الگوی تغییر خارج‌قسمت را در تقسیم‌هایی با صفرهای پایانی و تغییر ارزش مکانی درک کند.

### Row 136
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم اعداد منتهی به ۰
- Column 8: 4
- Column 11: قاعده‌ی ساده‌سازی و حذف صفرهای متناظر از مقسوم و مقسوم‌علیه منتهی به صفر را در تقسیم به کار ببرد.

### Row 137
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: استفاده از تقسیم‌های اعداد سازگار در محاسبه‌ی حاصل تقسیم
- Column 8: 4
- Column 11: با گرد کردن یا تبدیل اعداد به اعداد سازگار و خوش‌دست، خارج‌قسمت تقریبی را به راحتی محاسبه کند.

### Row 138
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: حل مساله‌های تقسیم تقریبی
- Column 8: 4
- Column 11: مسائل کاربردی تقسیم را با برآورد اولیه‌ی خارج‌قسمت به روش تقریبی پاسخ دهد.

### Row 139
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم  دو رقم بر یک رقم
- Column 8: 4
- Column 11: تقسیم دو رقم بر یک رقم را انجام دهد.

### Row 140
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: حل مساله‌های تقسیم  دو رقم بر یک رقم و تحلیل باقیمانده
- Column 8: 4
- Column 11: مسائل تقسیم دو رقم بر یک رقم را حل کرده و معنای خارج‌قسمت و تعداد باقیمانده در سوال را درک کند.

### Row 141
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: تقسیم  سه رقم بر یک رقم
- Column 8: 4
- Column 11: تقسیم سه رقم بر یک رقم را با تعیین تعداد ارقام خارج‌قسمت حل کند.

### Row 142
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: حل مساله‌های تقسیم  سه رقم بر یک رقم و تحلیل باقیمانده
- Column 8: 4
- Column 11: مسائل مربوط به تقسیم سه رقم بر یک رقم را مدل‌سازی کرده و درستی رابطه‌ی تقسیم را با باقیمانده بسنجد. و معنی تعداد باقیمانده در سوال را درک کند.

### Row 143
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.D
- Column 5: تقسیم
- Column 6: مقایسه‌ی عبارت‌های تقسیم
- Column 8: 4
- Column 11: حاصل دو عبارت تقسیم را مقایسه کرده و تاثیر تغییر مقسوم یا مقسوم‌علیه را بر حاصل تحلیل کند.

### Row 144
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.E
- Column 5: محاسبات ذهنی
- Column 8: 4

### Row 145
- Column 1: math
- Column 2: B
- Column 3: عملیات و محاسبات
- Column 4: B.A.F
- Column 5: ترکیب عملیات
- Column 8: 4

### Row 146
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.A
- Column 5: خط و نیم خط و پاره خط
- Column 7: 4

### Row 147
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.B
- Column 5: محیط
- Column 7: 4

### Row 148
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: درک مفهوم مساحت به عنوان سطح پوشاندهشده درون یک مرز بسته
- Column 8: 4

### Row 149
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: اندازهگیری مساحت به کمک واحدهای غیراستاندارد و پوشاندن سطح
- Column 8: 4

### Row 150
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: شمارش واحدهای مربعشکل روی صفحه شطرنجی (مربعهای کامل و ترکیب نیمهمربعها(
- Column 8: 4

### Row 151
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: انتخاب بخشی از یک شکل با یک مساحت مشخص
- Column 8: 4

### Row 152
- Column 3: تشخیص دو شکل با مساحت برابر و ظاهر متفاوت
- Column 5: 4

### Row 153
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: درک مفهوم و به کارگیری واحد استاندارد سطح (سانتیمتر مربع و متر مربع)
- Column 8: 4

### Row 154
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: فرمول نویسی و محاسبهی مساحت مربع و مستطیل
- Column 8: 4

### Row 155
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: تفکیک شکلهای هندسی ترکیبی به مربع و مستطیل برای محاسبهی مساحت کل
- Column 8: 4

### Row 156
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: حل مسائل معکوس مساحت (پیدا کردن طول یا عرض با داشتن مساحت و یک بعد)
- Column 8: 4

### Row 157
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: مقایسه ی محیط و مساحت و درک اینکه شکلهای هم محیط میتوانند مساحتهای متفاوت داشته باشند (و برعکس)
- Column 8: 4

### Row 158
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.C
- Column 5: مساحت
- Column 6: حل مسائل کاربردی مساحت در دنیای واقعی (مانند رنگآمیزی دیوار، فرش کردن و کاشیکاری)
- Column 8: 4

### Row 159
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.D
- Column 5: حجم

### Row 160
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: درک مفهوم زاویه
- Column 8: 4
- Column 12: میزان بازشدگی دو پاره خط سازنده زاویه را در در نظر نمیگیرد. خصوصا در زاویه های بیشتر از ۱۸۰ درجه فقط فضای داخلی را در نظر میگرد. به علامت نشانگر زاویه که میزان باز شدن را نشان میدهد توجه ندارد.

### Row 161
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: شناسایی اجزای زاویه (راس و ضلع ها )
- Column 8: 4

### Row 162
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: نام گذاری زاویه
- Column 8: 4

### Row 163
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: شناخت انواع زاویه (راست ، تند ، باز و نیم صفحه ، بازتابی ، تمام صفحه)
- Column 8: 4

### Row 164
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: استفاده از گونیا برای تشخیص و رسم زاویه راست
- Column 8: 4

### Row 165
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: معرفی واحد استاندارد اندازه گیری زاویه (درجه)
- Column 8: 4

### Row 166
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: اندازه گیری و خواندن زاویه با استفاده از نقاله
- Column 8: 4
- Column 12: به صفر نقاله توجه نمیکند. در مورد نقاله هایی که از دو سمت مدرج شدند.

### Row 167
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: رسم زاویه با اندازه ی مشخص (با درجه ی معین) به کمک نقاله
- Column 8: 4

### Row 168
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: زاویه های مکمل و متمم و پیدا کردن زاویه ی مجهول با جمع و تفریق
- Column 8: 4

### Row 169
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: تشخیص و یافتن مجموع زاویههای داخلی در شکلهای هندسی (چند ضلعیها : مثلث وچهارضلعی ها)
- Column 8: 4

### Row 170
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.E
- Column 5: زاویه
- Column 6: زاویه به عنوان بخشی از یک دایره
- Column 8: 4

### Row 171
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.F
- Column 5: تقارن

### Row 172
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.G
- Column 5: تبدیل ها

### Row 173
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.H
- Column 5: تشابه

### Row 174
- Column 1: math
- Column 2: C
- Column 3: هندسه و تجسم فضایی
- Column 4: C.A.I
- Column 5: شکل های هندسی
- Column 8: 4

### Row 175
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.A
- Column 5: زمان
- Column 8: 4

### Row 176
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.B
- Column 5: طول
- Column 8: 4

### Row 177
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.C
- Column 5: جرم
- Column 7: 4

### Row 178
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.D
- Column 5: زاویه
- Column 7: 4

### Row 179
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.E
- Column 5: محیط و مساحت
- Column 7: 4

### Row 180
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.F
- Column 5: حجم

### Row 181
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.G
- Column 5: دقت اندازه گیری

### Row 182
- Column 1: math
- Column 2: D
- Column 3: اندازه گیری
- Column 4: D.A.H
- Column 5: واحدهای اندازه گیری و تبدیل آنها
- Column 7: 4

### Row 183
- Column 1: math
- Column 2: E
- Column 3: آمار و احتمال
- Column 4: E.A.A
- Column 5: داده ها و نمودارها
- Column 7: 4

### Row 184
- Column 1: math
- Column 2: E
- Column 3: آمار و احتمال
- Column 4: E.A.B
- Column 5: احتمال
- Column 7: 4

### Row 185
- Column 1: math
- Column 2: E
- Column 3: آمار و احتمال
- Column 4: E.A.C
- Column 5: شاخص های مرکزی

### Row 186
- Column 1: math
- Column 2: F
- Column 3: سواد مالی
- Column 4: F.A.A
- Column 5: مفاهیم مالی
- Column 7: 4

### Row 187
- Column 1: math
- Column 2: F
- Column 3: سواد مالی
- Column 4: F.A.B
- Column 5: پول
- Column 7: 4

### Row 188
- Column 1: math
- Column 2: G
- Column 3: حل مساله
- Column 4: G.A.A
- Column 5: مساله های ترکیبی و چند مرحله ای
- Column 7: 4

### Row 189
- Column 1: math
- Column 2: G
- Column 3: حل مساله
- Column 4: G.A.B
- Column 5: مساله های کلامی
- Column 7: 4

### Row 190
- Column 1: math
- Column 2: G
- Column 3: حل مساله
- Column 4: G.A.C
- Column 5: راهبردهای حل مساله
- Column 7: 4

### Row 191
- Column 1: math
- Column 2: H
- Column 3: جبر و الگوها
- Column 4: H.A.A
- Column 5: الگو و دنباله
- Column 7: 4

### Row 192
- Column 1: math
- Column 2: H
- Column 3: جبر و الگوها
- Column 4: H.A.B
- Column 5: معادله و نامعادله

### Row 193
- Column 1: math
- Column 2: H
- Column 3: جبر و الگوها
- Column 4: H.A.C
- Column 5: ماشین ورودی-خروجی
- Column 7: 4

### Row 194
- Column 1: math
- Column 2: H
- Column 3: جبر و الگوها
- Column 4: H.A.D
- Column 5: توان و رادیکال و لگاریتم

### Row 195
- Column 1: math
- Column 2: I
- Column 3: منطق و استدلال
- Column 4: I.A.A
- Column 5: استقرا

### Row 196
- Column 1: math
- Column 2: I
- Column 3: منطق و استدلال
- Column 4: I.A.B
- Column 5: اثبات های هندسی

### Row 197
- Column 1: math
- Column 2: I
- Column 3: منطق و استدلال
- Column 4: I.A.C
- Column 5: گزاره ها

### Row 198
- Column 1: math
- Column 2: I
- Column 3: منطق و استدلال
- Column 4: I.A.D
- Column 5: نظریه گراف

### Row 199
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.A
- Column 5: ویژگی اعداد
- Column 7: 4

### Row 200
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.B
- Column 5: اعداد اول

### Row 201
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.C
- Column 5: بخش پذیری
- Column 7: 4

### Row 202
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.D
- Column 5: تجزیه و عوامل عدد
- Column 7: 4

### Row 203
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.E
- Column 5: ب.م.م وک.م.م

### Row 204
- Column 1: math
- Column 2: J
- Column 3: نظریه اعداد
- Column 4: J.A.F
- Column 5: مضرب
- Column 7: 4

### Row 205
- Column 1: math

### Row 206
- Column 1: math

### Row 207
- Column 1: math

### Row 208
- Column 1: math

### Row 209
- Column 1: math

### Row 210
- Column 1: math

### Row 211
- Column 1: math

### Row 212
- Column 1: math

### Row 213
- Column 1: math

### Row 214
- Column 1: math

### Row 215
- Column 1: math

### Row 216
- Column 1: math

### Row 217
- Column 1: math

### Row 218
- Column 1: math

### Row 219
- Column 1: math

### Row 220
- Column 1: math

### Row 221
- Column 1: math

### Row 222
- Column 1: math

### Row 223
- Column 1: math

### Row 224
- Column 1: math

### Row 225
- Column 1: math

### Row 226
- Column 1: math

### Row 227
- Column 1: math

### Row 228
- Column 1: math

### Row 229
- Column 1: math

### Row 230
- Column 1: math

### Row 231
- Column 1: math

### Row 232
- Column 1: math

### Row 233
- Column 1: math

### Row 234
- Column 1: math

### Row 235
- Column 1: math

### Row 236
- Column 1: math

### Row 237
- Column 1: math

### Row 238
- Column 1: math

### Row 239
- Column 1: math

### Row 240
- Column 1: math

### Row 241
- Column 1: math

### Row 242
- Column 1: math

### Row 243
- Column 1: math

### Row 244
- Column 1: math

### Row 245
- Column 1: math

### Row 246
- Column 1: math

### Row 247
- Column 1: math

### Row 248
- Column 1: math

### Row 249
- Column 1: math

### Row 250
- Column 1: math

### Row 251
- Column 1: math

### Row 252
- Column 1: math

### Row 253
- Column 1: math

### Row 254
- Column 1: math

### Row 255
- Column 1: math

### Row 256
- Column 1: math

### Row 257
- Column 1: math

### Row 258
- Column 1: math

### Row 259
- Column 1: math

### Row 260
- Column 1: math

### Row 261
- Column 1: math

### Row 262
- Column 1: math

### Row 263
- Column 1: math

### Row 264
- Column 1: math

### Row 265
- Column 1: math

### Row 266
- Column 1: math

### Row 267
- Column 1: math

### Row 268
- Column 1: math

### Row 269
- Column 1: math

### Row 270
- Column 1: math

### Row 271
- Column 1: math

### Row 272
- Column 1: math

### Row 273
- Column 1: math

### Row 274
- Column 1: math

### Row 275
- Column 1: math

### Row 276
- Column 1: math

### Row 277
- Column 1: math

### Row 278
- Column 1: math

### Row 279
- Column 1: math

### Row 280
- Column 1: math

### Row 281
- Column 1: math

### Row 282
- Column 1: math

### Row 283
- Column 1: math

### Row 284
- Column 1: math

### Row 285
- Column 1: math

### Row 286
- Column 1: math

### Row 287
- Column 1: math

### Row 288
- Column 1: math

### Row 289
- Column 1: math

### Row 290
- Column 1: math

### Row 291
- Column 1: math

### Row 292
- Column 1: math

### Row 293
- Column 1: math

### Row 294
- Column 1: math

### Row 295
- Column 1: math

### Row 296
- Column 1: math

### Row 297
- Column 1: math

### Row 298
- Column 1: math

### Row 299
- Column 1: math

### Row 300
- Column 1: math

### Row 301
- Column 1: math

### Row 302
- Column 1: math

### Row 303
- Column 1: math

### Row 304
- Column 1: math

### Row 305
- Column 1: math

### Row 306
- Column 1: math

### Row 307
- Column 1: math

### Row 308
- Column 1: math

### Row 309
- Column 1: math

### Row 310
- Column 1: math

### Row 311
- Column 1: math

### Row 312
- Column 1: math

### Row 313
- Column 1: math

### Row 314
- Column 1: math

### Row 315
- Column 1: math

### Row 316
- Column 1: math

### Row 317
- Column 1: math

### Row 318
- Column 1: math

### Row 319
- Column 1: math

### Row 320
- Column 1: math

### Row 321
- Column 1: math

### Row 322
- Column 1: math

### Row 323
- Column 1: math

### Row 324
- Column 1: math

### Row 325
- Column 1: math

### Row 326
- Column 1: math

### Row 327
- Column 1: math

### Row 328
- Column 1: math

### Row 329
- Column 1: math

### Row 330
- Column 1: math

### Row 331
- Column 1: math

### Row 332
- Column 1: math

### Row 333
- Column 1: math

### Row 334
- Column 1: math

### Row 335
- Column 1: math

### Row 336
- Column 1: math

### Row 337
- Column 1: math

### Row 338
- Column 1: math

### Row 339
- Column 1: math

### Row 340
- Column 1: math

### Row 341
- Column 1: math

### Row 342
- Column 1: math

### Row 343
- Column 1: math

### Row 344
- Column 1: math

### Row 345
- Column 1: math

### Row 346
- Column 1: math

### Row 347
- Column 1: math

### Row 348
- Column 1: math

### Row 349
- Column 1: math

### Row 350
- Column 1: math

### Row 351
- Column 1: math

### Row 352
- Column 1: math

### Row 353
- Column 1: math

### Row 354
- Column 1: math

### Row 355
- Column 1: math

### Row 356
- Column 1: math

### Row 357
- Column 1: math

### Row 358
- Column 1: math

### Row 359
- Column 1: math

### Row 360
- Column 1: math

### Row 361
- Column 1: math

### Row 362
- Column 1: math

### Row 363
- Column 1: math

### Row 364
- Column 1: math

### Row 365
- Column 1: math

### Row 366
- Column 1: math

### Row 367
- Column 1: math

### Row 368
- Column 1: math

### Row 369
- Column 1: math

### Row 370
- Column 1: math

### Row 371
- Column 1: math

### Row 372
- Column 1: math

### Row 373
- Column 1: math

### Row 374
- Column 1: math

### Row 375
- Column 1: math

### Row 376
- Column 1: math

### Row 377
- Column 1: math

### Row 378
- Column 1: math

### Row 379
- Column 1: math

### Row 380
- Column 1: math

### Row 381
- Column 1: math

### Row 382
- Column 1: math

### Row 383
- Column 1: math

### Row 384
- Column 1: math

### Row 385
- Column 1: math

### Row 386
- Column 1: math

### Row 387
- Column 1: math

### Row 388
- Column 1: math

### Row 389
- Column 1: math

### Row 390
- Column 1: math

### Row 391
- Column 1: math

### Row 392
- Column 1: math

### Row 393
- Column 1: math

### Row 394
- Column 1: math

### Row 395
- Column 1: math

### Row 396
- Column 1: math

### Row 397
- Column 1: math

### Row 398
- Column 1: math

### Row 399
- Column 1: math

### Row 400
- Column 1: math

### Row 401
- Column 1: math

### Row 402
- Column 1: math

### Row 403
- Column 1: math

### Row 404
- Column 1: math

### Row 405
- Column 1: math

### Row 406
- Column 1: math

### Row 407
- Column 1: math

### Row 408
- Column 1: math

### Row 409
- Column 1: math

### Row 410
- Column 1: math

### Row 411
- Column 1: math

### Row 412
- Column 1: math

### Row 413
- Column 1: math

### Row 414
- Column 1: math

### Row 415
- Column 1: math

### Row 416
- Column 1: math

### Row 417
- Column 1: math

### Row 418
- Column 1: math

### Row 419
- Column 1: math

### Row 420
- Column 1: math

### Row 421
- Column 1: math

### Row 422
- Column 1: math

### Row 423
- Column 1: math

### Row 424
- Column 1: math

### Row 425
- Column 1: math

### Row 426
- Column 1: math

### Row 427
- Column 1: math

### Row 428
- Column 1: math

### Row 429
- Column 1: math

### Row 430
- Column 1: math

### Row 431
- Column 1: math

### Row 432
- Column 1: math

### Row 433
- Column 1: math

### Row 434
- Column 1: math

### Row 435
- Column 1: math

### Row 436
- Column 1: math

### Row 437
- Column 1: math

### Row 438
- Column 1: math

### Row 439
- Column 1: math

### Row 440
- Column 1: math

### Row 441
- Column 1: math

### Row 442
- Column 1: math

### Row 443
- Column 1: math

### Row 444
- Column 1: math

### Row 445
- Column 1: math

### Row 446
- Column 1: math

### Row 447
- Column 1: math

### Row 448
- Column 1: math

### Row 449
- Column 1: math

### Row 450
- Column 1: math

### Row 451
- Column 1: math

### Row 452
- Column 1: math

### Row 453
- Column 1: math

### Row 454
- Column 1: math

### Row 455
- Column 1: math

### Row 456
- Column 1: math

### Row 457
- Column 1: math

### Row 458
- Column 1: math

### Row 459
- Column 1: math

### Row 460
- Column 1: math

### Row 461
- Column 1: math

### Row 462
- Column 1: math

### Row 463
- Column 1: math

### Row 464
- Column 1: math

### Row 465
- Column 1: math

### Row 466
- Column 1: math

### Row 467
- Column 1: math

### Row 468
- Column 1: math

### Row 469
- Column 1: math

### Row 470
- Column 1: math

### Row 471
- Column 1: math

### Row 472
- Column 1: math

### Row 473
- Column 1: math

### Row 474
- Column 1: math

### Row 475
- Column 1: math

### Row 476
- Column 1: math

### Row 477
- Column 1: math

### Row 478
- Column 1: math

### Row 479
- Column 1: math

### Row 480
- Column 1: math

### Row 481
- Column 1: math

### Row 482
- Column 1: math

### Row 483
- Column 1: math

### Row 484
- Column 1: math

### Row 485
- Column 1: math

### Row 486
- Column 1: math

### Row 487
- Column 1: math

### Row 488
- Column 1: math

### Row 489
- Column 1: math

### Row 490
- Column 1: math

### Row 491
- Column 1: math

### Row 492
- Column 1: math

### Row 493
- Column 1: math

### Row 494
- Column 1: math

### Row 495
- Column 1: math

### Row 496
- Column 1: math

### Row 497
- Column 1: math

### Row 498
- Column 1: math

### Row 499
- Column 1: math

### Row 500
- Column 1: math

### Row 501
- Column 1: math

### Row 502
- Column 1: math

### Row 503
- Column 1: math

### Row 504
- Column 1: math

### Row 505
- Column 1: math

### Row 506
- Column 1: math

### Row 507
- Column 1: math

### Row 508
- Column 1: math

### Row 509
- Column 1: math

### Row 510
- Column 1: math

### Row 511
- Column 1: math

### Row 512
- Column 1: math

### Row 513
- Column 1: math

### Row 514
- Column 1: math

### Row 515
- Column 1: math

### Row 516
- Column 1: math

### Row 517
- Column 1: math

### Row 518
- Column 1: math

### Row 519
- Column 1: math

### Row 520
- Column 1: math

### Row 521
- Column 1: math

### Row 522
- Column 1: math

### Row 523
- Column 1: math

### Row 524
- Column 1: math

### Row 525
- Column 1: math

### Row 526
- Column 1: math

### Row 527
- Column 1: math

### Row 528
- Column 1: math

### Row 529
- Column 1: math

### Row 530
- Column 1: math

### Row 531
- Column 1: math

### Row 532
- Column 1: math

### Row 533
- Column 1: math

### Row 534
- Column 1: math

### Row 535
- Column 1: math

### Row 536
- Column 1: math

### Row 537
- Column 1: math

### Row 538
- Column 1: math

### Row 539
- Column 1: math

### Row 540
- Column 1: math

### Row 541
- Column 1: math

### Row 542
- Column 1: math

### Row 543
- Column 1: math

### Row 544
- Column 1: math

### Row 545
- Column 1: math

### Row 546
- Column 1: math

### Row 547
- Column 1: math

### Row 548
- Column 1: math

### Row 549
- Column 1: math

### Row 550
- Column 1: math

### Row 551
- Column 1: math

### Row 552
- Column 1: math

### Row 553
- Column 1: math

### Row 554
- Column 1: math

### Row 555
- Column 1: math

### Row 556
- Column 1: math

### Row 557
- Column 1: math

### Row 558
- Column 1: math

### Row 559
- Column 1: math

### Row 560
- Column 1: math

### Row 561
- Column 1: math

### Row 562
- Column 1: math

### Row 563
- Column 1: math

### Row 564
- Column 1: math

### Row 565
- Column 1: math

### Row 566
- Column 1: math

### Row 567
- Column 1: math

### Row 568
- Column 1: math

### Row 569
- Column 1: math

### Row 570
- Column 1: math

### Row 571
- Column 1: math

### Row 572
- Column 1: math

### Row 573
- Column 1: math

### Row 574
- Column 1: math

### Row 575
- Column 1: math

### Row 576
- Column 1: math

### Row 577
- Column 1: math

### Row 578
- Column 1: math

### Row 579
- Column 1: math

### Row 580
- Column 1: math

### Row 581
- Column 1: math

### Row 582
- Column 1: math

### Row 583
- Column 1: math

### Row 584
- Column 1: math

### Row 585
- Column 1: math

### Row 586
- Column 1: math

### Row 587
- Column 1: math

### Row 588
- Column 1: math

### Row 589
- Column 1: math

### Row 590
- Column 1: math

### Row 591
- Column 1: math

### Row 592
- Column 1: math

### Row 593
- Column 1: math

### Row 594
- Column 1: math

### Row 595
- Column 1: math

### Row 596
- Column 1: math

### Row 597
- Column 1: math

### Row 598
- Column 1: math

### Row 599
- Column 1: math

### Row 600
- Column 1: math

### Row 601
- Column 1: math

### Row 602
- Column 1: math

### Row 603
- Column 1: math

### Row 604
- Column 1: math

### Row 605
- Column 1: math

### Row 606
- Column 1: math

### Row 607
- Column 1: math

### Row 608
- Column 1: math

### Row 609
- Column 1: math

### Row 610
- Column 1: math

### Row 611
- Column 1: math

### Row 612
- Column 1: math

### Row 613
- Column 1: math

### Row 614
- Column 1: math

### Row 615
- Column 1: math

### Row 616
- Column 1: math

### Row 617
- Column 1: math

### Row 618
- Column 1: math

### Row 619
- Column 1: math

### Row 620
- Column 1: math

### Row 621
- Column 1: math

### Row 622
- Column 1: math

### Row 623
- Column 1: math

### Row 624
- Column 1: math

### Row 625
- Column 1: math

### Row 626
- Column 1: math

### Row 627
- Column 1: math

### Row 628
- Column 1: math

### Row 629
- Column 1: math

### Row 630
- Column 1: math

### Row 631
- Column 1: math

### Row 632
- Column 1: math

### Row 633
- Column 1: math

### Row 634
- Column 1: math

### Row 635
- Column 1: math

### Row 636
- Column 1: math

### Row 637
- Column 1: math

### Row 638
- Column 1: math

### Row 639
- Column 1: math

### Row 640
- Column 1: math

### Row 641
- Column 1: math

### Row 642
- Column 1: math

### Row 643
- Column 1: math

### Row 644
- Column 1: math

### Row 645
- Column 1: math

### Row 646
- Column 1: math

### Row 647
- Column 1: math

### Row 648
- Column 1: math

### Row 649
- Column 1: math

### Row 650
- Column 1: math

### Row 651
- Column 1: math

### Row 652
- Column 1: math

### Row 653
- Column 1: math

### Row 654
- Column 1: math

### Row 655
- Column 1: math

### Row 656
- Column 1: math

### Row 657
- Column 1: math

### Row 658
- Column 1: math

### Row 659
- Column 1: math

### Row 660
- Column 1: math

### Row 661
- Column 1: math

### Row 662
- Column 1: math

### Row 663
- Column 1: math

### Row 664
- Column 1: math

### Row 665
- Column 1: math

### Row 666
- Column 1: math

### Row 667
- Column 1: math

### Row 668
- Column 1: math

### Row 669
- Column 1: math

### Row 670
- Column 1: math

### Row 671
- Column 1: math

### Row 672
- Column 1: math

### Row 673
- Column 1: math

### Row 674
- Column 1: math

### Row 675
- Column 1: math

### Row 676
- Column 1: math

### Row 677
- Column 1: math

### Row 678
- Column 1: math

### Row 679
- Column 1: math

### Row 680
- Column 1: math

### Row 681
- Column 1: math

### Row 682
- Column 1: math

### Row 683
- Column 1: math

### Row 684
- Column 1: math

### Row 685
- Column 1: math

### Row 686
- Column 1: math

### Row 687
- Column 1: math

### Row 688
- Column 1: math
